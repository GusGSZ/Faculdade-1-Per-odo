/*
   Exemplo0810 - v0.1 - 23/04 -> xx/04
   Author: Gustavo Gomes de Souza - 656841
*/

#include "io.h"

void method01 ( )
{
// declara��o de dados
   int x = 0;
   int tam = 0;
   
// leitura de dados do teclado
   do
   {
      tam = IO_readint ( "Digite o tamanho do vetor: " );
   } while ( tam <= 0 );
   
   int vetor[tam];
   
   for ( int i = 0; i < tam; i++ )
   {  
      do
      {
      x = IO_readint ( "Digite valores para o vetor: " );
      } while ( x < 0 );
      vetor [ i ] = x;
   }
   
   for ( int i = 0; i < tam; i++ )
   {  
      printf ( "%d: %d\n", i, vetor [ i ] ); 
   }  
}

void method02 ( )
{

}

void method03 ( )
{

}

void method04 ( )
{

}

void method05 ( )
{

}

void method06 ( )
{

}

void method07 ( )
{

}

void method08 ( )
{

}

void method09 ( )
{

}

void method10 ( )
{

}

void method11 ( )
{

}

void method12 ( )
{

}

/*
   Funcao principal.
   @return codigo de encerramento
*/
int main ( )
{
// definir dado
   int x = 0; // definir variavel com valor inicial
// repetir at� desejar parar
   do
   {
   
   // identificar
      IO_id ( "EXEMPLO0810 - Programa - v0.1" );
   
   // ler do teclado
      IO_println ( "Opcoes" );
      IO_println ( " 0 - Parar." );
      IO_println ( " 1 - " );
      IO_println ( " 2 - " );
      IO_println ( " 3 - " );
      IO_println ( " 4 - " );
      IO_println ( " 5 - " );
      IO_println ( " 6 - " );
      IO_println ( " 7 - " );
      IO_println ( " 8 - " );
      IO_println ( " 9 - " );
      IO_println ( "10 - " );
      IO_println ( "11 - " );
      IO_println ( "12 - " );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
   // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         default:
            IO_println ( "ERRO: Valor invalido." );
      } // fim escolher
   }
   while ( x != 0 );

// encerrar
   IO_pause ( "Apertar ENTER para terminar" );
   return ( 0 );
} // fim main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 
---------------------------------------------- previsao de testes
a.) \\-\\
b.) 3
    4
    5
    6
    2

c.) 1
    2
    3
    4
    5
    
d.) \\-\\
e.) \\-\\
f.) \\-\\
g.) \\-\\
h.) \\-\\
i.) \\-\\
j.) \\-\\
k.) \\-\\
l.) \\-\\

---------------------------------------------- resultados
a.) 0: 1
    1: 2
    2: 3
    3: 4
    4: 5
    
b.) 0: 3
    1: 4
    2: 5
    3: 6
    4: 2
    
c.) \\-\\

d.) 0: 1
    1: 2
    2: 3
    3: 4
    4: 5
    
e.)  Original
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
     
     Copia
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5

f.) Soma = 15

g.) Array1
     0: 0
     1: 0
     2: 0
     3: 0
     4: 0
     isAllZeros (array1) = 1
     
     Array2
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
     isAllZeros (array2) = 0
     
     Array3
     0: 1
     1: 2
     2: 0
     3: 4
     4: 5
     isAllZeros (array3) = 0

h.) Original
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
     
    Copia
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
     
    Soma
     0: -1
     1: -2
     2: -3
     3: -4
     4: -5
    
i.) Original
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
     
    Copia
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
    
    Iguais = 1
    
    Copia alterada
     0: -1
     1: 2
     2: 3
     3: 4
     4: 5
    
    Iguais = 0

j.) Original
     0: 1
     1: 2
     2: 3
     3: 4
     4: 5
    
    Procurar por (1) = 1
    
    Procurar por (3) = 1
    
    Procurar por (5) = 1
    
    Procurar por (-1) = 0

---------------------------------------------- historico
Versao          Data                           Modificacao
0.1 ( Begin )   21/04                          esboco
    ( Final )   22/04


---------------------------------------------- testes
Versao       Teste
0.1          01. ( OK )                        identificacao de programa

*/