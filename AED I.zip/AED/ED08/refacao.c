/**
   Refa��o - 24/04/2019
   Matr�cula: 656841
   Author: Gustavo Gomes de Souza
*/

#include "io.h"

bool placa ( chars placa1 )
{
   int val1 = 0;
   int val2 = 0;
   int val3 = 0;
   int tam = 0;
   
   tam = strlen ( placa1 );
   
   if ( tam == 8 )
   {
      for ( int x = 0; x < 3; x++ )
      {
         if ( placa1 [ x ] >= 'A' && placa1 [ x ] <= 'Z' )
         {
            val1 = val1 + 1;
         }
      }
      
      if ( placa1 [ 3 ] == '-' )
      {
         val2 = 1;
      }
      
      for ( int y = 4; y < 8; y++ )
      {
         if ( placa1 [ y ] >= '0' && placa1 [ y ] <= '9' )
         {
            val3 = val3 + 1;
         }
      }
      
      if ( val1 == 3 && val2 == 1 && val3 == 4 )
      {
         return ( true );
      }
      else
      {
         return ( false );
      }
   }
   else
   {
      return ( false );
   }
}



double maisproximo ( double x, double y )
{  
   double dif1 = 0.0;
   double dif2 = 0.0;
   
   dif1 = 3.1415 - x;
   dif2 = 3.1415 - y;
   
   if ( dif1 < dif2 )
   {
      return ( x );
   }
   else
   {
      return ( y );
   }
}

double exercicio01 ( int x )
{
   double k = 1.0;
   double soma1 = 1.0;
   double soma2 = 0.0;
   
   if ( x == 0 )
   {
      soma1 = 0.0;
      soma2 = 0.0;
   }
   
   if ( x == 1 )
   {
      soma1 = 1.0;
      soma2 = (2/35);
   }
   else
   {
      for ( int i = 2; i <= x; i++ )
      {
            if ( i % 2 == 0 )
            {
               soma1 = soma1 - (1.0/(i+k));
               
            }
            else
            {
               soma1 = soma1 + (1.0/i+k);
            }
            k = k + 1.0;
      }
   }

   soma2 = (1.0/(4.0*x+1.0)) - (1.0/(4.0*x+3.0));
   
   printf ( "Soma1 = %lf \n Soma2 = %lf\n", soma1, soma2 );
   double a = maisproximo ( soma1, soma2 );
   
   return ( a );
}

// METODOS

void method01 ( )
{
   int x = 0;
   x = IO_readint ( "Digite a quantidade: " );
   
   printf ( "%lf e' o valor mais proximo de PI ( 3.1415 )", exercicio01 ( x ) );
   
   IO_pause ( "Aperte ENTER para continuar." );
}


void method02 ( )
{
   chars placa1 = IO_new_chars ( 80 );
   strcpy ( placa1, "" );
   placa1 = IO_readstring ( "Digite a placa: " );
   
   printf ( "Resultado = %d\n", placa(placa1));
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method03 ( )
{

}



int main ( )
{
   int x = 0;
   
   do
   {
      IO_println ( "\n0 - parar. " );
      IO_println ( "1 - Dizer se um valor e' negativo, igual a zero ou positivo ( par ou impar )." );
      IO_println ( "2 - Contar quantos valores sao negativos, iguais a zero ou positivos ( par ou impar ) e dizer qual a maior quantidade." );
      IO_println ( "3 - Dizer se o simbolo e' operador logico, aritmetico, relacional, separador ou outro simbolo qualquer." );
      IO_println ( "\n" );
      x = IO_readint ( "Escolha uma opcao: " );
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         default:
            printf ( "Opcao invalida." );
      }
   } while ( x != 0 );
   
   IO_pause ( "Aperte ENTER para terminar." );
   return ( 0 );
}