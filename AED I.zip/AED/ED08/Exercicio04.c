#include "io.h"

/**
   FUNCOES
*/

bool par ( int x )
{
   if ( x % 2 == 0 )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool impar ( int x )
{
   if ( x % 2 != 0 )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

int maius ( chars palavra )
{
   int tam = strlen ( palavra );
   int x = 0;
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( palavra [ i ] >= 'A' && palavra [ i ] <= 'Z' )
      {
         x = x + 1;
      }
   }
   
   return ( x );
}

int minus ( chars palavra )
{
   int tam = strlen ( palavra );
   int x = 0;
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( palavra [ i ] >= 'a' && palavra [ i ] <= 'z' )
      {
         x = x + 1;
      }
   }
   
   return ( x );
}

int digitos ( chars palavra )
{
   int tam = strlen ( palavra );
   int x = 0;
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( palavra [ i ] >= '0' && palavra [ i ] <= '9' )
      {
         x = x + 1;
      }
   }
   
   return ( x );
}

int operadores ( chars palavra )
{
   int tam = strlen ( palavra );
   int x = 0;
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( palavra [ i ] == '&' || palavra [ i ] == '|' || palavra [ i ] == '!' || palavra [ i ] == '+' || palavra [ i ] == '-' || palavra [ i ] == '*' ||
            palavra [ i ] == '/' || palavra [ i ] == '%' || palavra [ i ] == '>' || palavra [ i ] == '<' || palavra [ i ] == '=')
      {
         x = x + 1;
      }
   }
   
   return ( x );
}

int separadores ( chars palavra )
{
   int tam = strlen ( palavra );
   int x = 0;
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( palavra [ i ] == ' ' || palavra [ i ] == '.' || palavra [ i ] == ',' || palavra [ i ] == ';' || palavra [ i ] == ':' || palavra [ i ] == '_' )
      {
         x = x + 1;
      }
   }
   
   return ( x );
}

bool sep ( char palavra )
{  
   if ( palavra == ' ' || palavra == '.' || palavra == ',' || palavra == ';' || palavra == ':' || palavra == '_' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}


bool oplog ( char palavra )
{
   if ( palavra == '&' || palavra == '|' || palavra == '!' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
} 

bool oparit ( char palavra )
{
   if ( palavra == '+' || palavra == '-' || palavra == '*' || palavra == '/' || palavra == '%' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool oprelac ( char palavra )
{
   if ( palavra == '>' || palavra == '<' || palavra == '=' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool letra ( char palavra )
{
   if ( palavra >= 'A' && palavra <= 'Z' || palavra >= 'a' && palavra <= 'z' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool numero ( char palavra )
{
   if ( palavra >= '0' && palavra <= '9' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool outro ( char x )
{
   if ( x < 'A' || x > 'Z' && x < 'a' || x > 'z' && x < '0' || x > '9' )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
}

bool cres ( char x, char y, char z )
{
   if ( ( ( int ) x < ( int ) y && ( int ) x < ( int ) z && ( int ) y < ( int ) z ) )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
   
}

bool dec ( char x, char y, char z )
{
   if ( ( int )x > ( int )y && ( int )x > ( int )z && ( int )y > ( int )z )
   {
      return ( true );
   }
   else
   {
      return ( false );
   }
   
}

/**

   METODOS
*/

void method01 ( )
{
   int n = 0;
   int x = 0;
   
   n = IO_readint ( "Digite a quantidade: " );
   
   for ( int i = 0; i < n; i++ )
   {
      x = IO_readint ( "Digite um valor: " );
      
      if ( x > 0 && par ( x ) )
      {
         printf ( "O numero %d e' par e positivo.\n", x );
      }
      else
      {
         if ( x > 0 && impar ( x ) )
         {
            printf ( "O numero %d e' impar e positivo.\n", x );
         }
      }
      
      if ( x < 0 && par ( x ) )
      {
         printf ( "O numero %d e' par e negativo.\n", x );
      }
      else
      {
         if ( x < 0 && impar ( x ) )
         {
            printf ( "O numero %d e' impar e negativo.\n", x );
         }
      }
      
      if ( x == 0 )
      {
         printf ( "O numero %d e' nulo.\n", x );
      }
   }
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method02 ( )
{
   int n = 0;
   int x = 0;
   int cont = 0;
   int cont2 = 0;
   int cont3 = 0;
   int cont4 = 0;
   int cont5 = 0;
   
   n = IO_readint ( "Digite a quantidade: " );
   
   for ( int i = 0; i < n; i++ )
   {
      x = IO_readint ( "Digite um valor: " );
      
      if ( x > 0 && par ( x ) )
      {
         cont++;
      }
      else
      {
         if ( x > 0 && impar ( x ) )
         {
            cont2++;
         }
      }
      
      if ( x < 0 && par ( x ) )
      {
         cont3++;
      }
      else
      {
         if ( x < 0 && impar ( x ) )
         {
            cont4++;
         }
      }
      
      if ( x == 0 )
      {
         printf ( "O numero %d e' nulo.\n", x );
         cont5++;
      }
   }
   
   if ( cont > cont2 && cont > cont3 && cont > cont4 && cont > cont5 )
   {
      printf ( "Existem mais numeros positivos pares. " );
   }
   else
   {
      if ( cont2 > cont && cont2 > cont3 && cont2 > cont4 && cont2 > cont5 )
      {
         printf ( "Existem mais numeros positivos impares. " );
      }
      else
      {
         if ( cont3 > cont && cont3 > cont2 && cont3 > cont4 && cont3 > cont5 )
         {
            printf ( "Existem mais numeros negativos pares. " );
         }
         else
         {
            if ( cont4 > cont && cont4 > cont2 && cont4 > cont3 && cont4 > cont5 )
            {
               printf ( "Existem mais numeros negativos impares. " );
            }
            else
            {
               if ( cont5 > cont && cont5 > cont2 && cont5 > cont3 && cont5 > cont4 )
               {
                  printf ( "Existem mais zeros. " );
               }
               else
               {
                  if ( cont == cont2 || cont == cont3 || cont == cont4 || cont == cont5 || cont2 == cont3 || cont2 == cont4 || cont2 == cont5 || 
                       cont3 == cont4 || cont3 == cont5 || cont4 == cont5 )
                  {
                     printf ( "Uma ou mais quantidades sao iguais. " );
                  }
               }
            }
         }
      }
   }
   
   IO_pause ( "Aperte ENTER para continuar." );
}



void method03 ( )
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   palavra = IO_readstring ( "Digite algo: " );
   
   int tam = strlen ( palavra );
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( sep (palavra [ i ]) )
      {
         printf ( "%c e' um separador.\n", palavra [ i ] );
      }
      else
      {
         if ( oplog (palavra [ i ]) )
         {
            printf ( "%c e' um operador logico.\n", palavra [ i ] );
         }
         else
         {
            if ( oparit (palavra [ i ]) )
            {
               printf ( "%c e' um operador aritmetico.\n", palavra [ i ] );
            }
            else
            {
               if ( oprelac (palavra [ i ]) )
               {
                  printf ( "%c e' um operador relacional.\n", palavra [ i ] );
               }
               else
               {
                  if ( letra (palavra [ i ]) )
                  {
                     printf ( "%c e' uma letra.\n", palavra [ i ] );
                  }
                  else
                  {
                     if ( numero (palavra [ i ]) )
                     {
                        printf ( "%c e' um numero.\n", palavra [ i ] );
                     }
                     else
                     {
                        if ( outro (palavra [ i ]) )
                        {
                           printf ( "%c e' outro tipo de simbolo.\n", palavra [ i ] );
                        }
                     }
                  }
               }
            }
         }
      }
   }
   
   IO_pause ( "Aperte ENTER para continuar. " );
}

void method04 ( )
{
   chars s = IO_new_chars ( 80 );
   strcpy ( s, "" );
   
   printf ( "Digite algo: " );
   scanf ( "%[^\n]s", s );
   
   
   printf ( "Ha' %d letras maiusculas na cadeia: \n", maius ( s ) );
   printf ( "Ha' %d letras minusculas na cadeia: \n", minus ( s ) );
   printf ( "Ha' %d digitos na cadeia: \n", digitos ( s ) );
   printf ( "Ha' %d operadores na cadeia: \n", operadores ( s ) );
   printf ( "Ha' %d separadores na cadeia: \n", separadores ( s ) );
   
   IO_pause ( "Aperte ENTER para continuar. " );
}



void method05 ( )
{   
   int n = 0;
   double x = 0.0;
   double soma = 0.0;
   double soma2 = 0.0;
   double soma3 = 0.0;
   double media1 = 0.0;
   double media2 = 0.0;
   double media3 = 0.0;
   int cont1 = 0;
   int cont2 = 0;
   int cont3 = 0;
   
   n = IO_readint ( "Digite uma quantidade: " );
   
   for ( int i = 0; i < n; i++ )
   {
      x = IO_readdouble ( "Digite um valor: " );
      if ( x < -21.50 )
      {
         soma = (soma) + x;
         printf ( "%lf\n", soma );
         cont1 = cont1 + 1;
      }
      else
      {
         if ( (x >= (-21.50)) && (x <= (21.50)) )
         {
            soma2 = soma2 + x;
            printf ( "%lf\n", soma2 );
            cont2 = cont2 + 1;
         }
         else
         {
            if ( x > 21.50 )
            {
               soma3 = soma3 + x;
               printf ( "%lf\n", soma3 );
               cont3 = cont3 + 3;
            }
         }
      }
   } 
   
   if ( cont1 == 0 )
   {
      media1 = 0;
   }
   else
   {
      media1 = soma/cont1;
   }
   
   if ( cont2 == 0 )
   {
      media2 = 0;
   }
   else
   {
      media2 = soma2/cont2;
   }
   
   if ( cont3 == 0 )
   {
      media3 = 0;
   }
   else
   {
      media3 = soma3/cont3;
   }
   
   printf ( "Media dos valores menores que -21.50 = %lf\n", media1 );
   printf ( "Media dos valores entre -21.50 e 21.50 = %lf\n", media2 );
   printf ( "Media dos valores maiores que 21.50 = %lf\n", media3 );
   
   if ( media1 > media2 && media1 > media3 )
   {
      printf ( "Media 1 e' a maior.\n" );
   }
   else
   {
      if ( media2 > media1 && media2 > media3 )
      {
         printf ( "Media 2 e' a maior.\n" );
      }
      else
      {
         if ( media3 > media1 && media3 > media2 )
         {
            printf ( "Media 3 e' a maior.\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para continuar. " );
}

void method06 ( )
{
   int a = 0;
   int b = 0;
   int valor = 0;
   double pot = 0.0;
   double soma = 0.0;
   
   a = IO_readint ( "\nDigite o valor minimo: " );
   b = IO_readint ( "Digite o valor maximo: " );
   
   printf ( "Digite valores: (-1 pra parar) \n" );
   
   do
   {
      valor = IO_readint ( "" );
      pot = pow ( valor, 2 );
      if ( valor > a && valor < b )
      {
         soma = soma + ( 1.0/pot );
      }
   
   } while ( valor != -1 );
   
   printf ( "\nSoma dos quadrados dos inversos dos valores dentro do intervalo inseridos = %lf\n", soma );
   
   IO_pause ( "Aperte ENTER para continuar. " );
   
}

void method07 ( )
{
   double a = 0.0;
   double b = 0.0;
   double x = 0.0;
   int acima = 0;
   int dentro = 0;
   int abaixo = 0;
   double tot = 0.0;
   double prcabaixo = 0.0;
   double prcdentro = 0.0;
   double prcacima = 0.0;
   
   a = IO_readdouble ( "Digite o valor minimo: " );
   
   do
   {
      b = IO_readdouble ( "Digite o valor maximo: " );
   } while ( b <= a );
   
   do
   {
      x = IO_readdouble ( "Digite um valor: ( 0 termina )\n" );
      
      if ( x == 0 )
      {
         break;
      }
      
      tot++;
      
      if ( x < a )
      {
         abaixo++;
      }
      else
      {
         if ( x > b )
         {
            acima++;
         }
         else
         {
            if ( x > a && x < b )
            {
               dentro++;
            }
         }
      }
   } while ( x != 0 );
   
   if ( tot == 0 )
   {
      prcabaixo = 0.0;
      prcdentro = 0.0;
      prcacima = 0.0;
   }
   else
   {
      prcabaixo = ( abaixo * 100 ) / tot;
      prcdentro = ( dentro * 100 ) / tot;
      prcacima  = ( acima  * 100 ) / tot;
   }
   
   printf ( "Porcentagem de numeros abaixo do intervalo = %lf (por cento)\n", prcabaixo );
   printf ( "Porcentagem de numeros dentro do intervalo = %lf (por cento)\n", prcdentro );
   printf ( "Porcentagem de numeros acima do intervalo = %lf (por cento)\n", prcacima );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

void method08 ( )
{
   double x = 0.0;
   double y = 0.0;
   double z = 0.0;
   
   
   x = IO_readdouble ( "Digite um valor: " );
   y = IO_readdouble ( "Digite outro valor: " );
   z = IO_readdouble ( "Digite mais um valor: " );
   
   if ( x < y && x < z && y < z )
   {
      printf ( "Os valores estao em ordem crescente.\n" );
      printf ( "%lf\n", x );
      printf ( "%lf\n", y );
      printf ( "%lf\n", z );
   }
   else
   {
      if ( x > y && x > z && y > z )
      {
         printf ( "Os valores estao em ordem decrescente.\n" );
         printf ( "%lf\n", x );
         printf ( "%lf\n", y );
         printf ( "%lf\n", z );
      }
      else
      {
         printf ( "Os valores nao estao em nenhuma dessas ordens.\n" );
         printf ( "%lf\n", x );
         printf ( "%lf\n", y );
         printf ( "%lf\n", z );
      }
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method09 ( )
{
   char x = ' ';
   char y = ' ';
   char z = ' ';    
   
   x = IO_readchar ( "Digite um caracter: " );
   y = IO_readchar ( "Digite outro caracter: " );
   z = IO_readchar ( "Digite mais um caracter: " );
   
   if ( cres ( x, y, z ) )
   {
      printf ( "Os caracteres estao em ordem crescente.\n" );
      printf ( "%c\n", x );
      printf ( "%c\n", y );
      printf ( "%c\n", z );
   }
   else
   {
      if ( dec ( x, y, z ) )
      {
         printf ( "Os caracteres estao em ordem decrescente.\n" );
         printf ( "%c\n", x );
         printf ( "%c\n", y );
         printf ( "%c\n", z );
      }
      else
      {
         printf ( "Os caracteres nao estao em ordem nenhuma.\n" );
         printf ( "%c\n", x );
         printf ( "%c\n", y );
         printf ( "%c\n", z );
      }
   }
   
   IO_pause ( "Aperte ENTER para continuar. " );
}

void method10 ( )
{
   chars x = IO_new_chars ( 80 );
   chars y = IO_new_chars ( 80 );
   chars z = IO_new_chars ( 80 );
   
   strcpy ( x, "" ); 
   strcpy ( y, "" );
   strcpy ( z, "" );
   
   
   x = IO_readstring ( "Digite uma cadeia de caracteres: " );
   y = IO_readstring ( "Digite outra cadeia de caracteres: " );
   z = IO_readstring ( "Digite mais uma cadeia de caracteres: " );
   
   if ( strcmp ( x, y ) < 0 && strcmp ( x, z ) < 0 )
   {
      printf ( "As cadeias estao em ordem crescente.\n" );
      printf ( "%s\n", x );
      printf ( "%s\n", y );
      printf ( "%s\n", z );
   }
   else
   {
      if ( strcmp ( x, y ) > 0 && strcmp ( x, z ) > 0 )
      {
         printf ( "As cadeias estao em ordem decrescente.\n" );
         printf ( "%s\n", x );
         printf ( "%s\n", y );
         printf ( "%s\n", z );
      }
      else
      {
         printf ( "As cadeias nao estao em ordem nenhuma.\n" );
         printf ( "%s\n", x );
         printf ( "%s\n", y );
         printf ( "%s\n", z );
      }
   }
   
   IO_pause ( "Aperte ENTER para continuar. " );
}

/** 
   Funcao principal
*/
int main ( )
{
   int x = 0;
   
   do
   {
      IO_println ( "\n0 - parar. " );
      IO_println ( "1 - Dizer se um valor e' negativo, igual a zero ou positivo ( par ou impar )." );
      IO_println ( "2 - Contar quantos valores sao negativos, iguais a zero ou positivos ( par ou impar ) e dizer qual a maior quantidade." );
      IO_println ( "3 - Dizer se o simbolo e' operador logico, aritmetico, relacional, separador ou outro simbolo qualquer." );
      IO_println ( "4 - Contar simbolos." );
      IO_println ( "5 - Calcular e mostrar maior media." );
      IO_println ( "6 - Calcular e mostrar a soma dos quadrados dos inversos." );
      IO_println ( "\n" );
      x = IO_readint ( "Escolha uma opcao: " );
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         default:
            printf ( "Opcao invalida." );
      }
   } while ( x != 0 );
   
   IO_pause ( "Aperte ENTER para terminar." );
}