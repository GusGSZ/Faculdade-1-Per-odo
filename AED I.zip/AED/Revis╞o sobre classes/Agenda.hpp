#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <string>
using std::string;
#include <fstream>
using std::ifstream;
using std::ofstream;
#include <cstring>

#include "Pessoa.hpp"

#ifndef _Agenda_
#define _Agenda_

class Agenda
{
    private:
    Pessoa pessoas[10];
    int i = -1;

    public:

    Agenda()
    {
        /*
        for ( int k = 0; k < 10; k++ )
        {
            pessoas[k].set("", 0, 0.0);
        }
        */
    }

    ~Agenda()
    {
        
    }

    int buscaPessoa(string name)
    {
        int pos = 0;
        for ( int j = 0; j <= i; j++ )
        {
            if ( pessoas[j].getNome().compare(name) == 0 )
            {
                pos = j;
            }
        }

        return pos;
    }

    void armazenaPessoa ( string n, int ida, double a )
    {
        i++;
        pessoas[i].set(n, ida, a);
    }

    void removePessoa( string name )
    {
        for ( int l = 0; l <= i; l++ )
        {
            if ( pessoas[l].getNome().compare(name) == 0 )
            {
                pessoas[l].set("", 0, 0.0);
            }
        }
    }

    void imprimePovo()
    {
        for( int j = 0; j <= i; j++ )
        {
            if( pessoas[j].getNome().compare("") != 0 )
            {
                pessoas[j].imprimir();
                cout << endl;
            }
        }
    }

    void imprimePessoa(int p)
    {
        pessoas[p].imprimir();
    }
};

#endif