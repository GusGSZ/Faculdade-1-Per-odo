#include <iostream>
#include <string>
#include <fstream>

#ifndef _ELV_
#define _ELV_

using namespace std;

class Elevador
{
    private:
        int atual;
        int totaland;
        int capacidade;
        int qtdpes;

    public:
        Elevador()
        {
            atual = 0;
            totaland = 0;
            capacidade = 0;
            qtdpes = 0;
        }

        ~Elevador()
        {
            
        }

        void inicializa( int cap, int total )
        {
            totaland = total;
            capacidade = cap;
            atual = 0;
            qtdpes = 0;
        }

        void entra()
        {
            if ( qtdpes < capacidade )
            {
                qtdpes++;
            }
            else
            {
                cout << "Ta cheio." << endl;
            }
        }

        void sai()
        {
            if ( qtdpes > 0 )
            {
                qtdpes--;
            }
            else
            {
                cout << "Nao tem ninguem." << endl;
            }
        }

        void sobe()
        {
            if ( atual < totaland )
            {
                atual++;
            }
            else
            {
                cout << "Ja' esta' no ultimo andar." << endl;
            }
        }

        void desce()
        {
            if ( atual > 0 )
            {
                atual--;
            }
            else
            {
                cout << "Ja' esta' no terreo." << endl;
            }
            
        }

        int getAtual()
        {
            return atual;
        }

        int getTotal()
        {
            return totaland;
        }

        int getCap()
        {
            return capacidade;
        }

        int getQtdPes()
        {
            return qtdpes;
        }

        void imprimir()
        {
            cout << "" << endl;
            cout << "Total de andares: " << totaland << endl;
            cout << "Andar atual: " << atual << endl;
            cout << "Capacidade: " << capacidade << endl;
            cout << "Quantidade de pessoas no elevador: " << qtdpes << endl;
            cout << "" << endl;
        }

};

#endif

int main ( )
{
    int totalandares = 0;
    int andat = 0;
    int cap = 0;
    int qtdpessoas = 0;
    int x = 0;
 
    cout << "Quantos andares tem o predio? ";
    cin >> totalandares;
    cout << "Qual a capacidade do elevador? ";
    cin >> cap;

    Elevador e;
    e.inicializa(cap, totalandares);

    do
    {
        cout << "0 - parar." << endl;
        cout << "1 - entra." << endl;
        cout << "2 - sai." << endl;
        cout << "3 - sobe." << endl;
        cout << "4 - desce." << endl;
        cout << "5 - informacoes sobre o elevador." << endl;
        cout << "Escolha a opcao: ";
        cin >> x;
        switch ( x )
        {
            case 0:
                break;
            case 1:
                e.entra();
                break;
            case 2:
                e.sai();
                break;
            case 3:
                e.sobe();
                break;
            case 4:
                e.desce();
                break;
            case 5:
                e.imprimir();
                break;
            default:
                cout << "Opcao invalida." << endl;
        }
    } while ( x != 0 );
    

    return 0;
}