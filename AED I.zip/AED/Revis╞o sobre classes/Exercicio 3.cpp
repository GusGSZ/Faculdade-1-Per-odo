#include <iostream>
#include <string>
#include <fstream>

using namespace std;

#ifndef _Relogio_
#define _Relogio_

class Relogio{
    private:
        int hora;
        int minuto;
        int segundo;
    
    public:
        
        Relogio()
        {
            hora = 0;
            minuto = 0;
            segundo = 0;
        }

        ~Relogio()
        {

        }

        void setHora( int hora, int minuto, int segundo )
        {
            if( hora > 23 || hora < 0 || minuto > 59 || minuto < 0 || segundo > 59 || segundo < 0 )
            {
                cout << "Horario invalido." << endl;
            }
            else
            {
                this->hora = hora;
                this->minuto = minuto;
                this->segundo = segundo;
            }
        }

        void getHora( int* h, int* m, int* s )
        {
            *h = hora;
            *m = minuto;
            *s = segundo;
            return;
        }

        void avancar()
        {
            segundo++;
            if ( segundo == 60 && minuto == 59 && hora == 23 )
            {
                hora = 0;
                minuto = 0;
                segundo = 0;
            }
            else
            {
                if( segundo == 60 && minuto == 59 )
                {
                    hora++;
                    minuto = 0;
                    segundo = 0;
                }
                else
                {
                    if ( segundo == 60 )
                    {
                        minuto++;
                        segundo = 0;
                    }
                }
            }
            
        }
};

#endif

int main( )
{
    int hora = 0;
    int minuto = 0;
    int seg = 0;
    int x = 0;

    Relogio r;

    do
    {
        cout << "0 - parar." << endl;
        cout << "1 - escolhe a hora." << endl;
        cout << "2 - mostra a hora." << endl;
        cout << "3 - avanca um segundo." << endl;
        cout << "Escolha a opcao: ";
        cin >> x;
        switch ( x )
        {
            case 0:
                break;
            case 1:
                cout << "Hora: ";
                cin >> hora;
                cout << "\nMinuto: ";
                cin >> minuto;
                cout << "\nSegundo: ";
                cin >> seg;
                r.setHora(hora, minuto, seg);
                break;
            case 2:
                r.getHora(&hora, &minuto, &seg);
                cout << "\n" << hora << ":" << minuto << ":" << seg << endl;
                break;
            case 3:
                r.avancar();
                break;
            default:
                cout << "Opcao invalida." << endl;
                break;
        }
    } while ( x != 0 );
    
    return 0;
}