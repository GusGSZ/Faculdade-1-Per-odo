#include <iostream>
using std::cout;
using std::cin;
using std::endl;
#include <string>
using std::string;
#include <fstream>
using std::ifstream;
using std::ofstream;

#ifndef _PESSOA_
#define _PESSOA_

class Pessoa
{
    private:
    string nome;
    int idade;
    double altura;

    public:

    Pessoa()
    {
        nome = "";
        idade = 0;
        altura = 0.0;
    }

    ~Pessoa()
    {
    }

    Pessoa ( string n, int i, double a )
    {
        nome = n;
        idade = i;
        altura = a;
    }

    string getNome( )
    {
        return this->nome;
    }

    int getIdade( )
    {
        return this->idade;
    }

    double getAltura( )
    {
        return this->altura;
    }

    void setNome ( string nome )
    {
        this->nome = nome;
    }

    void setIdade ( int idade )
    {
        this->idade = idade;
    }

    void setAltura ( double altura )
    {
        this->altura = altura;
    }

    void set ( string n, int i, double a )
    {
        nome = n;
        idade = i;
        altura = a;
    }

    void imprimir ( )
    {
        cout << "Nome: " << nome << endl;
        cout << "Idade: " << idade << endl;
        cout << "Altura: " << altura << endl;
    }
};

#endif