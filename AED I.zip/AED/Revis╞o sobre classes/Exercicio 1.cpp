#include <iostream>
#include <string>
#include <fstream>

using namespace std;

#ifndef _PESSOA_
#define _PESSOA_

class Pessoa
{
    private:
    string nome;
    int idade;
    double altura;

    public:

    Pessoa()
    {
        nome = "";
        idade = 0;
        altura = 0.0;
    }

    ~Pessoa()
    {
        
    }

    Pessoa ( string n, int i, double a )
    {
        nome = n;
        idade = i;
        altura = a;
    }

    string getNome( )
    {
        return this->nome;
    }

    int getIdade( )
    {
        return this->idade;
    }

    double getAltura( )
    {
        return this->altura;
    }

    void setNome ( string nome )
    {
        this->nome = nome;
    }

    void setIdade ( int idade )
    {
        this->idade = idade;
    }

    void setAltura ( double altura )
    {
        this->altura = altura;
    }

    void set ( string n, int i, double a )
    {
        nome = n;
        idade = i;
        altura = a;
    }

    void imprimir ( )
    {
        cout << "Nome: " << nome << endl;
        cout << "Idade: " << idade << endl;
        cout << "Altura: " << altura << endl;
    }
};

#endif

int main( int argc, char *argv[]){
    int n = 0;
    string nome = "";
    int idade = 0;
    double altura = 0.0;

    cout << "Quantas pessoas serao cadastradas?" << endl;
    cin >> n;

    Pessoa pessoas[n];

    for ( int i = 0; i < n; i++ )
    {
        cout << "Digite o nome: ";
        cin >> nome;
        cout << "Digite a idade: ";
        cin >> idade;
        cout << "Digite a altura: ";
        cin >> altura;
        
        pessoas[i].set(nome, idade, altura);
    }
    
    
    for ( int i = 0; i < n; i++ )
    {
        //cout << pessoas[i].getNome() << endl;
        pessoas[i].imprimir();
    }
    


    return 0;
}