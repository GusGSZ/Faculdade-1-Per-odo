   /*
    Exemplo0313 - v0.3 - 13/03/2019
    Author: Gustavo Gomes de Souza
   */

   // dependencias
   #include "io.h" // para definicoes proprias
   
   void metodo1 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     
     IO_id ( "EXEMPLO0313 - Metodo1 - v0.3" );
     
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          IO_printf ( "%s %c\n", "", palavra[x] );
       }
     }
     
   }
   
   void metodo2 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0313 - Metodo2 - v0.3" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     } 
   }
   
   void metodo3 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0313 - Metodo3 - v0.3" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   }
   
   int main ( )
   {
        // definir dado
   int x = 0;
     // repetir at� desejar parar
   do
   {
       // identificar
      IO_id ( "EXEMPLO0310 - Programa - v1.0" );
      IO_println ( "Opcoes" );
      IO_println ( "0 - parar" );
      IO_println ( "1 - metodo1" );
      IO_println ( "2 - metodo2" );
      IO_println ( "3 - metodo3" );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
       // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         default:
            IO_println ( IO_concat ( "Valor diferente das opcoes [0,1,2,3] (",
               IO_concat ( IO_toString_d ( x ), ")" ) ) );
      } // fim escolher
   }
     while ( x != 0 );
    IO_pause ( "Aperte ENTER para terminar." );
    return(0);
   }
   
   /*

   ---------------------------------------------- documentacao complementar
   ---------------------------------------------- notas / observacoes / comentarios
   ---------------------------------------------- previsao de testes
    a.) GusTaVoO
    b.) AnA
    c.) StroGoNoFF
    d.) QUATRO
          
   ---------------------------------------------- resultados 
    a.) 1 - O
        2 - V
        3 - T
        4 - G
    
    b.) 1 - A
        2 - A
    
    c.) 1 - F
        2 - F
        3 - N
        4 - G
        5 - S
        
    d.) 1 - O
        2 - R
        3 - T
        4 - A
        5 - U
        6 - Q
        
   ---------------------------------------------- historico
    Versao    Data                                Modificacao
    0.1       12/03                               esboco
    0.2       13/03
    0.3       13/03
 
   ---------------------------------------------- testes
    Versao     Teste
    0.1        01. ( OK )                         identificacao de programa
    0.2        01. ( OK )
    0.3        01. ( OK )
    
    */