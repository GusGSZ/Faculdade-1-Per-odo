   /*
    Exemplo0320 - v1.0 - 16/03/2019
    Author: Gustavo Gomes de Souza
   */

   // dependencias
   #include "io.h" // para definicoes proprias
   
   void metodo1 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     
     IO_id ( "EXEMPLO0320 - Metodo1 - v1.0" );
         
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          IO_printf ( "%s %c\n", "", palavra[x] );
       }
     }
     
   }
   
   void metodo2 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo2 - v1.0" );     
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     } 
   }
   
   void metodo3 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo3 - v1.0" );
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   }
   
   void metodo4 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
          
     IO_id ( "EXEMPLO0320 - Metodo4 - v1.0" );
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          maiuscula++;
          if ( !((palavra [x] >= 'a' && palavra[x] <= 'z' ) || ( palavra [x] >= 'A' && palavra [x] <= 'Z'  )))
          {
           x++;
          }
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
     }
   }  
   
   void metodo5 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo5 - v1.0" );
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
   }
   
   void metodo6 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo6 - v1.0" );
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          char simbol = palavra [x];
          if (! ( ( simbol >= 'a' && simbol <= 'z' ) || ( simbol >= 'A' && simbol <= 'Z' ) || ( simbol >= '0' && simbol <= '9' ) ) )
          {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
          }
     }
   }
   
   void metodo7 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo7 - v1.0" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   void metodo8 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo8 - v1.0" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 && !( x % 2 == 0 ) )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   void metodo9 ( )
   {
   //definir dados
     double y = 0.0, z = 0.0;
     int cont = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo9 - v1.0" );
     
     y = IO_readdouble( "Digite o numero inferior: " );
     z = IO_readdouble( "Digite o numero superior: " );
     
     while ( z <= y )
     {
      z = IO_readdouble( "Digite o numero superior: " );
     }
     
     for ( double x = y; x <= z+1; x++ )
     {
        if ( ( (int) x ) % 2 == 0 )
        {
        cont++;
        IO_printf ( "%s %d - %d\n", "", cont, (int) x );
        }
     }
   }
   
   void metodo10 ( )
   {
   //definir dados
     double y = 0.0, z = 0.0, passo = 0.01, parteinteira = 0.0, partedecimal = 0.0;
     int cont = 0;
     
     IO_id ( "EXEMPLO0320 - Metodo10 - v1.0" );
     
     do
     {
        y = IO_readdouble( "Digite o numero inferior: ");
     }
     while (  y <= 0.0 || y >= 1.0 );
     
     do
     {
        z = IO_readdouble( "Digite o numero superior: " );
     }
     while ( z <= y );
     
     parteinteira = (int)z;
     partedecimal = z - parteinteira;
     
     for ( double x = y; x <= z+0.01; x = x + passo )
     {
        if ( partedecimal > 0.00 && partedecimal < 1.0 )
        {
        cont++;
        IO_printf ( "%s %d - %lf\n", "", cont, x );
        }
     }
   }
   
   int main ( )
   {
        // definir dado
   int x = 0;
     // repetir at� desejar parar
   do
   {
       // identificar
      IO_id ( "EXEMPLO0320 - Programa - v1.0" );
      IO_println ( "Opcoes" );
      IO_println ( "0 - parar" );
      IO_println ( "1 - metodo1" );
      IO_println ( "2 - metodo2" );
      IO_println ( "3 - metodo3" );
      IO_println ( "4 - metodo4" );
      IO_println ( "5 - metodo5" );
      IO_println ( "6 - metodo6" );
      IO_println ( "7 - metodo7" );
      IO_println ( "8 - metodo8" );
      IO_println ( "9 - metodo9" );
      IO_println ( "10 - metodo10" );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
       // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         case 4:
            metodo4 ( );
            break;
         case 5:
            metodo5 ( );
            break;
         case 6:
            metodo6 ( );
            break;
         case 7:
            metodo7 ( );
            break;
         case 8:
            metodo8 ( );
            break;
         case 9:
            metodo9 ( );
            break;
         case 10:
            metodo10 ( );
            break;
         default:
            IO_println ( IO_concat ( "Valor diferente das opcoes [0,1,2,3,4,5,6,7,8,9,10] (",
               IO_concat ( IO_toString_d ( x ), ")" ) ) );
      } // fim escolher
   }
     while ( x != 0 );
    IO_pause ( "Aperte ENTER para terminar." );
    return(0);
   }
   
   /*

   ---------------------------------------------- documentacao complementar
   ---------------------------------------------- notas / observacoes / comentarios
   ---------------------------------------------- previsao de testes
    a.) 0.1 e 0.9 
    b.) 0.2 e 0.8
    c.) 0.9 e 1.2
        
   ---------------------------------------------- historico
    Versao    Data                                Modificacao
    0.1       12/03                               esboco
    0.2       13/03
    0.3       13/03
    0.4       13/03
    0.5       13/03
    0.6       13/03
    0.7       13/03
    0.8       13/03
    0.9       13/03
    1.0       16/03
 
   ---------------------------------------------- testes
    Versao     Teste
    0.1        01. ( OK )                         identificacao de programa
    0.2        01. ( OK )
    0.3        01. ( OK )
    0.4        01. ( OK )
    0.5        01. ( OK )
    0.6        01. ( OK )
    0.7        01. ( OK )
    0.8        01. ( OK )
    0.9        01. ( OK )
    1.0        01. ( OK )
    
    */