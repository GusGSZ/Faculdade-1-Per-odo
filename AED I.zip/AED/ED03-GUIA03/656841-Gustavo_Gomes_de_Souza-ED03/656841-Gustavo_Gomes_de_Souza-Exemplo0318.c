   /*
    Exemplo0318 - v0.8 - 13/03/2019
    Author: Gustavo Gomes de Souza
   */

   // dependencias
   #include "io.h" // para definicoes proprias
   
   void metodo1 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     
     IO_id ( "EXEMPLO0318 - Metodo1 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          IO_printf ( "%s %c\n", "", palavra[x] );
       }
     }
     
   }
   
   void metodo2 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo2 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     } 
   }
   
   void metodo3 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo3 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   }
   
   void metodo4 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo4 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          maiuscula++;
          if ( !((palavra [x] >= 'a' && palavra[x] <= 'z' ) || ( palavra [x] >= 'A' && palavra [x] <= 'Z'  )))
          {
           x++;
          }
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
     }
   }  
   
   void metodo5 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo5 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
   }
   
   void metodo6 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo6 - v0.8" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          char simbol = palavra [x];
          if (! ( ( simbol >= 'a' && simbol <= 'z' ) || ( simbol >= 'A' && simbol <= 'Z' ) || ( simbol >= '0' && simbol <= '9' ) ) )
          {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
          }
     }
   }
   
   void metodo7 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo7 - v0.8" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   void metodo8 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0318 - Metodo8 - v0.8" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 && !( x % 2 == 0 ) )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   int main ( )
   {
        // definir dado
   int x = 0;
     // repetir at� desejar parar
   do
   {
       // identificar
      IO_id ( "EXEMPLO0318 - Programa - v0.8" );
      IO_println ( "Opcoes" );
      IO_println ( "0 - parar" );
      IO_println ( "1 - metodo1" );
      IO_println ( "2 - metodo2" );
      IO_println ( "3 - metodo3" );
      IO_println ( "4 - metodo4" );
      IO_println ( "5 - metodo5" );
      IO_println ( "6 - metodo6" );
      IO_println ( "7 - metodo7" );
      IO_println ( "8 - metodo8" );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
       // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         case 4:
            metodo4 ( );
            break;
         case 5:
            metodo5 ( );
            break;
         case 6:
            metodo6 ( );
            break;
         case 7:
            metodo7 ( );
            break;
         case 8:
            metodo8 ( );
            break;
         default:
            IO_println ( IO_concat ( "Valor diferente das opcoes [0,1,2,3,4,5,6,7,8] (",
               IO_concat ( IO_toString_d ( x ), ")" ) ) );
      } // fim escolher
   }
     while ( x != 0 );
    IO_pause ( "Aperte ENTER para terminar." );
    return(0);
   }
   
   /*

   ---------------------------------------------- documentacao complementar
   ---------------------------------------------- notas / observacoes / comentarios
   ---------------------------------------------- previsao de testes
    a.) 11 e 44
    b.) 5 e 10
    c.) 15 e 105
          
   ---------------------------------------------- resultados 
    a.) 15
        21
        27
        33
        39
    
    b.) 9
    
    c.) 15
        21
        27
        33
        39
        45
        51
        57
        63
        69
        75
        81
        87
        93
        99
        105
        
   ---------------------------------------------- historico
    Versao    Data                                Modificacao
    0.1       12/03                               esboco
    0.2       13/03
    0.3       13/03
    0.4       13/03
    0.5       13/03
    0.6       13/03
    0.7       13/03
    0.8       13/03
 
   ---------------------------------------------- testes
    Versao     Teste
    0.1        01. ( OK )                         identificacao de programa
    0.2        01. ( OK )
    0.3        01. ( OK )
    0.4        01. ( OK )
    0.5        01. ( OK )
    0.6        01. ( OK )
    0.7        01. ( OK )
    0.8        01. ( OK )
    
    */