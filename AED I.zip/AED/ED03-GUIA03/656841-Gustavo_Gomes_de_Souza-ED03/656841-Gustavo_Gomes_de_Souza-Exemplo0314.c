   /*
    Exemplo0314 - v0.4 - 13/03/2019
    Author: Gustavo Gomes de Souza
   */

   // dependencias
   #include "io.h" // para definicoes proprias
   
   void metodo1 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     
     IO_id ( "EXEMPLO0314 - Metodo1 - v0.4" );
     
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          IO_printf ( "%s %c\n", "", palavra[x] );
       }
     }
     
   }
   
   void metodo2 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0314 - Metodo2 - v0.4" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     } 
   }
   
   void metodo3 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0314 - Metodo3 - v0.4" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   }
   
   void metodo4 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0314 - Metodo4 - v0.4" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          maiuscula++;
          if ( !((palavra [x] >= 'a' && palavra[x] <= 'z' ) || ( palavra [x] >= 'A' && palavra [x] <= 'Z'  )))
          {
           x++;
          }
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   
   int main ( )
   {
        // definir dado
   int x = 0;
     // repetir at� desejar parar
   do
   {
       // identificar
      IO_id ( "EXEMPLO0314 - Programa - v0.4" );
      IO_println ( "Opcoes" );
      IO_println ( "0 - parar" );
      IO_println ( "1 - metodo1" );
      IO_println ( "2 - metodo2" );
      IO_println ( "3 - metodo3" );
      IO_println ( "4 - metodo4" );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
       // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         case 4:
            metodo4 ( );
            break;
         default:
            IO_println ( IO_concat ( "Valor diferente das opcoes [0,1,2,3,4] (",
               IO_concat ( IO_toString_d ( x ), ")" ) ) );
      } // fim escolher
   }
     while ( x != 0 );
    IO_pause ( "Aperte ENTER para terminar." );
    return(0);
   }
   
   /*

   ---------------------------------------------- documentacao complementar
   ---------------------------------------------- notas / observacoes / comentarios
   ---------------------------------------------- previsao de testes
    a.) Gustavo
    b.) a B c
    c.) A b C
          
   ---------------------------------------------- resultados 
    a.) 1 - G
        2 - u
        3 - s
        4 - t
        5 - a
        6 - v
        7 - o
    
    b.) 1 - a
        2 - B
        3 - c
    
    c.) 1 - A
        2 - b
        3 - C
        
   ---------------------------------------------- historico
    Versao    Data                                Modificacao
    0.1       12/03                               esboco
    0.2       13/03
    0.3       13/03
    0.4       13/03
 
   ---------------------------------------------- testes
    Versao     Teste
    0.1        01. ( OK )                         identificacao de programa
    0.2        01. ( OK )
    0.3        01. ( OK )
    0.4        01. ( OK )
    
    */