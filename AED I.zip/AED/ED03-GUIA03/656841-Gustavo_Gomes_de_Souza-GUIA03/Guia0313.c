      /*    
      Guia_0313 - v0.1 - 16/03/2019
      Author: Gustavo Gomes de Souza - 656841
      
      Para compilar em uma janela de comandos (terminal): 
 
      No Linux  :   gcc -o Guia_0313      ./Guia_0313.c
      No Windows:   gcc -o Guia_0313.exe    Guia_0313.c
      
      OBS.: O arquivo de defini�oes karel.h devera' estar disponivel
                      na pasta include do compilador ou na pasta do programa.
 
      Para executar em uma janela de comandos (terminal):        
      No Linux  :   ./Guia0313.c
      No Windows:     Guia0313
 
      */ 
      // lista de dependencias 
      #include "karel.h" // na pasta do programa
      #include "mylib.h"
      #include "io.h"
       
      // --------------------------- definicoes de metodos 
 
      /**    
      decorateWorld - Metodo para preparar o cenario.    
      @param fileName - nome do arquivo para guardar a descricao.  
      */ 
      
void decorateWorld(char* fileName){
   ref_world v_world = world_now; 
      
      
      //colocar um marcador no mundo
   set_World( 4, 7, BEEPER);
   set_World( 5, 7, BEEPER);
   set_World( 5, 7, BEEPER);
   set_World( 6, 7, BEEPER);
   set_World( 6, 7, BEEPER);
   set_World( 6, 7, BEEPER);
      
      // colocar obstaculos verticais
   set_World( 1, 3, VWALL);
   set_World( 1, 4, VWALL);
   set_World( 1, 5, VWALL);
   set_World( 1, 6, VWALL);
   set_World( 1, 7, VWALL);
   set_World( 1, 8, VWALL);
      
   set_World( 7, 3, VWALL);
   set_World( 7, 4, VWALL);
   set_World( 7, 5, VWALL);
   set_World( 7, 6, VWALL);
   set_World( 7, 7, VWALL);
      
   set_World( 2, 4, VWALL);
   set_World( 2, 5, VWALL);
   set_World( 2, 6, VWALL);
   set_World( 2, 7, VWALL);
      
   set_World( 3, 5, VWALL);
   set_World( 3, 6, VWALL);
   set_World( 4, 7, VWALL);
   set_World( 5, 7, VWALL);
   set_World( 6, 5, VWALL);
   set_World( 6, 6, VWALL);
      
      // colocar obstaculos horizontais
   set_World( 2, 2, HWALL);
   set_World( 3, 2, HWALL);
   set_World( 4, 2, HWALL);
   set_World( 5, 2, HWALL);
   set_World( 6, 2, HWALL);
   set_World( 7, 2, HWALL);
      
   set_World( 2, 8, HWALL);
   set_World( 3, 8, HWALL);
   set_World( 4, 8, HWALL);
   set_World( 5, 8, HWALL);
   set_World( 6, 8, HWALL);
   set_World( 7, 8, HWALL);
      
   set_World( 3, 7, HWALL);
   set_World( 4, 7, HWALL);
   set_World( 5, 7, HWALL);
   set_World( 6, 7, HWALL);
   set_World( 7, 7, HWALL);
      
   set_World( 4, 6, HWALL);
   set_World( 6, 6, HWALL);
      
   set_World( 5, 4, HWALL);
   set_World( 6, 4, HWALL);
            
      // salvar configuracao do mundo
   save_World( fileName );
      
}//end decorateWorld()
      
      // Acoes
      
void turnRight()
{
   turnLeft();
   turnLeft();
   turnLeft();
}
      
void turnAround()
{
   turnLeft();
   turnLeft();
}
      
void turnAroundCornerLeft()
{
   move();
   turnRight();
   move();
   turnRight();
   move();
}
      
void limparArq( char* fileName){
   FILE* archive = fopen ( fileName, "w");
         
   fclose(archive);
}
      
      
void gravarPosicao( char* fileName )
{
   FILE* archive = fopen ( fileName, "a+");
   int x = xAvenue();
   int y = yStreet();
   int beepers = 6;
         
   IO_fprint ( archive, "%d", x );
   IO_fprint ( archive, "  |  ", x );
   IO_fprint ( archive, "%d", y );
   IO_fprint ( archive, "  |  ", y );
   IO_fprint ( archive, "%d\n", beepers );
         
   fclose(archive);
}
         
void execute( int option )
{  
      // executar a opcao de comando.
   switch ( option )
   {
      case 1: 
         up();
         break;          
      case 2: 
         mova(4); 
         break;          
      case 3: 
         right();           
         break;          
      case 4: 
         mova(6);           
         break;          
      case 5: 
         down();           
         break;          
      case 6: 
         mova( 3 );           
         break;          
      case 7: 
         down( );           
         break;          
      case 8: 
         mova( 5 );
         break;          
      case 9: 
         pick();
         break;
      case 10:             
         mova( 2 );
         break;
      case 11:             
         left();
         break;
      case 12:
         put();
         break;
      case 13:             
         turnLeft();           
         break;
      case 14:             
         turnOff();           
         break;
      case 15:             
         move();           
         break;
      case 16:
         mova( 7 );
         break;
      case 17:
         turnAround();
         break;
      case 18:
         turnAroundCornerLeft();
         break;
      case 19:
         gravarPosicao( "Tarefa0313.txt" );
         break;
      case 21:
         turnRight();
         break;
      default:// nenhuma das alternativas anteriores
         // comando invalido
         show_Error("ERROR: Invalid Command.");
   }// end switch
}// end execute
       
void playActions ( chars fileName )   
{    
           // definir dados       
   int   action;       
   FILE* archive = fopen ( fileName, "rt" ); 
 
           // repetir enquanto houver dados       
   fscanf ( archive, "%d", &action );   // tentar ler a primeira linha       
   while ( ! feof( archive ) )     // testar se nao encontrado o fim       
   {         
           // mostrar mais um comando            
      IO_printf ( "%d", action );            
      delay ( stepDelay );         
           // executar mais um comando            
      execute ( action );         
           // tentar ler a proxima linha            
      fscanf ( archive, "%d", &action );  // tentar ler a primeira linha       
   } // end for    
           // fechar o arquivo    
           // RECOMENDAVEL para a leitura       
   fclose ( archive );   
} // end playActions ( )
      
      
      // -------------------acao principal
      
      /**
        * Acao principal: Executar a tarefa descrita acima.
        */
        
int main(){
      // definir contexto
   world v_world;      ref_world ref_v_world = ref v_world;     world_now = ref v_world;
   robot v_robot;      ref_robot ref_v_robot = ref v_robot;     robot_now = ref v_robot;
   box   v_box  ;      ref_box   ref_v_box   = ref v_box  ;     box_now   = ref v_box  ;
      
      // criar mundo
   create_World ("Guia03_13_v0.1");
         
      // decorar o ambiente com um marcador
   decorateWorld("Guia0313.txt");
         
      // comandos para tornar o mundo visivel
   reset_World();
   set_Speed(1);
   read_World("Guia0313.txt");
         
      // colocar o robo com a configuracao inicial
   create_Robot( 1, 1, EAST, 0, "Karel");
         
      // executar acoes
   limparArq( "Tarefa0313.txt" );
   playActions( "Tarefa0313b.txt" );
      
      // preparar o encerramento
   close_World();
         
      // encerrar programa
   getchar();
   return(0);
} //end main
      
      /*
      
      ---------------------------------------------- testes 
  
      ---------------------------------------------- documentacao complementar
      
      ---------------------------------------------- notas / observacoes / comentarios 
       
 
      ---------------------------------------------- previsao de testes 
      
 
 
      ---------------------------------------------- historico 
 
      Versao     Data                                Modificacao   
      0.1        16/03                               esboco
 
      ---------------------------------------------- testes 
 
      Versao      Teste   
      0.1         01. ( OK )                  teste inicial
 
      */