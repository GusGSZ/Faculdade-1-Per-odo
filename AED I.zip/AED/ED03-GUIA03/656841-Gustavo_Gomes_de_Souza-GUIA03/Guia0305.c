/*
 Guia0305 - v0.5 - 17/03/2019
 Author: Gustavo Gomes de Souza
 
 Para compilar em uma janela de comandos (terminal):
 No Linux  : gcc -o Guia0305       ./Guia0305.c
 No Windows: gcc -o Guia0305.exe     Guia0305.c
 
 Para executar em uma janela de comandos (terminal):
 No Linux : ./Guia0305.c
 No Windows: Guia0305
*/

// lista de dependencias
#include "karel.h"
#include "io.h"
#include "mylib.h"

//definicoes

#define MAX_COMMANDS 500

// --------------------------- definicoes de metodos

/**
 decorateWorld - Metodo para preparar o cenario.
 @param fileName - nome do arquivo para guardar a descricao.
*/
void decorateWorld ( char* fileName )
{
// colocar um marcador no mundo
   set_World ( 4, 4, BEEPER );
// salvar a configuracao atual do mundo
   save_World( fileName );
} // decorateWorld ( )


/**
 * turnRight - Metodo para virar 'a direita.
 */
void turnRight( )
{
 // definir dado local
   int step = 0;
 // o executor deste metodo
 // deve virar tres vezes 'a esquerda
   for ( step = 1; step <= 3; step = step + 1 )
   {
      turnLeft( );
   } // end for
} // end turnRight( )


/**
 * moveN - Metodo para mover certa quantidade de passos.
 * @param steps - passos a serem dados.
 */
void moveN( int steps )
{
 // testar se a quantidade de passos e' maior que zero
   if ( steps > 0 )
   {
   // dar um passo
      move( );
   // tentar dar mais um passo
      moveN( steps-1 );
   } // end if
} // end moveN( )


/**
 * countCommands - Metodo para contar comandos de arquivo.
 * @return quantidade de comandos
 * @param fileName - nome do arquivo
 */
int countCommands( chars fileName )
{
 // definir dados
   int x = 0;
   int length = 0;
   FILE* archive = fopen ( fileName, "rt" );
 // repetir enquanto houver dados
   fscanf ( archive, "%d", &x );
   while ( ! feof( archive ) )
   {
   // contar mais um comando
      length = length + 1;
   // tentar ler a proxima linha
      fscanf ( archive, "%d", &x );
   } // end while
 // fechar o arquivo
   fclose( archive );
 // retornar resultado
   return (length);
} // end countCommands( )

/**
 * readCommands - Metodo para receber comandos de arquivo.
 * @return grupo formado por todos os comandos
 * @param filename - nome do arquivo
 */
int readCommands( int commands [ ], chars fileName )
{
 // definir dados
   int x = 0;
   int action = 0;
   int length = 0;
   int comandos = 0;
   FILE* archive = fopen ( fileName, "rt" );
 // obter a quantidade de comandos
   length = countCommands ( fileName );
 // criar um armazenador para os comandos
   if ( length < MAX_COMMANDS )
   {
   // repetir para a quantidade de comandos
      for ( x=0; x<length; x=x+1 )
      {
      // tentar ler a proxima linha
         fscanf ( archive, "%d", &action );
      // guardar um comando
      // na posicao (x) do armazenador
         commands [ x ] = action;
         comandos++;
      } // end for
   // fechar o arquivo
   // INDISPENSAVEL para a gravacao
      fclose( archive );
   } // end for
 // retornar quantidade de comandos lidos
   return ( length );
} // end readCommands ( )

/**
 * execute - Metodo para executar um comando.
 * @param action - comando a ser executado
 */
void execute( int option )
{  
      // executar a opcao de comando.
   switch ( option )
   {
      case 1: 
         up();
         break;          
      case 2: 
         mova(7); 
         break;          
      case 3: 
         right();           
         break;          
      case 4: 
         mova(2);           
         break;          
      case 5: 
         down();           
         break;          
      case 6: 
         mova( 3 );           
         break;          
      case 7: 
         down( );           
         break;          
      case 8: 
         mova( 4 );           
         break;          
      case 9: 
         pick();           
         break;
      case 10:             
         mova( 5 );           
         break;
      case 11:             
         left();           
         break;
      case 12:             
         put();           
         break;
      case 13:             
         turnLeft();           
         break;
      case 14:             
         turnOff();           
         break;
      case 15:             
         move();           
         break;
      default:// nenhuma das alternativas anteriores
         // comando invalido
         show_Error("ERROR: Invalid Command.");
   }// end switch
}// end execute

/**
 * doCommands - Metodo para executar comandos de arquivo.
 * @param length - quantidade de comandos
 * @param commands - grupo de comandos para executar
 */
void doCommands( int length, int commands [ ] )
{
 // definir dados
   int action = 0;
   int x = 0;
   
 // repetir para a quantidade de comandos
   for ( x = 0; x < length; x = x + 1 )
   {
   // executar esse comando
      execute( commands [ x ] );
      
   } // end for
} // end doCommands( )

/**
 * doTask - Metodo para executar comandos de arquivo.
 * @param fileName - nome do arquivo
 */
 void doTask( chars fileName )
 {
 // definir dados locais
 int quantidade = 0;
 int comandos [ MAX_COMMANDS ];
 // ler quantidade e comandos
 quantidade = readCommands ( comandos, "Tarefa0301.txt" );
 message [0] = '\0';
 sprintf ( message, "Commands = %d", quantidade );
 show_Text ( message );
 // executar comandos
 doCommands ( quantidade, comandos );
 } // end doTask( )



// --------------------------- acao principal

/**
 * Acao principal: executar a tarefa descrita acima.
 */
int main ( )
{
   int quantidade = 0;
   int comandos [MAX_COMMANDS];
   
// definir o contexto
   world v_world; ref_world ref_v_world = ref v_world; world_now = ref_v_world;
   robot v_robot; ref_robot ref_v_robot = ref v_robot; robot_now = ref_v_robot;
   box v_box ; ref_box ref_v_box = ref v_box ; box_now = ref_v_box ;
   
   
// criar o mundo
   create_World ( "Guia_03_05_v05" );
   
// criar o ambiente com um marcador
   decorateWorld( "Guia0305.txt" );
   
// comandos para tornar o mundo visivel
   reset_World( ); // limpar configuracoes
   set_Speed ( 1 ); // escolher velocidade
   read_World( "Guia0305.txt" ); // ler configuracao do ambiente
   
// colocar o robo no necessario
   create_Robot ( 1, 1, EAST, 0, "Karel" );
   
// executar acoes
   doTask( "Tarefa0301.txt" );

   
// preparar o encerramento
   close_World ( );
   
// encerrar o programa
   getchar ( );
   return ( 0 );
} // end main ( )


// ---------------------------------------------- testes

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

---------------------------------------------- previsao de testes

---------------------------------------------- historico
  Versao        Data                             Modificacao
  0.1           14/03                            esboco
  0.2           17/03
  0.3           17/03
  0.4           17/03
  0.5           17/03
 
---------------------------------------------- testes
  Versao        Teste
  0.1           01. ( OK )                     identificacao de programa
  0.2           01. ( OK )
  0.3           01. ( OK )
  0.4           01. ( OK )
  0.5           01. ( OK )
  
*/