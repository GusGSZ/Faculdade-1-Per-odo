      void up()
      {
      // um degrau para cima e 'a direita
      while(!facingNorth())
      {
      turnLeft();
      } // end while
      move();
      } // end up()
      
      void right()
      {
      while(!facingEast())
      {
      turnLeft();
      } // end while
      move();
      } // end right()
      
      void left()
      {
       while(!facingWest())
       {
        turnLeft();
       } // end while()
        move();
      } // end left()
      
      void down()
      {
      // um degrau para baixo e a' direita
      while(!facingSouth())
      {
      turnLeft();
      } // end while
      move();
      } // end down()
      
      void pick(){
        // pegar marcadores
        while(nextToABeeper())
        {
          pickBeeper();
        }
      }

      void put(){
        // por marcadores
        int x;
        for(x = 0; x < 9; x++)
        {
          if(beepersInBag())
           {
            putBeeper();
           } else {
            break;
           }
        }
      }

      void mova(int x)
      {
        int y;
        for (y = 0; y < x; y++)
        {
         move();
        }
      }