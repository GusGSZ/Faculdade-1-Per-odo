/*
 Guia0302 - v0.2 - 14/03/2019
 Author: Gustavo Gomes de Souza
 
 Para compilar em uma janela de comandos (terminal):
 No Linux  : gcc -o Guia0302       ./Guia0302.c
 No Windows: gcc -o Guia0302.exe     Guia0302.c
 
 Para executar em uma janela de comandos (terminal):
 No Linux : ./Guia0302.c
 No Windows: Guia0302
*/
// lista de dependencias
#include "karel.h"
#include "io.h"

//definicoes

#define MAX_COMMANDS 500

// --------------------------- definicoes de metodos

/**
 decorateWorld - Metodo para preparar o cenario.
 @param fileName - nome do arquivo para guardar a descricao.
*/
void decorateWorld ( char* fileName )
{
// colocar um marcador no mundo
   set_World ( 4, 4, BEEPER );
// salvar a configuracao atual do mundo
   save_World( fileName );
} // decorateWorld ( )


/**
 * turnRight - Metodo para virar 'a direita.
 */
void turnRight( )
{
 // definir dado local
   int step = 0;
 // o executor deste metodo
 // deve virar tres vezes 'a esquerda
   for ( step = 1; step <= 3; step = step + 1 )
   {
      turnLeft( );
   } // end for
} // end turnRight( )


/**
 * moveN - Metodo para mover certa quantidade de passos.
 * @param steps - passos a serem dados.
 */
void moveN( int steps )
{
 // testar se a quantidade de passos e' maior que zero
   if ( steps > 0 )
   {
   // dar um passo
      move( );
   // tentar dar mais um passo
      moveN( steps-1 );
   } // end if
} // end moveN( )


/**
 * countCommands - Metodo para contar comandos de arquivo.
 * @return quantidade de comandos
 * @param fileName - nome do arquivo
 */
int countCommands( chars fileName )
{
 // definir dados
   int x = 0;
   int length = 0;
   FILE* archive = fopen ( fileName, "rt" );
 // repetir enquanto houver dados
   fscanf ( archive, "%d", &x );
   while ( ! feof( archive ) )
   {
   // contar mais um comando
      length = length + 1;
   // tentar ler a proxima linha
      fscanf ( archive, "%d", &x );
   } // end while
 // fechar o arquivo
   fclose( archive );
 // retornar resultado
   return (length);
} // end countCommands( )

/**
 * readCommands - Metodo para receber comandos de arquivo.
 * @return grupo formado por todos os comandos
 * @param filename - nome do arquivo
 */
int readCommands( int commands [ ], chars fileName )
{
 // definir dados
   int x = 0;
   int action = 0;
   int length = 0;
   int comandos = 0;
   FILE* archive = fopen ( fileName, "rt" );
 // obter a quantidade de comandos
   length = countCommands ( fileName );
 // criar um armazenador para os comandos
   if ( length < MAX_COMMANDS )
   {
   // repetir para a quantidade de comandos
      for ( x=0; x<length; x=x+1 )
      {
      // tentar ler a proxima linha
         fscanf ( archive, "%d", &action );
      // guardar um comando
      // na posicao (x) do armazenador
         commands [ x ] = action;
         comandos++;
      } // end for
   // fechar o arquivo
   // INDISPENSAVEL para a gravacao
      fclose( archive );
   } // end for
 // retornar quantidade de comandos lidos
   return ( length );
} // end readCommands ( )



// --------------------------- acao principal

/**
 * Acao principal: executar a tarefa descrita acima.
 */
int main ( )
{
   int quantidade = 0;
   int comandos [MAX_COMMANDS];
   
// definir o contexto
   world v_world; ref_world ref_v_world = ref v_world; world_now = ref_v_world;
   robot v_robot; ref_robot ref_v_robot = ref v_robot; robot_now = ref_v_robot;
   box v_box ; ref_box ref_v_box = ref v_box ; box_now = ref_v_box ;
   
   
// criar o mundo
   create_World ( "Guia_03_02_v01" );
   
// criar o ambiente com um marcador
   decorateWorld( "Guia0302.txt" );
   
// comandos para tornar o mundo visivel
   reset_World( ); // limpar configuracoes
   set_Speed ( 1 ); // escolher velocidade
   read_World( "Guia0302.txt" ); // ler configuracao do ambiente
   
// colocar o robo no necessario
   create_Robot ( 1, 1, EAST, 0, "Karel" );
   
// executar acoes
   quantidade = readCommands ( comandos, "Tarefa0301.txt" );
   message [0] = '\0';        // limpar a mensagem
   sprintf ( message, "Commands = %d", quantidade );
   show_Text ( message );
   
// preparar o encerramento
   close_World ( );
   
// encerrar o programa
   getchar ( );
   return ( 0 );
} // end main ( )


// ---------------------------------------------- testes

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

---------------------------------------------- previsao de testes

---------------------------------------------- historico
  Versao        Data                             Modificacao
  0.1           14/03                            esboco
  0.2           17/03
 
---------------------------------------------- testes
  Versao        Teste
  0.1           01. ( OK )                     identificacao de programa
  0.2           01. ( OK )
  
*/