    /*
    Exemplo0218 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0218        exemplo0218.c    
    Windows: gcc -o exemplo0218.exe    exemplo0218.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0218
    Windows:    exemplo0218  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero x e' par e positivo e se o numero y e' impar e negativo
    
    void maimenigu( double x, double y )
    {
      if ( x > y )
      {
         IO_printf("%s %lf e' maior que %lf.", "\n", x, y );
      } 
      else 
      {
         if ( x < y )
         {
            IO_printf("%s %lf e' menor que %lf.", "\n", x, y );
         }
         else
         {
            if ( x == y )
            {
               IO_printf("%s %lf e' igual a %lf.", "\n", x, y );
            }
         }
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    double x = 0.0;   // definir variavel com valor inicial
    double y = 0.0;   // definir variavel com valor inicial
 
    // identificar     
    IO_id ( "EXEMPLO0218 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readdouble ( "Entrar com um valor real: " ); 
    y = IO_readdouble ( "Entrar com outro valor real: " );
 
    // executar metodo
    maimenigu(x, y); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); 
    } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  20 e 14
    b.)  78 e 99
    c.)  2019 e 2019
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor real: 20
        Entrar com outro valor real: 14
        20.000000 e' maior que 14.000000.
        
    b.) Entrar com um valor real: 78
        Entrar com outro valor real: 99
        78.000000 e' menor que 99.000000.

    c.) Entrar com um valor real: 2019
        Entrar com outro valor real: 2019
        2019.000000 e' igual a 2019.000000.
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */