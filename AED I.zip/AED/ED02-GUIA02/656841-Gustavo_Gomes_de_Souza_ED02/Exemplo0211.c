    /*
    Exemplo0211 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0211        exemplo0211.c    
    Windows: gcc -o exemplo0211.exe    exemplo0211.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0211    
    Windows:    exemplo0211  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero e par ou impar
    void par( int x )
    {
      if ( x%2 == 0 )
      {
        IO_printf("%s O numero %d e par.", "", x); 
      }
      else
      {
        IO_printf("%s O numero %d e impar", "", x);
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    int x = 0;   // definir variavel com valor inicial 
 
    // identificar     
    IO_id ( "EXEMPLO0211 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readint ( "Entrar com um valor inteiro: " ); 
 
    // executar metodo
    par(x); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  1
    b.)  0
    c.) -2
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor inteiro: 1
        O numero 1 e impar.
        
    b.) Entrar com um valor inteiro: 0
        O numero 0 e par.
        
    c.) Entrar com um valor inteiro: -2
        O numero -2 e par.
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */