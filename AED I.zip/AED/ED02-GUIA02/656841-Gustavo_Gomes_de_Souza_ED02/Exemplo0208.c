    /*
    Exemplo0208 - v0.8 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0208        exemplo0208.c    
    Windows: gcc -o exemplo0208.exe    exemplo0208.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0208
    Windows:    exemplo0208
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    char x = '_';   // definir variavel com valor inicial 
 
    // identificar     
    IO_id ( "EXEMPLO0208 - Programa - v0.8" ); 
 
    // ler do teclado     
    x = IO_readchar ( "Entrar com um caractere [0, A, a]: " ); 
 
    // testar valor     
    switch ( x )
    {
      case '0':
        IO_printf ( "%s (%c=%d)\n", "Valor igual do simbolo zero", x,x );
        break;
      case 'A':
        IO_printf ( "%s (%c=%d)\n", "Valor igual 'a letra A", x,x );
        break;
      case 'a':
        IO_printf ( "%s (%c=%d)\n", "Valor igual 'a letra a", x,x );
        break;
      default:
        IO_printf ( "%s (%c=%d)\n", "Valor diferente das opcoes [0, A, a]", x,x );
    } // fim switch
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.) 0
    b.) A
    c.) a
    d.) 1
        
    ---------------------------------------------- resultados
    
    a.) Entrar com um caractere: 0
        Valor igual do simbolo zero (0=48)
        
    b.) Entrar com um caractere: A
        Valor igual 'a letra A (A=65)
        
    c.) Entrar com um caractere: a
        Valor igual 'a letra a (a=97)
            
    d.) Entrar com um caractere: 1
        Valor diferente das opcoes [0, A, a] (1=49)
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
    0.2       06/03
    0.3       06/03
    0.4       06/03
    0.5       06/03
    0.6       06/03
    0.7       06/03
    0.8       06/03
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa
    0.2       01. ( OK )                           teste if/else/and
    0.3       01. ( OK )                           teste if/else/if/else/and
    0.4       01. ( OK )                           teste if/else/if/else/and com double e intervalo
    0.5       01. ( OK )                           teste if/else/if/else/and com char
    0.6       01. ( OK )                           teste if/else/or
    0.7       01. ( OK )                           teste not
    0.8       01. ( OK )                           teste switch
    
    */