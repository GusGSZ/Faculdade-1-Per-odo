    /*
    Exemplo0212 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0212        exemplo0212.c    
    Windows: gcc -o exemplo0212.exe    exemplo0212.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0212
    Windows:    exemplo0212  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero e par ou impar
    void par( int x )
    {
      if ( x%2 == 0 && x < 100 )
      {
        IO_printf("%s O numero %d e' par e menor que 100.", "", x); 
      }
      else
      {
        if ( x%2 != 0 && x > 100 ) {
           IO_printf("%s O numero %d e' impar e maior que 100", "", x);
        }
      } 
        
        if ( x == 100)
        {
           IO_printf("%s O numero %d e' par, igual a 100", "", x);
        }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    int x = 0;   // definir variavel com valor inicial 
 
    // identificar     
    IO_id ( "EXEMPLO0212 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readint ( "Entrar com um valor inteiro: " ); 
 
    // executar metodo
    par(x); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  1
    b.)  100
    c.) -2
    d.) 201
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor inteiro: 1
        
    b.) Entrar com um valor inteiro: 100
        O numero e' par, igual a 100.
        
    c.) Entrar com um valor inteiro: -2
        O numero -2 e' par e menor que 100.
        
    d.) Entrar com um valor inteiro: 201
        O numero 201 e' impar e maior que 100.
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */