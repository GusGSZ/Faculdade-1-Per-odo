    /*
    Exemplo0219 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0219        exemplo0219.c    
    Windows: gcc -o exemplo0219.exe    exemplo0219.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0219
    Windows:    exemplo0219  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero x e' par e positivo e se o numero y e' impar e negativo
    
    void maimenigu( double x, double y, double z )
    {
      if ( y != z ) 
      {
         if ( ( x > y && x < z ) || ( x < y && x > z ) )
         {
            IO_printf ( "%s %lf esta' entre %lf e %lf", "", x, y, z );
         }
         else
         {
            IO_printf ( "%s %lf nao esta' entre %lf e %lf", "", x, y, z );
         }
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    double x = 0.0;   // definir variavel com valor inicial
    double y = 0.0;   // definir variavel com valor inicial
    double z = 0.0;
 
    // identificar     
    IO_id ( "EXEMPLO0219 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readdouble ( "Entrar com um valor real: " ); 
    y = IO_readdouble ( "Entrar com outro valor real: " );
    z = IO_readdouble ( "Entrar com mais um valor real: " );
    
    // executar metodo
    maimenigu(x, y, z); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); 
    } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  20, 14 e 30
    b.)  78, 88 e 99
    c.)  2019, 2000 e 2100
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor real: 20
        Entrar com outro valor real: 14
        Entrar com mais um valor real: 30
        20.000000 esta' entre 14.000000 e 30.000000
        
    b.) Entrar com um valor real: 78
        Entrar com outro valor real: 88
        Entrar com mais um valor real: 99
        78.000000 nao esta' entre 88.000000 e 99.000000

    c.) Entrar com um valor real: 2019
        Entrar com outro valor real: 2000
        Entrar com mais um valor real: 2100
        2019.000000 esta' entre 2000.000000 e 2100.000000
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */