    /*
    Exemplo0206 - v0.6 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0206        exemplo0206.c    
    Windows: gcc -o exemplo0206.exe    exemplo0206.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0206
    Windows:    exemplo0206
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    char x = '_';   // definir variavel com valor inicial 
 
    // identificar     
    IO_id ( "EXEMPLO0206 - Programa - v0.6" ); 
 
    // ler do teclado     
    x = IO_readchar ( "Entrar com um caractere: " ); 
 
    // testar valor     
    if (( 'a' <= x && x <= 'z' ) || ( 'A' <= x && x <= 'Z' ))
    {        
      IO_printf ( "%s (%c)\n", "Letra.", x );     
    }
    else
    {        
      IO_printf ( "%s (%c)\n", "Valor diferente de letra.", x ); 
    } // fim se 
 
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.) 0
    b.) 1
    c.) 10
    d.) -1
    e.) 100
    f.) A
    g.) h
        
    ---------------------------------------------- resultados
    
    a.) Entrar com um caractere: 0
        Valor diferente de letra. (0)
        
    b.) Entrar com um caractere: 1
        Valor diferente de letra. (1)
        
    c.) Entrar com um caractere: 10
        Valor diferente de letra. (10)
            
    d.) Entrar com um caractere: -1
        Valor diferente de letra. (-1)
        
    e.) Entrar com um caractere: 100
        Valor diferente de letra. (100)
        
    f.) Entrar com um caractere: A
        Letra. (A)
        
    g.) Entrar com um caractere: h
        Letra. (h)
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
    0.2       06/03
    0.3       06/03
    0.4       06/03
    0.5       06/03
    0.6       06/03
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa
    0.2       01. ( OK )                           teste if/else/and
    0.3       01. ( OK )                           teste if/else/if/else/and
    0.4       01. ( OK )                           teste if/else/if/else/and com double e intervalo
    0.5       01. ( OK )                           teste if/else/if/else/and com char
    0.6       01. ( OK )                           teste if/else/or
    
    */