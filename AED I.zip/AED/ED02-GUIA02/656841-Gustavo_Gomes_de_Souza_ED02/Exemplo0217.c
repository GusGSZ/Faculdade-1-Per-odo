    /*
    Exemplo0217 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0217        exemplo0217.c    
    Windows: gcc -o exemplo0217.exe    exemplo0217.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0217
    Windows:    exemplo0217  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero x e' par e positivo e se o numero y e' impar e negativo
    
    void parimpar( int x, int y )
    {
      if ( x%2 == 0 && x > 0 )
      {
        IO_printf("%s O numero %d e' par e positivo.", "\n", x );
      }
      else
      {
        IO_printf("%s O numero %d nao e' par ou nao e' positivo.", "\n", x );
      }
      
      if ( y%2 != 0 && y < 0 )
      {
        IO_printf("%s O numero %d e' impar e negativo.", "\n", y );
      }
      else
      {
        IO_printf("%s O numero %d nao e' impar ou nao e negativo.", "\n", y );
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    int x = 0;   // definir variavel com valor inicial
    int y = 0;   // definir variavel com valor inicial
 
    // identificar     
    IO_id ( "EXEMPLO0217 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readint ( "Entrar com um valor inteiro: " ); 
    y = IO_readint ( "Entrar com um valor inteiro: " );
 
    // executar metodo
    parimpar(x, y); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); 
    } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  10 e -11
    b.)  3 e -4
    c.)  -12 e 23
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor inteiro: 10
        Entrar com um valor inteiro: -11
        O numero 10 e' par e positivo.
        O numero -11 e' impar e negativo.
        
    b.) Entrar com um valor inteiro: 3
        Entrar com um valor inteiro: -4
        O numero 3 nao e' par ou nao e' positivo.
        O numero -4 nao e' impar ou nao e negativo.

        
    c.) Entrar com um valor inteiro: -12
        Entrar com um valor inteiro: 23
        O numero -12 nao e' par ou nao e' positivo.
        O numero 23 nao e' impar ou nao e negativo.
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */