    /*
    Exemplo0216 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0216        exemplo0216.c    
    Windows: gcc -o exemplo0216.exe    exemplo0216.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0216
    Windows:    exemplo0216  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero x e par e o numero y e impar
    
    void parimpar( int x, int y )
    {
      if ( x%2 == 0 )
      {
        IO_printf("%s O numero %d e' par.", "\n", x );
      }
      else
      {
        IO_printf("%s O numero %d nao e' par.", "\n", x );
      }
      
      if ( y%2 != 0 )
      {
        IO_printf("%s O numero %d e' impar.", "\n", y );
      }
      else
      {
        IO_printf("%s O numero %d nao e' impar.", "\n", y );
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    int x = 0;   // definir variavel com valor inicial
    int y = 0;   // definir variavel com valor inicial
 
    // identificar     
    IO_id ( "EXEMPLO0216 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readint ( "Entrar com um valor inteiro: " ); 
    y = IO_readint ( "Entrar com outro valor inteiro: " );
 
    // executar metodo
    parimpar(x, y); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); 
    } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  23 e 42
    b.)  110 e 53
    c.)  12 e 24
    d.)  69 e 97
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor inteiro: 23
        Entrar com outro valor inteiro: 42
        O numero 23 nao e' par.
        o numero 42 nao e' impar.
        
    b.) Entrar com um valor inteiro: 110
        Entrar com outro valor inteiro: 53
        O numero 110 e' par.
        o numero 53 e' impar.
        
    c.) Entrar com um valor inteiro: 12
        Entrar com outro valor inteiro: 24
        O numero 110 e' par.
        o numero 53 nao e' impar.
        
    d.) Entrar com um valor inteiro: 69
        Entrar com outro valor inteiro: 97
        O numero 110 nao e' par.
        o numero 53 e' impar.

        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */