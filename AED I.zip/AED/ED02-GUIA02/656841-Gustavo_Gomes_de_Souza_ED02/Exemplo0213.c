    /*
    Exemplo0213 - v0.1 - 06/03/2019
    Author: Gustavo Gomes de Souza     
    
    Para compilar em terminal (janela de comandos):    
    Linux  : gcc -o exemplo0213        exemplo0213.c    
    Windows: gcc -o exemplo0213.exe    exemplo0213.c 
 
    Para executar em terminal (janela de comandos):    
    Linux  :  ./exemplo0213
    Windows:    exemplo0213  
    */ 
    
    // dependencias 
    #include "IO.h"  // para definicoes proprias 
    
    // Metodo para testar se o numero pertence ao intervalo (25:75)
    
    void interv( int x )
    {
      if ( x > 25 && x < 75 )
      {
        IO_printf("%s O numero %d pertence ao intervalo (25:75).", "", x); 
      }
      else
      {
        IO_printf("%s O numero %d nao pertence ao intervalo (25:75)", "", x);
      }
    }
 
    /*   Funcao principal.   
    @return codigo de encerramento   
    @param argc - quantidade de parametros na linha de comandos   
    @param argv - arranjo com o grupo de parametros na linha de comandos 
    */ 
    
    int main ( ) 
    {  // definir dado     
    int x = 0;   // definir variavel com valor inicial 
 
    // identificar     
    IO_id ( "EXEMPLO0213 - Programa - v0.1" ); 
 
    // ler do teclado     
    x = IO_readint ( "Entrar com um valor inteiro: " ); 
 
    // executar metodo
    interv(x); 
    
    // encerrar    
    IO_pause ( "Apertar ENTER para terminar" );     
    return ( 0 ); } // fim main( ) 
    
    /* 
    
    ---------------------------------------------- documentacao complementar 
 
    ---------------------------------------------- notas / observacoes / comentarios 
 
    
    ---------------------------------------------- previsao de testes 
 
    a.)  25
    b.)  100
    c.)  63
    
    ---------------------------------------------- resultados
    
    a.) Entrar com um valor inteiro: 1
        O numero 25 nao pertence ao intervalo (25:75)
        
    b.) Entrar com um valor inteiro: 1
        O numero 100 nao pertence ao intervalo (25:75)
        
    c.) Entrar com um valor inteiro: 1
        O numero 63 pertence ao intervalo (25:75)
        
    ---------------------------------------------- historico 
 
    Versao    Data                                 Modificacao   
    0.1       06/03                                esboco 
 
    ---------------------------------------------- testes 
 
    Versao    Teste   
    0.1       01. ( OK )                           identificacao de programa 
 
    */