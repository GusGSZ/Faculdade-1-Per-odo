/*
 killthislove.hpp - v0.1 - 30/05/2019
 Author: Gustavo Gomes de Souza
*/

// ----------------------------------------------- definicoes globais
#ifndef _KTL_H_
#define _KTL_H_

// dependencias
#include <iostream>
using std::cin ; // para entrada
using std::cout; // para saida
using std::endl; // para mudar de linha

#include <iomanip>
using std::setw; // para definir espacamento

#include <string>
using std::string; // para cadeia de caracteres

#include <fstream>
using std::ofstream; // para gravar arquivo
using std::ifstream ; // para ler arquivo

#include <ctime>
#include <cstdlib>

template <typename KTL>

class Lisa
{
   private:
      int tamanho;
      KTL* dados;
   
   public:
   
   Lisa ( int tam )
   {
      tamanho = tam;
      dados = new KTL[tam];
   }
   
   void liberar ( )
   {
      if ( dados != NULL )
      {
         delete (dados);
         dados = NULL;
      }
   }
   
   void set ( int posicao, int valor )
   {
      if ( posicao >= 0 && posicao <= tamanho )
      {
         dados[posicao] = valor;
      }// fim if( )
   }// fim set( )
   
   KTL get ( int posicao )
   {
      KTL valor = 0; // retorna valor do tipo dependencia ( KTL )
      if ( posicao >= 0 && posicao <= tamanho )
      {
         valor = dados [posicao];
      }// fim if( )
      
      return ( valor );
   }// fim get ( )
   
   void mostrar ( )
   {
      cout << endl;
      for ( int x = 0; x < tamanho; x++ )
      {
         cout << setw ( 2 ) << x << ":" << setw ( 3 ) << dados[x] << endl;
      }// fim for( )
   }// fim mostrar ( )
   
   void ler ( )
   {
      cout << endl;
      for ( int i = 0; i < tamanho; i++ )
      {
         cout << setw ( 2 ) << i << ":" << setw( 2 ) << "";
         cin >> dados[i];
      }// fim for( )
      cout << endl;
   }// fim ler ( )
   
   void preencherRand ( int inf, int sup )
   {
      int aleatorio = 0;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         aleatorio = rand()%(sup-inf+1) + inf;
         dados[i] = aleatorio;
      }// fim for ( )
      
   }// fim preencherRand ( )
   
   void gravar ( string fileName )
   {
      // declaracao tipo de entrada para arquivo
      ofstream arquivo;
      // abrir arquivo
      arquivo.open ( fileName );
      //salvar tamanho em arquivo
      arquivo << tamanho << endl;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         //salvar dados em arquivo
         arquivo << dados[i] << endl;
      }// fim for( )
      
      //fechar arquivo
      arquivo.close ( );
   }// fim gravar( )
   
   void lerArq ( string fileName )
   {
      //declaracao de tipo arquivo saida
      ifstream arquivo;
      //declarar dados
      int tam = 0;
      // abrir arquivo
      arquivo.open( fileName );
      // ler tamanho da primeira linha do arquivo
      arquivo >> tam;
      
      if ( tam == 0 )
      {
         cout << "\nERROR: Tamanho invalido.\n" << endl;
      }
      else
      {
         //guardar a quantidade de dados
         tamanho = tam;
         //reservar espaco
         dados = new KTL[tamanho];
         //ler dados
         for ( int i = 0; i < tamanho; i++ )
         {
            arquivo >> dados[i];
         }// fim for( )
      }// fim if-else( )
      //fechar arquivo
      arquivo.close ( );
   }
   
   int tam ( string fileName )
   {
      //declaracao de tipo arquivo saida
      ifstream arquivo;
      //declarar dados
      int tam = 0;
      // abrir arquivo
      arquivo.open( fileName );
      // ler tamanho da primeira linha do arquivo
      arquivo >> tam;
      //fechar arquivo
      arquivo.close ( );
      // retornar valor
      return tam;
   }
   
   int acharMaior ( )
   {
      // definicao de dados
      int maior = 0;
      
      // procurar maior valor em arranjo
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] > maior )
            maior = dados[i];
         // fim if ( )
      }// fim for ( )
      
      // retornar maior valor
      return ( maior );
   }
   
   int acharMenor ( )
   {
      // definicao de dados
      int menor = dados[0];
      
      // procurar menor valor em arranjo
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] < menor )
            menor = dados[i];
         // fim if ( )
      }// fim for( )
      
      //retornar menor valor do arranjo
      return ( menor );
   }
   
   int somar ( )
   {
      int soma = 0;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         soma = soma + dados[i];
      }
      
      return soma;
   }
   
   double media ( )
   {
      int soma = 0;
      double media = 0.0; 
      
      for ( int i = 0; i < tamanho; i++ )
      {
         soma = soma + dados[i];
      }
      
      media = (double)soma/(double)tamanho;
      
      return media;
   }
   
   bool zeros ( )
   {
      bool zero = true;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] != 0 )
            zero = false;
      }
      
      return zero;
   } // fim zeros ( )
   
   bool ordenado ( )
   {
      // definicao de dados
      int maior = 0;
      int menor = 0;
      int tf = 0;
      
      maior = dados[0];
      for ( int i = 1; i < (tamanho-1); i++ )
      {
         menor = dados[i];
         if ( maior < menor )
         {
            tf++;
         }
         else
         {
            maior = menor;
         }
         
      }// fim for ( )
      
      // retorno booleano
      if ( tf > 0 )
         return false;
      else
         return true;
      
   } // fim ordenado ( )
   
   bool procurado ( int procurado, int posini, int posfin )
   {
      int a = 0;
      
      for ( int i = posini; i <= posfin; i++ )
      {
         if ( dados[i] == procurado )
         {
            a++;
         }
      }
      
      if ( a != 0 )
         return true;
      else
         return false;
   }
   
   Lisa escalar ( int constante, Lisa arranjo )
   {
      for ( int i = 0; i < arranjo.tamanho; i++ )
      {
         arranjo.dados[i] = arranjo.dados[i] * constante;
      }
      
      return ( arranjo );
   }
   
   void decrescente ( )
   {
      int aux = 0;
      int aux2 = 0;
      int cont = 0;
      
      do
      {
         cont = 0;
         
         for ( int i = (tamanho-1); i > 0; i-- )
         {  
            if ( dados[i] > dados[i-1] )
            {
               aux  = dados[i];
               aux2 = dados[i-1];
               dados[i]   = aux2;
               dados[i-1] = aux;
            }
         }
         
         for ( int i = (tamanho-1); i > 0; i-- )
         {  
            if ( dados[i] > dados[i-1] )
            {
               cont++;
            }
         }
         
      }while(cont > 0);
         
      mostrar( );
   }
   
   int tam ( Lisa vetor )
   {
      int tam = tamanho;
      return tam;
   }
   
   /**
      operador (!=).
   */
   bool operator!= ( const Lisa <KTL> jennie )
   {
      int i = 0;
      int t = 0;
      
      if ( tamanho <= 0 || tamanho != jennie.tamanho )
      {
         cout << "Tamanhos diferentes." << endl;
         return true;
      }
      else
      {
         while ( i < this->tamanho )
         {
            if ( dados[i] != jennie.dados[i] )
               t++;
            i++;
         }
         
         if ( t != 0 )
         {
            return true;
         }
         else
         {
            return false;
         }
      }
   }
   
   /**
      operador (-).
   */
   Lisa& operator- ( const Lisa <KTL> rose )
   {
      static Lisa <KTL> soma ( rose.tamanho );
      
      if ( rose.tamanho <= 0 || tamanho != rose.tamanho )
      {
         cout << "Tamanho invalido ou diferente." << endl;
      }
      else
      {
         for ( int i = 0; i < this->tamanho; i++ )
         {
            soma.dados[i] = dados[i] - rose.dados[i];
         }
      }
      
      return (soma);
   }
   
};
#endif