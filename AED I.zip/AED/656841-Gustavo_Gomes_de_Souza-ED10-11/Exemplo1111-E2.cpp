/*
 Exemplo1111-20 - v0.1 - 30/05/2019 - 31/05/2019
 Matricula: 656841
 Author: Gustavo Gomes de Souza
*/

// dependencias
#include <iostream> // std::cin, std::cout, std:endl
#include <limits> // std::numeric_limits
#include <string> // para cadeias de caracteres

// ----------------------------------------------- definicoes globais
void pause ( std::string text )
{
   std::string dummy;
   std::cin.clear ( );
   std::cout << std::endl << text;
   std::cin.ignore( );
   std::getline(std::cin, dummy);
   std::cout << std::endl << std::endl;
} // end pause ( )

using namespace std;

void idMetodo ( string x )
{
   cout << endl << "EXEMPLO1111-E2 - Method" << x << " - v0.1" << endl;
   cout << "Matricula: 656841" << endl;
   cout << "Autor: Gustavo Gomes de Souza\n" << endl;
}

// ----------------------------------------------- classes
#include "killthislove.hpp"

// ----------------------------------------------- metodos

/**
 Method00 - nao faz nada.
*/
void method00 ( )
{
   // nao faz nada
} // fim method00 ( )

/**
 Method01 - Mostrar certa quantidade de valores.
*/
void method01 ( )
{
// identificar
   idMetodo ( "01" );
   
// definir dados
   int n = 0;
   int inf = 0;
   int sup = 0;
   
// receber dados
   cout << "Quantos numeros serao gravados?" << endl;
   cin >> n;
   Lisa <int> vetor ( n );
   
   cout << "Qual o valor inferior do intervalo?" << endl;
   cin >> inf;
   
   cout << "Qual o valor superior do intervalo?" << endl;
   cin >> sup;
   
// preencher arranjo com valores aleatorios
   vetor.preencherRand ( inf, sup );
// mostrar arranjo
   vetor.mostrar( );
// gravar arranjo em arquivo
   vetor.gravar( "DADOS.txt" );
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para continuar." );
} // fim method01 ( )

/**
 Method02.
*/
void method02 ( )
{
// identificar
   idMetodo ( "02" );
    
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// saida de dados
   cout << "O maior valor do arranjo e': " << vetor.acharMaior() << endl;
// reciclar espaco
   vetor.liberar( );
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method02 ( )

/**
 Method03.
*/
void method03 ( )
{
// identificar
   idMetodo ( "03" );
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// saida de dados
   cout << "O menor valor do arranjo e': " << vetor.acharMenor() << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method03 ( )

/**
 Method04.
*/
void method04 ( )
{
// identificar
   idMetodo ( "04" );
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// saida de dados
   cout << "A soma dos valores do arranjo e': " << vetor.somar() << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method04 ( )

/**
 Method05.
*/
void method05 ( )
{
// identificar
   idMetodo ( "05" );
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arquivo
   vetor.mostrar( );
// saida de dados
   cout << "A media dos valores do arranjo e': " << vetor.media() << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method05 ( )

/**
 Method06.
*/
void method06 ( )
{
// identificar
   idMetodo ( "06" );
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// condicao para saida de dados
   if ( vetor.zeros ( ) )
      cout << "O arranjo so' tem zeros." << endl;
   else
      cout << "O arranjo tem outros valores alem de zero." << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method06 ( )

/**
 Method07.
*/
void method07 ( )
{
// identificar
   idMetodo ( "07" );
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// condicao para saida de dados
   if ( vetor.ordenado ( ) )
      cout << "O arranjo esta' ordenado." << endl;
   else
      cout << "O arranjo nao esta' ordenado." << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method07 ( )

/**
 Method08.
*/
void method08 ( )
{
// identificar
   idMetodo ( "08" );
   
// definir dados
   int procurado = 0;
   int posini = 0;
   int posfin = 0;
   
// definir arranjo
   Lisa <int> vetor ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
   
// entrada de dados
   cout << "Qual o valor procurado?" << endl;
   cin >> procurado;
   
   cout << "Entre quais posicoes esse valor sera' procurado?" << endl;
   
   do{
      cin >> posini;
      if ( posini < 0 )
         cout << "Posicao invalida." << endl;
   }while (posini < 0);
   
   cout << "e" << endl;
   
   do{
   cin >> posfin;
   if ( posfin >= vetor.tam(vetor) || posfin < posini )
         cout << "Posicao invalida." << endl;
   }while (posfin >= vetor.tam(vetor) || posfin < posini);
// mostrar arranjo
   vetor.mostrar( );
// condicao para saida de dados
   if ( vetor.procurado ( procurado, posini, posfin ) )
      cout << "O valor existe entre as posicoes indicadas." << endl;
   else
      cout << "O valor nao existe entre as posicoes indicadas." << endl;
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method08 ( )

/**
 Method09.
*/
void method09 ( )
{
// identificar
   idMetodo ( "09" );
   
// definir dados
   int constante = 0;
// entrada de dados
   cout << "Qual o valor procurado?" << endl;
   cin >> constante;
// definir arranjos
   Lisa <int> vetor ( 5 );
   Lisa <int> vetorescalado ( 5 );
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
// mostrar arranjo
   vetor.mostrar( );
// escalar arranjo
   vetorescalado = vetor.escalar ( constante, vetor );
// mostrar arranjo escalado
   vetorescalado.mostrar( );
// reciclar espaco
   vetor.liberar( );
   vetorescalado.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para terminar." );
} // fim method09 ( )

/**
 Method10.
*/
void method10 ( )
{
// identificar
   idMetodo ( "10" );
   
// definir arranjo
   Lisa <int> vetor ( 5 );
   
// ler arranjo de arquivo
   vetor.lerArq ( "DADOS.txt" );
   
// mostrar arranjo
   vetor.mostrar( );
   
// ordenar arranjo em ordem decrescente
   vetor.decrescente ( );
   
// mostrar arranjo em ordem decrescente
   vetor.mostrar( );
   
// reciclar espaco
   vetor.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para terminar." );
} // fim method10 ( )

/**
 MethodE1.
*/
void methodE1 ( )
{
// identificar
   idMetodo ( "E1" );
   
// definir arranjos
   Lisa <int> vetor ( 5 );
   Lisa <int> vetor2 ( 5 );
   
// ler arranjos de arquivo
   vetor.lerArq ( "DADOS.txt" );
   vetor2.lerArq ( "DADOS1.txt" );
   
// mostrar arranjos
   vetor.mostrar( );
   vetor2.mostrar( );
   
// testar se ha' algum valor diferente entre dois arranjos
   if ( (vetor!=vetor2) )
      cout << "Os arranjos sao diferentes em alguma posicao." << endl;
   else
      cout << "Os arranjos sao iguais." << endl;
   
// reciclar espaco
   vetor.liberar( );
   vetor2.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

/**
 MethodE2.
*/
void methodE2 ( )
{
// identificar
   idMetodo ( "E2" );
   
// definir arranjos
   Lisa <int> vetor ( 5 );
   Lisa <int> vetor2 ( 5 );
   Lisa <int> vetorSub ( 5 );
   
// ler arranjos de arquivo
   vetor.lerArq ( "DADOS.txt" );
   vetor2.lerArq ( "DADOS1.txt" );
   
// mostrar arranjos
   vetor.mostrar( );
   vetor2.mostrar( );
   
// subtrair arranjos
   vetorSub = (vetor-vetor2);
   
// mostrar arranjo com valores somados
   vetorSub.mostrar( );
   
// reciclar espaco
   vetor.liberar( );
   vetor2.liberar( );
   vetorSub.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

/**
 criarVetor - Criar vetor e gravar em arquivo.
*/
void criarVetor ( )
{
// definir dados
   string fileName = "";
   int tam = 0;
   
// entrada de dados
   cout << "Em qual arquivo serao gravados os valores?" << endl;
   cin >> fileName;
   
   cout << "Quantos numeros serao gravados no arranjo?" << endl;
   cin >> tam;
   
// definir arranjo
   Lisa <int> vetor ( tam );
   
// ler dados do teclado para arranjo
   vetor.ler( );
// gravar arranjo em arquivo
   vetor.gravar( fileName );
// reciclar espaco
   vetor.liberar( );
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

// ----------------------------------------------- acao principal

/*
 Funcao principal.
 @return codigo de encerramento
*/
int main ( int argc, char** argv )
{
// definir dado
   int x = 0; // definir variavel com valor inicial
// repetir at� desejar parar
   do
   {
   // identificar
      cout << "EXEMPLO1101 - Programa - v0.1\n " << endl;
   // mostrar opcoes
      cout << "Opcoes:" << endl;
      cout << " 0 - parar                                                     " << endl;
      cout << " 1 - Criar arranjo com valores aleatorios e salvar em arquivo. " << endl;
      cout << " 2 - Procurar maior valor de arranjo.                          " << endl;
      cout << " 3 - Procurar menor valor de arranjo.                          " << endl;
      cout << " 4 - Somar valores de arranjo.                                 " << endl;
      cout << " 5 - Media dos valores de arranjo.                             " << endl;
      cout << " 6 - Verificar se os valores do arranjo sao iguais a zero.     " << endl;
      cout << " 7 - Dizer se arranjo esta' ordenado em ordem decrescente.     " << endl;
      cout << " 8 - Procurar valor entre posicoes.                            " << endl;
      cout << " 9 - Escalar arranjo.                                          " << endl;
      cout << "10 - Ordenar arranjo em ordem decrescente.                     " << endl;
      cout << "11 - Testar se algum valor no arranjo e' diferente.            " << endl;
      cout << "12 - Subtrair arranjos.                                        " << endl;
      cout << "13 - Criar arranjo em arquivo.                                 " << endl;
   // ler do teclado
      cout << endl << "Entrar com uma opcao: ";
      cin >> x;
   // escolher acao
      switch ( x )
      {
         case 0:
            method00 ( );
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            methodE1 ( );
            break;
         case 12:
            methodE2 ( );
            break;
         case 13:
            criarVetor ( );
            break;
         default:
            cout << endl << "ERRO: Valor invalido." << endl;
      } // fim escolher
   }
   while ( x != 0 );
// encerrar
   pause ( "Apertar ENTER para terminar" );
   return ( 0 );
} // fim main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

 * Se tiver algo errado, por favor deixa os comentarios que eu refaco.
 * O metodo criarVetor e' so' pra nao ter que abrir o bloco de notas pra criar um arquivo.
 
---------------------------------------------- previsao de testes

---------------------------------------------- historico
Versao   Data                                  Modificacao
 0.1     30/05                                 esboco
           |
           |
           |
         31/05
 
---------------------------------------------- testes
Versao   Teste
 0.1     01. ( OK )                            identificacao de programa
         02. ( OK )
         03. ( OK )
         04. ( OK )
         05. ( OK )
         06. ( OK )
         07. ( OK )
         08. ( OK )
         09. ( OK )
         10. ( OK )
         E1. ( OK )
         E2. ( OK )
         13. ( OK )
 
*/
