/*
   Exemplo0810 - v0.1 - 23/04 -> 28/04
   Author: Gustavo Gomes de Souza - 656841
*/

#include "io.h"

// FUNCOES


int arraySize ( chars fileName )
{
   int n = 0;
   int m = 0;
   FILE* arquivo = fopen ( fileName, "rt" );
   
   fscanf ( arquivo, "%d", &n );
   
   while ( !feof ( arquivo ) )
   {
      fscanf ( arquivo, "%d", &n );
      m = m+1;
   }

   if ( m <= 0 )
   {
      IO_println ( "Valor invalido." );
      n = 0;
   }
   
   return ( m );
} // fim arraySize ( )

int aleatoryNumber ( int inf, int sup )
{
   int random = 0;
   random = inf + (rand( ) %(sup-inf) );
   return ( random );
}

int acharMaior ( int array [ ] )
{
   int z1 = 0;
   int z2 = 0;
   int z3 = 0;
   
   int x = arraySize ( "DADOS.txt" );
   
   for ( int i = 0; i < x; i++ )
   {
      if ( i == 0 )
      {
         z2 = array [ i ];
      }
      else
      {
         z1 = array [ i ];
         if ( z1 > z2 )
         {
            z2 = z1;
         }
      }
   }
   
   return ( z2 );
}

int acharMenor ( int array [ ] )
{
   int z1 = 0;
   int z2 = 0;
   int z3 = 0;
   
   int x = arraySize ( "DADOS.txt" );
   
   for ( int i = 0; i < x; i++ )
   {
      if ( i == 0 )
      {
         z2 = array [ i ];
      }
      else
      {
         z1 = array [ i ];
         if ( z1 < z2 )
         {
            z2 = z1;
         }
      }
   }
   
   return ( z2 );
}

double mediaValores ( chars file )
{
   FILE* arquivo = fopen ( file, "rt" );
   double media = 0.0;
   double soma = 0.0;
   int z = 0;
   int z2 = 0;
   
   int x = arraySize ( file );
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < x; i++ )
   {
      fscanf ( arquivo, "%d", &z2 );
      soma = soma + z2;
   }
   
   media = soma/x;
   
   return ( media );
}

bool ordenado ( int array[ ], int tam )
{
   //definicao de dados
   int maior = 0;
   int menor = 0;
   
   // verificar se o vetor nao esta' vazio
   if ( tam != 0 )
   {
      menor = array [ 0 ];
      
      for ( int i = 1; i < tam; i++ )
      {
         maior = array [ i ];
         if ( maior < menor )
         {
            return ( false );
         }
         else
         {
            menor = maior;
         }
      }
      return ( true );
   }
   else
   {
      printf ( "Vetor (arranjo) vazio." );
      return ( false );
   }
}

bool acharValor ( int array[ ], int tam, int x, int valor )
{
   for ( int i = x; i < tam; i++ )
   {
      if ( array [ i ] == valor )
      {
         return ( true );
      }
      else
      {
         if ( i == (tam-1) )
         return (false);
      }
   }
}

int acharValor2 ( int array[ ], int tam, int x, int valor )
{
   for ( int i = x; i < tam; i++ )
   {
      if ( array [ i ] == valor )
      {
         return i;
      }
   }
   
   for ( int i = 0; i < x; i++ )
   {
      if ( array [ i ] == valor )
      {
         return (i);
      }
      else
      {
         return ( -1 );
      }
   }
}

int acharValor3 ( int array[ ], int tam, int x, int valor )
{
   int cont = 0;
   
   for ( int i = x; i < tam; i++ )
   {
      if ( array [ i ] == valor )
      {
         cont = cont + 1;
      }
   }
   
   for ( int i = 0; i < x; i++ )
   {
      if ( array [ i ] == valor )
      {
         cont = cont + 1;
      }
   }
   
   if ( cont > 0 )
   {
      return ( cont );
   }
   else
   {
      return ( 0 );
   }
}

int E11 ( chars fileName, int valor )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int qtd = 0;
   
   for ( int i = valor; i > 0; i-- )
   {
      if ( valor % i == 0 )
      {
         fprintf ( arquivo, "%d\n", i );
         qtd++;
      }
   }
   
   fprintf ( arquivo, "%d\n", qtd );
   
   fclose ( arquivo );
   return ( qtd );
}

// METODOS GRAVAR

void metodoPalavras3 ( chars fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   chars linha = IO_new_chars ( 80 );
   
   fprintf ( arquivo, "%c\n", ' ' );
   IO_println ( "Gravar palavras em arquivo. Digite PARAR para terminar. " );
   do
   {
      strcpy ( linha, IO_readln ( "" ) );
      fprintf ( arquivo, "%s\n", linha );
   } while ( strcmp ( "PARAR", linha ) != 0 );
   
   fclose ( arquivo );
}

void palavraS ( )
{
   metodoPalavras3 ( "PALAVRAS.txt" );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

void gravarMethod01 ( chars fileName, int tam )
{  
   // declara��o de dados
   int x = 0;
   FILE* arquivo = fopen ( fileName, "wt" );
   
// leitura de dados do teclado
   int vetor[tam];
   
   for ( int i = 0; i < tam; i++ )
   {  
      do
      {
      x = IO_readint ( "Digite valores para o vetor: " );
      } while ( x < 0 );
      vetor [ i ] = x;
   }
   
   for ( int i = 0; i < tam; i++ )
   {  
      printf ( "%d: %d\n", i, vetor [ i ] ); 
      fprintf ( arquivo, "%d\n", vetor [ i ] );
   }
   
   fclose ( arquivo );
} 

void gravarMethod02 ( chars fileName, chars fileOut, int array[ ] )
{
   FILE* arquivo = fopen ( fileName, "rt" );
   FILE* saida = fopen ( fileOut, "wt" );
   int w = 0;
   int y = 1;
   int z = 1;
   int tam = 0;
   
   tam = arraySize ( "RESULTADO01.txt" );
   fprintf ( saida, "Tamanho = %d\n", tam );
   
   fscanf ( arquivo, "%d", &w );
   fprintf ( saida, "%d\n", w );
   while ( !feof ( arquivo ) && y < tam )
   {
      fscanf ( arquivo, "%d", &z );
      if ( z > 0 )
      {
         fprintf ( saida, "%d\n", z );
      }
         y = y + 1;
   }
   
   fclose ( arquivo );
   fclose ( saida );
}

void gravarMethod03 ( chars fileName, int inf, int sup, int n )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int random = 0;
   
   fprintf ( arquivo, "%d\n", n );
   for ( int i = 0; i < n; i++ )
   {
     random = aleatoryNumber ( inf, sup );
     if( i == n-1 )
     {
         fprintf ( arquivo, "%d", random );
     }
     else
     {
         fprintf ( arquivo, "%d\n", random );
     }
   }
   
   fclose ( arquivo );
}

void gravarMethod06 ( chars fileIn, chars fileOut, chars fileOut2 )
{  
   FILE* entrada = fopen ( fileIn, "rt" );
   FILE* saida = fopen ( fileOut, "wt" );
   FILE* saida2 = fopen ( fileOut2, "wt" );
   int z = 0;
   int tam = 0;
   tam = arraySize ( fileIn );
   int array [ tam ];
   int z1 = 0;
   
   fscanf ( entrada, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( entrada, "%d", &z1 );
      array [ i ] = z1;
   }
   
   for ( int i = 0; i < tam; i++ )
   {
      if ( array [ i ] < mediaValores ( fileIn ) )
      {
         fprintf ( saida, "%d\n", array [ i ] );
      }
      else
      {
         fprintf ( saida2, "%d\n", array [ i ] );
      }
   }
   
   fclose ( entrada );
   fclose ( saida );
   fclose ( saida2 );
}

// METODOS

void method01 ( )
{
   int tam = 0;
   
   do
   {
      tam = IO_readint ( "Digite o tamanho do vetor: " );
   } 
   while ( tam <= 0 );
   
   gravarMethod01 ( "RESULTADO01.txt", tam );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method02 ( )
{
   int array [ arraySize ( "RESULTADO01.txt" ) ];
   
   gravarMethod02 ( "RESULTADO01.txt", "RESULTADO02.txt", array );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method03 ( )
{
   int n = 0;
   int inf = 0;
   int sup = 0;
   
   n = IO_readint ( "Quantos valores aleatorios serao gravados? " );
   inf = IO_readint ( "Qual o valor inferior do intervalo? " );
   sup = IO_readint ( "Qual o valor superior do intervalo? " );
   
   gravarMethod03 ( "DADOS.txt", inf, sup, n );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method04 ( )
{   
   FILE* arquivo = fopen ( "DADOS.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DADOS.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
      printf ( "%d\n", z1 );
   }
   
   printf ( "O maior valor do arranjo e': %d", acharMaior ( array ) );
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method05 ( )
{
   FILE* arquivo = fopen ( "DADOS.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DADOS.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
   }
   
   printf ( "O menor valor do arranjo e': %d", acharMenor ( array ) );
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method06 ( )
{
   gravarMethod06 ( "DADOS.txt", "MENORES.txt", "MAIORES.txt" );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method07 ( )
{
   int tam = 0;
   int x = 0;
   
   do
   {
      tam = IO_readint ( "Digite o tamanho do vetor: " );
   } 
   while ( tam <= 0 );
   
   int vetor[tam];
   
   for ( int i = 0; i < tam; i++ )
   {  
      x = IO_readint ( "Digite valores para o vetor: " );
      vetor [ i ] = x;
   }
   
   for ( int i = 0; i < tam; i++ )
   {  
      printf ( "%d: %d\n", i, vetor [ i ] ); 
   }
   
   if ( ordenado ( vetor, tam ) )
   {
      printf ( "O arranjo esta' em ordem crescente." );
   }
   else
   {
      printf ( "O arranjo nao esta' em ordem crescente." );
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method08 ( )
{
   FILE* arquivo = fopen ( "DADOS.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DADOS.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
   }
   
   int x = 0;
   x = IO_readint ( "Informe a posicao de procura inicial: " );
   int valor = IO_readint ( "Informe o valor procurado: " ); 
   
   if ( acharValor ( array, tam, x, valor ) )
   {
      printf ( "O valor '%d' existe no arranjo procurando a partir da posicao indicada.", valor );
   }
   else
   {
      printf ( "O valor '%d' nao existe no arranjo procurando a partir da posicao indicada.", valor );
   }
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method09 ( )
{
   FILE* arquivo = fopen ( "DADOS.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DADOS.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
   }
   
   int x = 0;
   
   do
   {
      x = IO_readint ( "Informe a posicao de procura inicial: " );
   }
   while ( x > (tam-1) );
   
   int valor = IO_readint ( "Informe o valor procurado: " ); 
   
   if ( acharValor2 ( array, tam, x, valor ) != -1 )
   {
      printf ( "O valor '%d' existe no arranjo e se encontra na posicao %d.", valor, acharValor2 ( array, tam, x, valor ) );
   }
   else
   {
      printf ( "O valor '%d' nao existe no arranjo.", valor );
   }
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method10 ( )
{
   FILE* arquivo = fopen ( "DADOS.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DADOS.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   fscanf ( arquivo, "%d", &z );
   for ( int i = 0; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
   }
   
   int x = 0;
   
   do
   {
      x = IO_readint ( "Informe a posicao de procura inicial: " );
   }
   while ( x > (tam-1) );
   
   int valor = IO_readint ( "Informe o valor procurado: " ); 
   
   if ( acharValor3 ( array, tam, x, valor ) != 0 )
   { 
         printf ( "O valor '%d' existe e se encontra %d vezes no arranjo.", valor, acharValor3 ( array, tam, x, valor ) );
   }
   else
   {
      printf ( "O valor '%d' nao existe no arranjo.", valor );
   }
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method11 ( )
{
   int valor = IO_readint ( "Digite o valor que quer saber os divisores: " );
   
   int qtd = E11 ( "DIVISORES.TXT", valor );
   
   FILE* arquivo = fopen ( "DIVISORES.txt", "rt" );
   int tam = 0;
   tam = arraySize ( "DIVISORES.txt" );
   int array [ tam ];
   int z = 0;
   int z1 = 0;
   
   array [ 0 ] = qtd;
   for ( int i = 1; i < tam; i++ )
   {
      fscanf ( arquivo, "%d", &z1 );
      array [ i ] = z1;
   }
   
   for ( int i = 0; i < tam; i++ )
   {
      printf ( "%d\n", array [ i ] );
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method12 ( )
{
   
   FILE* arquivo = fopen ( "PALAVRAS.txt", "rt" );
   int x = 0;
   char* z[100];
   int m10 = 0;
   chars linha = IO_new_chars ( 80 );
   
   strcpy ( linha, IO_fread ( arquivo ) );
   while ( !feof( arquivo ) && strcmp ( "PARAR", linha )!=0 )
   {  
      if ( linha [ 0 ] == 'A' || linha [ 0 ] == 'a' )
      {
         z[x] = linha;
         m10 = m10 + 1;
         if ( m10 <= 10 )
         printf ( "%s\n", z[x] );
      }
      x = x + 1;
      // tentar ler o proximo
            strcpy ( linha, IO_fread ( arquivo ) );
   }
   
   fclose ( arquivo );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

/*
   Funcao principal.
   @return codigo de encerramento
*/
int main ( )
{
// definir dado
   int x = 0; // definir variavel com valor inicial
// repetir at� desejar parar
   do
   {
   
   // identificar
      IO_id ( "EXEMPLO0811 - Programa - v0.1" );
   
   // ler do teclado
      IO_println ( "Opcoes" );
      IO_println ( " 0 - Parar." );
      IO_println ( " 1 - Gravar dados em arranjo." );
      IO_println ( " 2 - Guardar dados de arranjo em arquivo." );
      IO_println ( " 3 - Gerar valores aleatorio e gravar em arquivo." );
      IO_println ( " 4 - Procurar maior valor." );
      IO_println ( " 5 - Procurar menor valor." );
      IO_println ( " 6 - Media de valores em arranjo." );
      IO_println ( " 7 - Ordenado ou nao." );
      IO_println ( " 8 - Se existe o valor procurado no arranjo." );
      IO_println ( " 9 - Onde valor procurado aparece no arranjo." );
      IO_println ( "10 - Quantas vezes valor procurado aparece no arranjo." );
      IO_println ( "11 - Divisores." );
      IO_println ( "12 - 10 palavras com a ou A." );
      IO_println ( "12 - Gravar palavras em arquivo." );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
   // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         case 13:
            palavraS ( );
            break;
         default:
            IO_println ( "ERRO: Valor invalido." );
      } // fim escolher
   }
   while ( x != 0 );

// encerrar
   IO_pause ( "Apertar ENTER para terminar" );
   return ( 0 );
} // fim main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 
---------------------------------------------- previsao de testes
---------------------------------------------- historico
Versao          Data                           Modificacao
0.1 ( Begin )   23/04                          esboco
    ( Final )   28/04


---------------------------------------------- testes
Versao       Teste
0.1          01. ( OK )                        identificacao de programa

*/