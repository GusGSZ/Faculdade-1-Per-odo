  /**
   Exemplo0411 - v0.1 - 19/03/2019 - 21/03/2019
   Author: Gustavo Gomes de Souza - 656841
  */
  
  // dependencias
  
  #include "io.h"
  
  // Acoes
  
void metodo1 ()
{
   double x = 0, y = 0, qtd = 0, valor = 0;
   
   int entre = 0, fora = 0;
   
   x = IO_readdouble ( "Digite o valor inferior: " );
   y = IO_readdouble ( "Digite o valor superior: " );
   
   qtd = IO_readdouble ( "Digite a quantidade de numeros a ser lida: " );
   
   for ( int z = 1; z <= qtd; z ++ )
   {
      valor = IO_readdouble ( "\n Digite um valor: " );
      IO_printf ( "%s %d - %lf", "", z, valor );
      
      if ( valor >= x && valor <= y )
      {
         entre++;
      }
      else
      {
         fora++;
      } // end if
      
   } //end for
   
   printf ( "\n %d valor(es) esta(ao) dentro do intervalo e %d valor(es) esta(ao) fora do intervalo. \n\n", entre, fora );
}
  
bool maiuscula ( char x )
{
   bool maius = false;
  
   if ( x >= 'A' && x <= 'Z' )
   {
      return (true);
   }
   else
   {
      return (false);
   }
  
}
  
void metodo2 ()
{
   chars palavra = IO_new_chars (80);
   strcpy ( palavra, "" );
   
   int maiusculas = 0;
   
   palavra = IO_readstring( "Digite uma palavra: ");
   
   int tam = strlen (palavra);
   
   for ( int x = 0; x < tam; x++ )
   { 
      if ( maiuscula (palavra [x]) )
      {
         maiusculas++;
      }
   }
   
   printf ( "%d letra(s) maiuscula(s). \n\n", maiusculas );
}
  
int maius ( chars palavra )
{
   int maiusculas = 0;
   
   int tam = strlen (palavra);
   
   for ( int x = 0; x < tam; x++ )
   { 
      if ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' )
      {
         maiusculas++;
      }
   }
   
   return (maiusculas);
}
  
void metodo3()
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   printf ( "Ha %d letra(s) maiuscula(s). \n", maius ( palavra ) );
}
  
chars maiusalt ( chars palavra )
{  
   chars maiuscula = IO_new_chars( 80 );
   strcpy ( maiuscula, "" );
   
   int tam = strlen(palavra);
   
      for ( int x = 0; x < tam; x++ )
      {
         if ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' )
            maiuscula = IO_concat (maiuscula, IO_toString_c (palavra [ x ]) );
      }
      
   return ( maiuscula );
} // end maiusalt()

void metodo4 ( )
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   char letra;
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   IO_printf ( "%s \n", maiusalt(palavra) );
}

chars maimin ( chars palavra )
{
   int maius = 0, minus = 0;
   
   chars maimin = IO_new_chars ( 80 );
   strcpy ( maimin, "" );
   
   int tam = strlen(palavra);
   
   for ( int x = 0; x < tam; x++ )
   {
      if ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' )
      {
         maius++;
      }
      else
      {
         if ( palavra [ x ] >= 'a' && palavra [ x ] <= 'z' )
         {
            minus++;
         }
      }
      maimin = IO_concat( IO_concat ("Maiusculas:  ", IO_toString_d (maius)), IO_concat ( "\nMinusculas:  ", IO_toString_d (minus) ) );
   }
   
   return ( maimin ); 
}

void metodo5 ( )
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   IO_printf ( "%s \n", maimin(palavra) );
}

char* maiusminus ( chars palavra )
{
   chars maiusculas = IO_new_chars(80);
   chars minusculas = IO_new_chars(80);
   
   strcpy ( maiusculas, "" );
   strcpy ( minusculas, "" );
   
   int tam = strlen ( palavra );
   
   for ( int x = 0; x < tam; x++ )
   {
      if ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' ) 
      {
         maiusculas = IO_concat ( maiusculas, IO_toString_c ( palavra [ x ] ) ) ; 
      }
      else
      {
         if ( palavra [ x ] >= 'a' && palavra [ x ] <= 'z' )
         {
            minusculas = IO_concat ( minusculas, IO_toString_c ( palavra [ x ] ) ) ; 
         }
      }
   }
   
   return ( IO_concat ( IO_concat( "Maiusculas: ", maiusculas ), IO_concat ( "\nMinusculas: ", minusculas ) ) );
}

void metodo6 () 
{
   chars palavra = IO_new_chars ( 80 );
   
   palavra = IO_readstring ( "Digite uma palavra: ");
   
   IO_printf ( "%s", maiusminus ( palavra ) );
}

void metodo7 ( )
{
   chars palavra = IO_new_chars ( 80 );
   
   int cont = 0;
   
   strcpy ( palavra, "" );
   
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   int tam = strlen (palavra);
   
   for ( int x = 0; x < tam; x++ )
   {
      if ( palavra [ x ] >= '0' && palavra [ x ]  <= '9' )
      {
         if ( (int) palavra[ x ] %2 != 0 )
         {
            cont++;
            printf ( "%c\n", palavra [x] );
         }
      }
   }
   printf ( "Existem %d digitos impares na cadeia. \n", cont );
}

int alfanumerico ( chars palavra )
{
   int simbol = 0;
   
   int tam = strlen (palavra);
   
   for ( int x = 0; x < tam; x++ )
   { 
      if ( ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' ) || ( palavra [ x ] >= 'a' && palavra [ x ] <= 'z' ) || 
      (palavra [ x ] >= '0' && palavra [ x ] <= '9' ) )
      {
         simbol++;
      }
   }
   
   return (simbol);
}

void metodo8 ( )
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   printf ( "\nExistem %d simbolos alfanumericos na cadeia. \n", alfanumerico(palavra) );
}

chars alfanumericoalt ( chars palavra )
{  
   chars alfanumerico = IO_new_chars( 80 );
   strcpy ( alfanumerico, "" );
   
   int tam = strlen(palavra);
   
      for ( int x = 0; x < tam; x++ )
      {
         if ( ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' ) || ( palavra [ x ] >= 'a' && palavra [ x ] <= 'z' ) || 
            (palavra [ x ] >= '0' && palavra [ x ] <= '9' ) )
         {
            alfanumerico = IO_concat (alfanumerico, IO_toString_c ( palavra [ x ] ) );
         }
      }
      
   return ( IO_concat (alfanumerico, "\n\n" ) );
} // end alfanumericoalt()

void metodo9 ( )
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   palavra = IO_readstring ( "Digite uma palavra: " );
   
   printf ( "%s", alfanumericoalt(palavra) );
}

void metodo10 ( )
{
   int qtd = 0, cont = 0, cont1 = 0;
   
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   qtd = IO_readint ( "Quantidade de palavras: " );
   
   for ( int x = 1; x <= qtd; x++ )
   {
      palavra = IO_readstring ( "Digite uma palavra: " );
      
      int tam = strlen ( palavra );
      
      for ( int y = 0; y < tam; y++ )
      { 
         if ( ( palavra [ y ] >= 'A' && palavra [ y ] <= 'Z' ) || ( palavra [ y ] >= 'a' && palavra [ y ] <= 'z' ) || 
            ( palavra [ y ] >= '0' && palavra [ y ] <= '9' ) )
         {
            cont++;
            cont1++;
         }
      }
      printf ( "\nExistem %d simbolos alfanumericos na palavra %d\n\n", cont1, x );
      cont1 = 0;
   }
   
   printf ( "No total, existem %d simbolos alfanumericos nas palavras.\n\n", cont );
}

void metodo12 ( )
{
   int qtd1 = 0, qtd2 = 0;

   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   
   chars palavra2 = IO_new_chars ( 80 );
   strcpy ( palavra2, "" );
   
   palavra = IO_readstring ( "Digite uma palavra: " );
   palavra2 = IO_readstring ( "Digite outra palavra: " );
   
   int tam = strlen ( palavra );
   int tam2 = strlen ( palavra2 );
   
   for ( int x = 0; x < tam; x++ )
   { 
      if ( palavra [ x ] >= '0' && palavra [ x ] <= '9' )
      {
         qtd1 = qtd1 + 1;
      }
   }
   
   for ( int y = 0; y < tam2; y++ )
   { 
      if ( palavra2 [ y ] >= '0' && palavra2 [ y ] <= '9' )
      {
         qtd2 = qtd2 + 1;
      }
   }
   
   if ( qtd1 > qtd2 )
   {
      IO_printf ( "%s A palavra 1 tem mais digitos que a palavra 2.\n" );
   }
   
   if ( qtd1 < qtd2 )
   {
      printf ( "A palavra 2 tem mais digitos que a palavra 1.\n" );
   }
   
   if ( qtd1 == qtd2 )
   {
      printf ( "As duas palavras tem a mesma quantidade de digitos.\n" );
   }
}
  
  // Acao principal
  
int main ()
{
   int x = 0;
   
   do
   {
      printf ( "Opcoes: \n" );
      printf ( "1 - contar quantos valores estao dentro e os que estao fora do intervalo. \n" );
      printf ( "2 - contar letras maiusculas. \n" );
      printf ( "3 - contar letras maiusculas (alternativo). \n" );
      printf ( "4 - separar letras maiusculas. \n" );
      printf ( "5 - contar letras maiusculas e minusculas. \n" );
      printf ( "6 - separar letras maiusculas e minusculas. \n" );
      printf ( "7 - contar e mostrar digitos impares. \n" );
      printf ( "8 - contar todos os simbolos alfanum�ricos. \n" );
      printf ( "9 - separar todos os simbolos alfanum�ricos. \n" );
      printf ( "10 - contar a quantidade de simbolos alfanum�ricos em cada palavra e no total. \n" );
      printf ( "11 - contar a quantidade de simbolos alfanum�ricos em cada palavra e no total. \n" );
      printf ( "12 - calcular qual das duas palavras tem o maior numero de digitos. \n" );
      printf ( "Escolha uma opcao: \n" );
      scanf  ( "%d", &x );
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         case 4:
            metodo4 ( );
            break;
         case 5:
            metodo5 ( );
            break;
         case 6:
            metodo6 ( );
            break;   
         case 7:
            metodo7 ( );
            break;
         case 8:
            metodo8 ( );
            break;
         case 9:
            metodo9 ( );
            break;
         case 10:
            metodo10 ( );
            break;
         case 11:
            metodo10 ( );
            break;
         case 12:
            metodo12 ( );
            break;
         default:
            printf( "%s ERRO: Valor invalido. ");
            break;
      }
      
   }
   while ( x != 0 );
   
   //encerrar
   printf ( "Digite ENTER para terminar. " );
   fflush( stdin );
   getchar( );
   return ( 0 );
}
  
  /*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

---------------------------------------------- previsao de testes
a.) 
b.) 
c.) 
---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          19/03                            esboco
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
 
*/