   /*
    Exemplo0319 - v0.9 - 13/03/2019
    Author: Gustavo Gomes de Souza
   */

   // dependencias
   #include "io.h" // para definicoes proprias
   
   void metodo1 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     
     IO_id ( "EXEMPLO0319 - Metodo1 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          IO_printf ( "%s %c\n", "", palavra[x] );
       }
     }
     
   }
   
   void metodo2 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo2 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     } 
   }
   
   void metodo3 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo3 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
       if ( palavra [x] >= 'A' && palavra[x] <= 'Z' )
       {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
     }  
   }
   
   void metodo4 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo4 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          maiuscula++;
          if ( !((palavra [x] >= 'a' && palavra[x] <= 'z' ) || ( palavra [x] >= 'A' && palavra [x] <= 'Z'  )))
          {
           x++;
          }
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
     }
   }  
   
   void metodo5 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo5 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = tamanho; x >= 0; x-- )
     {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
       }
   }
   
   void metodo6 ( )
   {
   //definir dados
     int tamanho = 0;
     chars palavra = IO_new_chars( 80 );
     char letra;
     int maiuscula = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo6 - v0.9" );
          
     palavra = IO_readstring( "Digite uma palavra: " );
     
     tamanho = strlen (palavra) - 1;
     
     for ( int x = 0; x <= tamanho; x++ )
     {
          char simbol = palavra [x];
          if (! ( ( simbol >= 'a' && simbol <= 'z' ) || ( simbol >= 'A' && simbol <= 'Z' ) || ( simbol >= '0' && simbol <= '9' ) ) )
          {
          maiuscula++;
          IO_printf ( "%s %d - %c\n", "", maiuscula, palavra[x] );
          }
     }
   }
   
   void metodo7 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo7 - v0.9" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   void metodo8 ( )
   {
   //definir dados
     int y = 0, z = 0, x2 = 0;
     
     IO_id ( "EXEMPLO0319 - Metodo8 - v0.9" );
          
     y = IO_readint( "Digite o numero inferior: " );
     z = IO_readint( "Digite o numero superior: " );
     
     for ( int x = y; x <= z; x++ )
     {
        if ( x % 3 == 0 && !( x % 2 == 0 ) )
        {
        IO_printf ( "%s %d\n", "", x );
        }
     }
   }
   
   void metodo9 ( )
   {
   //definir dados
     double y = 0.0, z = 0.0, num = 0.0;
     int qtd = 0, cont = 0;
     
     chars real9 = IO_new_chars ( 80 );
     
     strcpy ( real9, "" );;
     
     IO_id ( "EXEMPLO0319 - Metodo9 - v0.9" );
          
     y = IO_readdouble( "Digite o numero inferior: " );
     z = IO_readdouble( "Digite o numero superior: " );
     qtd = IO_readint ( "Digite a quantidade de numeros a serem digitados: " );
     
     while ( z <= y )
     {
      z = IO_readdouble( "Digite o numero superior: " );
     }
     
     for ( int x = 1; x <= qtd; x ++ )
     {
        num = IO_readdouble ( "Digite um valor: " );
        if ( x == qtd )
        {
            printf ( "%d - %lf\n\n", x, num );
        }
        else
        {
            printf ( "%d - %lf\n", x, num );
        }
        
        if ( (int) num >= y && (int) num <= z )
        {
            if ( ( (int) num ) % 2 == 0 )
            {
               real9 = IO_concat ( IO_concat ( real9, IO_toString_f (num) ), IO_concat ( "\n", "" ) );
               cont++;
            }
        }
     }
     
     printf ( "%s", real9 );
     printf ( "\nHa %d valores dentro do intervalo cujas partes inteiras sao pares. \n", cont);
   }
   
   int main ( )
   {
        // definir dado
   int x = 0;
     // repetir at� desejar parar
   do
   {
       // identificar
      IO_id ( "EXEMPLO0319 - Programa - v0.9" );
      IO_println ( "Opcoes" );
      IO_println ( "0 - parar" );
      IO_println ( "1 - metodo1" );
      IO_println ( "2 - metodo2" );
      IO_println ( "3 - metodo3" );
      IO_println ( "4 - metodo4" );
      IO_println ( "5 - metodo5" );
      IO_println ( "6 - metodo6" );
      IO_println ( "7 - metodo7" );
      IO_println ( "8 - metodo8" );
      IO_println ( "9 - metodo9" );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
       // testar valor
      switch ( x )
      {
         case 0:
            break;
         case 1:
            metodo1 ( );
            break;
         case 2:
            metodo2 ( );
            break;
         case 3:
            metodo3 ( );
            break;
         case 4:
            metodo4 ( );
            break;
         case 5:
            metodo5 ( );
            break;
         case 6:
            metodo6 ( );
            break;
         case 7:
            metodo7 ( );
            break;
         case 8:
            metodo8 ( );
            break;
         case 9:
            metodo9 ( );
            break;
         default:
            IO_println ( IO_concat ( "Valor diferente das opcoes [0,1,2,3,4,5,6,7,8,9] (",
               IO_concat ( IO_toString_d ( x ), ")" ) ) );
      } // fim escolher
   }
     while ( x != 0 );
    IO_pause ( "Aperte ENTER para terminar." );
    return(0);
   }
   
   /*

   ---------------------------------------------- documentacao complementar
   ---------------------------------------------- notas / observacoes / comentarios
   ---------------------------------------------- previsao de testes
    a.) [11.15:44.53]
    b.) [0.2:22.9234]
    c.) [15.5:30.13]
          
   ---------------------------------------------- resultados 
    a.) 1 - 12
        2 - 14
        3 - 16
        4 - 18
        5 - 20
        6 - 22
        7 - 24
        8 - 26
        9 - 28
        10 - 30
        11 - 32
        12 - 34
        13 - 36
        14 - 38
        15 - 40
        16 - 42
        17 - 44
    
    b.) 1 - 0
        2 - 2
        3 - 4
        4 - 6
        5 - 8
        6 - 10
        7 - 12
        8 - 14
        9 - 16
        10 - 18
        11 - 20
        12 - 22
    
    c.) 1 - 16
        2 - 18
        3 - 20
        4 - 22
        5 - 24
        6 - 26
        7 - 28
        8 - 30
        
   ---------------------------------------------- historico
    Versao    Data                                Modificacao
    0.1       12/03                               esboco
    0.2       13/03
    0.3       13/03
    0.4       13/03
    0.5       13/03
    0.6       13/03
    0.7       13/03
    0.8       13/03
    0.9       13/03
 
   ---------------------------------------------- testes
    Versao     Teste
    0.1        01. ( OK )                         identificacao de programa
    0.2        01. ( OK )
    0.3        01. ( OK )
    0.4        01. ( OK )
    0.5        01. ( OK )
    0.6        01. ( OK )
    0.7        01. ( OK )
    0.8        01. ( OK )
    0.9        01. ( OK )
    
    */