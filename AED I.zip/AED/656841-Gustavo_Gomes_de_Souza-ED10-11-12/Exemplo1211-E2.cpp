/**
   Exemplo1211->E2 - v0.1 - 01->02/06/2019
   Matricula: 656841
   Author: Gustavo Gomes de Souza
*/

// dependecias
#include <iostream>
#include <limits>
#include <string>

//--------------------------------------------- definicoes globais
void pause ( std::string text )
{
   std::string dummy;
   std::cin.clear ( );
   std::cout << std::endl << text;
   std::cin.ignore( );
   std::getline(std::cin, dummy);
   std::cout << std::endl << std::endl;
} // end pause ( )

using namespace std;

void idMetodo ( string x )
{
   cout << endl << "EXEMPLO1211->E2 - Method" << x << " - v0.1" << endl;
   cout << "Matricula: 656841" << endl;
   cout << "Autor: Gustavo Gomes de Souza\n" << endl;
}

//--------------------------------------------- classes
#include "killthislove.hpp"

//--------------------------------------------- metodos

/**
 Method00 - nao faz nada.
*/
void method00 ( )
{
   // nao faz nada
} // fim method00 ( )

/**
 Method01.
*/
void method01 ( )
{
// identificar
   idMetodo ( "01" );
   
// definir dados
   int lin = 0;
   int col = 0;
   int inf = 0;
   int sup = 0;
   
// receber dados
   cout << "Quantas linhas?" << endl;
   cin >> lin;
   cout << "Quantas colunas?" << endl;
   cin >> col;
   Kisses <int> matriz ( lin, col );
   
   cout << "Qual o valor inferior do intervalo?" << endl;
   cin >> inf;
   
   cout << "Qual o valor superior do intervalo?" << endl;
   cin >> sup;
   
// preencher matriz com valores aleatorios
   matriz.preencherAleatorio ( inf, sup );
// mostrar matriz
   matriz.mostrar( );
// gravar matriz em arquivo
   matriz.gravar( "DADOS.txt" );
// reciclar espaco
   matriz.liberar( );
   
// encerrar
   pause ( "Aperte ENTER para continuar." );
} // fim method01 ( )

/**
 Method02.
*/
void method02 ( )
{
// identificar
   idMetodo ( "02" );
// declarar dados
   int constante = 0;
// entrada de dados
   cout << "Por qual constante a matriz sera' multiplicada?" << endl;
   cin >> constante;
// definir matriz com valores iniciais
   Kisses <int> matriz ( 5, 5 );
// ler matriz de arquivo
   matriz.lerArq( "DADOS.txt" );
// definir matriz de mesmo tamanho da matriz 1
   Kisses <int> matriz2 ( matriz.linhass(), matriz.colunass() );
// mostrar matriz
   matriz.mostrar( );
// escalar matriz
   matriz2 = matriz.escalar( constante );
// mostrar matriz escalada
   matriz2.mostrar( );
// reciclar espaco
   matriz.liberar( );   
   matriz2.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method02 ( )

/**
 Method03.
*/
void method03 ( )
{
// identificar
   idMetodo ( "03" );
  
// definir matriz com valor inicial
   Kisses <int> matriz ( 5, 5 );
   
// ler matriz de arquivo
   matriz.lerArq( "DADOS.TXT" );
   
// mostrar matriz
   matriz.mostrar( );
   
// testar se e' identidade
   if ( matriz.isIdentity( ) )
      cout << "E' uma matriz identidade." << endl;
   else
      cout << "Nao e' uma matriz identidade." << endl;
// reciclar espaco
   matriz.liberar( );
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method03 ( )

/**
 Method04.
*/
void method04 ( )
{
// identificar
   idMetodo ( "04" );
// definir matrizes com valores iniciais
   Kisses <int> matriz ( 5, 5 );
   Kisses <int> matriz2 ( 5, 5 );
// ler matrizes de arquivos
   matriz.lerArq( "DADOS1.txt" );
   matriz2.lerArq ( "DADOS2.TXT" );
   
// mostrar matrizes
   matriz.mostrar( );
   matriz2.mostrar( );
   
// testar se sao iguais
   if ( matriz==matriz2 )
      cout << "As matrizes sao iguais." << endl;
   else
      cout << "As matrizes sao diferentes." << endl;
// reciclar espaco
   matriz.liberar( );
   matriz2.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method04 ( )

/**
 Method05.
*/
void method05 ( )
{
// identificar
   idMetodo ( "05" );
   
// definir matrizes com valores iniciais
   Kisses <int> matriz ( 5, 5 );
   Kisses <int> matriz2 ( 5, 5 );
// ler matrizes de arquivos
   matriz.lerArq( "DADOS1.txt" );
   matriz2.lerArq ( "DADOS2.TXT" );
   
// definir matriz com tamanho das outras duas
   Kisses <int> matrizsomada ( matriz.linhass(), matriz.colunass() );
   
// mostrar matrizes
   matriz.mostrar( );
   matriz2.mostrar( );
   
// somar matrizes
   matrizsomada = matriz+matriz2;
   
// mostrar matriz somada
   matrizsomada.mostrar( );
   
// reciclar espaco
   matriz.liberar( );
   matriz2.liberar( );
   matrizsomada.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method05 ( )

/**
 Method06.
*/
void method06 ( )
{
// identificar
   idMetodo ( "06" );
   
   Kisses <int> matriz ( 5, 5 );
   
   int linha1 = 0;
   int linha2 = 0;
   int constante = 0;
   
   cout << "Qual a primeira linha?" << endl;
   cin >> linha1;
   
   cout << "Qual a segunda linha?" << endl;
   cin >> linha2;
   
   cout << "Qual a constante para multiplicar?" << endl;
   cin >> constante;
   
   matriz.lerArq( "DADOS1.TXT" );
   
   matriz.mostrar( );
   
   matriz.addLines( linha1, linha2, constante );
   
   matriz.mostrar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method06 ( )

/**
 Method07.
*/
void method07 ( )
{
// identificar
   idMetodo ( "07" );
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// definir dados
   int coluna1 = 0;
   int coluna2 = 0;
   int constante = 0;
// entrada de dados
   cout << "Qual a primeira coluna?" << endl;
   cin >> coluna1;
   
   cout << "Qual a segunda coluna?" << endl;
   cin >> coluna2;
   
   cout << "Qual a constante para multiplicar?" << endl;
   cin >> constante;
// ler matriz de arquivo
   matriz.lerArq( "DADOS1.TXT" );
// mostrar matriz original
   matriz.mostrar( );
// alterar linhas
   matriz.addColumns( coluna1, coluna2, constante );
// mostrar matriz alterada
   matriz.mostrar( );
// reciclar espaco
   matriz.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method07 ( )

/**
 Method08.
*/
void method08 ( )
{
// identificar
   idMetodo ( "08" );
// definir dados
   int procurado = 0;
// entrada de dados
   cout << "Qual o valor procurado?" << endl;
   cin >> procurado;
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// ler matriz de arquivo
   matriz.lerArq( "DADOS1.txt" );
// mostrar matriz
   matriz.mostrar( );
// dizer em qual linha se encontra o valor procurado, se existir
   if ( matriz.procurarNaLinha( procurado ) == -1 )
   {
      cout << "O valor procurado nao foi encontrado." << endl;
   }
   else
   {
      cout << "O valor procurado foi encontrado na linha: " << matriz.procurarNaLinha( procurado ) << endl;
   }
   
// reciclar espaco
   matriz.liberar( );
   
// encerrar
   pause ( "Apertar ENTER para continuar" );
} // fim method08 ( )

/**
 Method09.
*/
void method09 ( )
{
// identificar
   idMetodo ( "09" );
// definir dados
   int procurado = 0;
// entrada de dados
   cout << "Qual o valor procurado?" << endl;
   cin >> procurado;
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// ler matriz de arquivo
   matriz.lerArq( "DADOS1.txt" );
// mostrar matriz
   matriz.mostrar( );
// dizer em qual linha se encontra o valor procurado, se existir
   if ( matriz.procurarNaColuna( procurado ) == -1 )
   {
      cout << "O valor procurado nao foi encontrado." << endl;
   }
   else
   {
      cout << "O valor procurado foi encontrado na coluna: " << matriz.procurarNaColuna( procurado ) << endl;
   }
   
// reciclar espaco
   matriz.liberar( );
      
// encerrar
   pause ( "Aperte ENTER para terminar." );
} // fim method09 ( )

/**
 Method10.
*/
void method10 ( )
{
// identificar
   idMetodo ( "10" );
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// ler matriz de arquivo
   matriz.lerArq( "DADOS1.txt" );
// mostrar matriz
   matriz.mostrar( );
// transpor matriz
   matriz.transpor( );
// mostrar matriz transposta
   matriz.mostrar( );
// encerrar
   pause ( "Aperte ENTER para terminar." );
} // fim method10 ( )

/**
 MethodE1.
*/
void methodE1 ( )
{
// identificar
   idMetodo ( "E1" );
   
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// ler matriz de arquivo
   matriz.lerArq( "DADOS1.txt" );
// mostrar matriz
   matriz.mostrar( );
// transpor matriz
   if ( matriz.naSequencia( ) )
      cout << "A matriz esta' na sequencia indicada." << endl;
   else
      cout << "A matriz nao esta' na sequencia indicada." << endl;
      
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

/**
 MethodE2.
*/
void methodE2 ( )
{
// identificar
   idMetodo ( "E2" );
// definir dados
   int linhas = 0;
   int colunas = 0;
   
// definir matriz
   Kisses <int> matriz ( 5, 5 );
// entrada de dados
   cout << "Quantas linhas a matriz tera'?" << endl;
   cin >> linhas;
   
   cout << "Quantas colunas a matriz tera'?" << endl;
   cin >> colunas;
   
// criar matriz na sequencia proposta
   matriz.criarNaSequencia( linhas, colunas );
// mostrar matriz na sequencia proposta
   matriz.mostrar( );
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

/**
 criarVetor - Criar vetor e gravar em arquivo.
*/
void criarMatriz ( )
{
// definir dados
   string fileName = "";
   int tam = 0;
   int linhas = 0;
   int colunas = 0;
   
// entrada de dados
   cout << "Em qual arquivo serao gravados os valores?" << endl;
   cin >> fileName;
   
   cout << "Quantas linhas?" << endl;
   cin >> linhas;
   
   cout << "Quantas colunas?" << endl;
   cin >> colunas;
   
// definir arranjo
   Kisses <int> matriz ( linhas, colunas );
   
// ler dados do teclado para arranjo
   matriz.preencher( );
// gravar arranjo em arquivo
   matriz.gravar( fileName );
// reciclar espaco
   matriz.liberar( );
// encerrar
   pause ( "Aperte ENTER para terminar." );
}

// ----------------------------------------------- acao principal

/*
 Funcao principal.
 @return codigo de encerramento
*/
int main ( int argc, char** argv )
{
// definir dado
   int x = 0; // definir variavel com valor inicial
// repetir at� desejar parar
   do
   {
   // identificar
      cout << "EXEMPLO1211->E2 - Programa - v0.1\n " << endl;
   // mostrar opcoes
      cout << "Opcoes:" << endl;
      cout << " 0 - parar                                                              " << endl;
      cout << " 1 - Criar matriz com valores aleatorios e salvar em arquivo.           " << endl;
      cout << " 2 - Escalar matriz.                                                    " << endl;
      cout << " 3 - Testar se matriz e' identidade.                                    " << endl;
      cout << " 4 - Testar se duas matrizes sao iguais.                                " << endl;
      cout << " 5 - Incluir um operador para somar duas matrizes.                      " << endl;
      cout << " 6 - Alterar linhas de matriz.                                          " << endl;
      cout << " 7 - Alterar colunas de matriz.                                         " << endl;
      cout << " 8 - Dizer em qual linha da matriz se encontra certo valor, se houver.  " << endl;
      cout << " 9 - Dizer em qual coluna da matriz se encontra certo valor, se houver. " << endl;
      cout << "10 - Transpor matriz                                                    " << endl;
      cout << "11 - Dizer se matriz esta' na sequencia indicada.                       " << endl;
      cout << "12 - Criar matriz na sequencia proposta.                                " << endl;
      cout << "13 - Criar matriz e salvar em arquivo.                                  " << endl;
   // ler do teclado
      cout << endl << "Entrar com uma opcao: ";
      cin >> x;
   // escolher acao
      switch ( x )
      {
         case 0:
            method00 ( );
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            methodE1 ( );
            break;
         case 12:
            methodE2 ( );
            break;
         case 13:
            criarMatriz ( );
            break;
         default:
            cout << endl << "ERRO: Valor invalido." << endl;
      } // fim escolher
   }
   while ( x != 0 );
// encerrar
   pause ( "Apertar ENTER para terminar" );
   return ( 0 );
} // fim main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

 * Se tiver algo errado, por favor deixa os comentarios que eu refaco.
 * O metodo criarMatriz e' so' pra nao ter que abrir o bloco de notas pra criar um arquivo com a matriz.
 
---------------------------------------------- previsao de testes

---------------------------------------------- historico
Versao   Data                                  Modificacao
 0.1     01/06                                 esboco
           |
           |
           |
         02/06
 
---------------------------------------------- testes
Versao   Teste
 0.1     01. ( OK )                            identificacao de programa
         02. ( OK )
         03. ( OK )
         04. ( OK )
         05. ( OK )
         06. ( OK )
         07. ( OK )
         08. ( OK )
         09. ( OK )
         10. ( OK )
         E1. ( OK )
         E2. ( OK )
         13. ( OK )
 
*/
