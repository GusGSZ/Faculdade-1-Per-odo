/**
   Exemplo0911 - v0.1 - 03/05/2019 - 04/05/2019
   Author: Gustavo Gomes de Souza - 656841
*/

// dependencias

#include "io.h"

// METODOS

void mostrarMatriz ( int linhas, int colunas, double matrix [][colunas] )
{
   for ( int x = 0; x < linhas; x++ )
   {
      for ( int y = 0; y < colunas; y++ )
      {
         printf ( "%2.3lf\t", matrix [x][y] );
      }
      printf ( "\n" );
   }
}

void gravarMatriz ( int linhas, int colunas, double matriz[][colunas], chars fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "%d\n", linhas );
   fprintf ( arquivo, "%d\n", colunas );
   
   for ( int x = 0; x < linhas; x++ )
   {
      for ( int y = 0; y < colunas; y++ )
      {
         fprintf ( arquivo, "%2.3lf\t", matriz [ x ][ y ] );
      }
      fprintf ( arquivo, "\n" );
   }
   
   fclose ( arquivo );
}

void gravarMatrizInt ( int linhas, int colunas, int matriz[][colunas], chars fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "%d\n", linhas );
   fprintf ( arquivo, "%d\n", colunas );
   
   for ( int x = 0; x < linhas; x++ )
   {
      for ( int y = 0; y < colunas; y++ )
      {
         fprintf ( arquivo, "%d\t", matriz [ x ][ y ] );
      }
      fprintf ( arquivo, "\n" );
   }
   
   fclose ( arquivo );
}

void method01 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0.0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      double matrix [ lines ][ columns ];
      printf ( "Digite os valores da matriz.\n" );
      for ( int i = 0; i < lines; i++ )
      {
         for ( int y = 0; y < columns; y++ )
         {
            do
            {
               valor = IO_readdouble ( "" );
            } while ( valor <= 0 );
            matrix [i][y]= valor;
         }
      }
         
      mostrarMatriz ( lines, columns, matrix );
      gravarMatriz ( lines, columns, matrix, "MATRIZ01.txt" );
   }
   IO_pause ( "Aperte ENTER para terminar." );
}

void method02 ( )
{
   FILE* arquivo = fopen ( "MATRIZ01.txt", "rt" );
   
   int x = 0;
   int y = 0;
   double a = 0.0;
   int b = 0;
   
   fscanf ( arquivo, "%d", &x );
   fscanf ( arquivo, "%d", &y );
   
   double matriz [x][y];
   
   for ( int i = 0; i < x; i++ )
   {
      for ( int j = 0; j < y; j++ )
      {
         fscanf ( arquivo, "%lf\t", &a );
         matriz [i][j] = a;
      }
   }
   
   fclose ( arquivo );
   
   for ( int i = 0; i < x; i++ )
   {
      for ( int j = 0; j < y; j++ )
      {
         printf ( "%2.3lf\t", matriz [i][j] );
      }
      printf ( "\n" );
   }
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method03 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nDiagonal principal: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               if ( a == b )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
               }
               else
               {
                  printf ( "\t" );
               }
            }
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method04 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int m = columns;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nDiagonal secundaria: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               if ( (b == (m-1)) )
               {   
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  m--;
               }
               else
               {
                  printf ( "\t" );
               }
            }
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method05 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int l = 1;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores abaixo da diagonal principal: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < l; b++ )
            {  
               if ( a == l && b < l )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  if ( b == l-1 )
                  l++;
               }
               else
               {
                  printf ( "\t" );
               }
            }
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method06 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int l = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores acima da diagonal principal: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               if ( ( a == l && b > l && b < columns ) )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  if ( b == lines-1 )
                  l++;
               }
               else
               {   
                  printf ( "\t\t" );  
               }
            }
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method07 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int m = (columns-1);
   int l = 1;
   int x = ( columns - 2 );
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores abaixo da diagonal secundaria: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns ; b++ )
            {  
               if ( a == l && b > x )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  if ( b == m )
                  {
                     l++;
                     x--;
                  }
               }
               else
               {   
                  printf ( "\t\t" );  
               }
            }
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method08 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int m = (columns-1);
   int x = ( columns - 2 );
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor <= 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores acima da diagonal secundaria: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns ; b++ )
            {    
               if ( b < m )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
               }
               else
               {   
                  printf ( "\t\t" );  
               }
            }
            m--;
            printf ( "\n" );
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method09 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int l = 1;
   int cont = 0;
   int cont1 = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor < 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores abaixo da diagonal principal: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < l; b++ )
            {  
               if ( a == l && b < l )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  cont++;
                  if ( matrix [ a ][ b ] == 0 )
                  {
                     cont1++;
                  }
                  if ( b == l-1 )
                  l++;
               }
               else
               {
                  printf ( "\t\t" );
               }
            }
            printf ( "\n" );
         }
         if ( cont == cont1 )
         {
            IO_println ( "Todos os valores abaixo da diagonal principal sao nulos." );
         }
         else
         {
            IO_println ( "Nem todos ou nenhum valor abaixo da diagonal principal sao nulos." );
         }
      }
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method10 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   double valor = 0;
   int l = 0;
   int cont = 0;
   int cont1 = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      if ( lines != columns )
      {
         printf ( "Nao e' uma matriz quadrada.\n" );
      }
      else
      {
         double matrix [ lines ][ columns ];
         printf ( "Digite os valores da matriz.\n" );
         for ( int i = 0; i < lines; i++ )
         {
            for ( int y = 0; y < columns; y++ )
            {
               do
               {
                  valor = IO_readdouble ( "" );
               } while ( valor < 0 );
               matrix [i][y]= valor;
            }
         }
         
         IO_println ( "\nMatriz: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               printf ( "%2.3lf\t", matrix [ a ][ b ] );
            }
            printf ( "\n" );
         }
         
         IO_println ( "\nValores acima da diagonal principal: " );
         
         for ( int a = 0; a < lines; a++ )
         {
            for ( int b = 0; b < columns; b++ )
            {  
               if ( ( a == l && b > l && b < columns ) )
               {
                  printf ( "%2.3lf\t", matrix [ a ][ b ] );
                  cont++;
                  if ( matrix [ a ][ b ] == 0 )
                  {
                     cont1++;
                  }
                  if ( b == lines-1 )
                  l++;
               }
               else
               {   
                  printf ( "\t\t" );  
               }
            }
            printf ( "\n" );
         }
         
         if ( cont == cont1 )
         {
            IO_println ( "Todos os valores acima da diagonal principal sao nulos." );
         }
         else
         {
            if ( cont1 != 0 ) 
            {
               IO_println ( "Algum/alguns dos valores acima da diagonal principal sao nulos." );
            }
            else
            {
               IO_println ( "Os valores acima da diagonal principal nao sao nulos." );
            }
         }
      }  
   }
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method11 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   int a = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      int matrix [ lines ][ columns ];
      for ( int i = 0; i < lines; i++ )
      {
         for ( int y = 0; y < columns; y++ )
         {
            matrix[i][y] = a+1;
            a++;
         }
      }
      
      IO_println ( "\nMatriz: " );
      
      for ( int a = 0; a < lines; a++ )
      {
         for ( int b = 0; b < columns; b++ )
         {  
            printf ( "%d\t", matrix [ a ][ b ] );
         }
   
         printf ( "\n" );
      }
      
      gravarMatrizInt ( lines, columns, matrix, "MATRIZ11.txt" );
   }
   IO_pause ( "Aperte ENTER para terminar." );
}

void method12 ( )
{
   int lines = IO_readint ( "Digite a quantidade de linhas: " );
   int columns = IO_readint ( "Digite a quantidade de colunas: " );
   int a = 0;
   
   if ( lines <= 0 || columns <= 0 )
   {
      IO_println ( "Valor invalido." );
   }
   else
   {
      int matrix [ lines ][ columns ];
      for ( int i = 0; i < columns; i++ )
      {
         for ( int y = 0; y < lines; y++ )
         {
            matrix[y][i] = a+1;
            a++;
         }
      }
      
      IO_println ( "\nMatriz: " );
      
      for ( int a = 0; a < lines; a++ )
      {
         for ( int b = 0; b < columns; b++ )
         {  
            printf ( "%d\t", matrix [ a ][ b ] );
         }
   
         printf ( "\n" );
      }
      gravarMatrizInt ( lines, columns, matrix, "MATRIZ12.txt" );
   }
   IO_pause ( "Aperte ENTER para terminar." );
}

int main ( )
{
   int x = 0;
   
   do
   {
      // identificar
      IO_id ( "EXEMPLO0911 - Programa - v0.1" );
      
      // opcoes
      IO_println ( "1  - Mostrar matriz." );
      IO_println ( "2  - Gravar matriz em arquivo" );
      IO_println ( "3  - Mostrar somente os valores na diagonal principal de uma matriz real quadrada." );
      IO_println ( "4  - Mostrar somente os valores na diagonal secundaria de uma matriz real quadrada." );
      IO_println ( "5  - Mostrar somente os valores abaixo da diagonal principal de uma matriz real quadrada." );
      IO_println ( "6  - Mostrar somente os valores acima da diagonal principal de uma matriz real quadrada." );
      IO_println ( "7  - Mostrar somente os valores abaixo da diagonal secundaria de uma matriz real quadrada." );
      IO_println ( "8  - Mostrar somente os valores acima da diagonal secundaria de uma matriz real quadrada." );
      IO_println ( "9  - Testar se sao todos nulos os valores abaixo da diagonal principal de uma matriz real quadrada." );
      IO_println ( "10 - Testar se nao sao nulos os valores acima da diagonal principal de uma matriz real quadrada." );
      IO_println ( "11 - Montar uma matriz em ordem crescente linha/coluna e grava-la em aqruivo." );
      IO_println ( "12 - Montar uma matriz em ordem crescente coluna/linha e grava-la em aqruivo." );
      x = IO_readint ("\nEscolha uma opcao: ");
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         default:
            printf ( "INVALID VALUE!");
            break;
      }
   }
   while ( x != 0 );
   
   IO_pause ( "Aperte ENTER para terminar. ");
   return ( 0 );
}

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

 * No E1 e E2, era pra ser s� matrizes quadradas, ou pode ser qualquer matriz? 
 
---------------------------------------------- previsao de testes
a.) 1, 2 e 3
      { 1, 2, 3, 4, 5, 6 }
      
b.) 2

c.) 3, 3 e 3
      { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
      
d.) 4, 2 e 2
      { 1, 2, 3, 4 }
      
e.) 5, 3 e 3
      { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
      
f.) 6, 3 e 3
      { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
      
g.) 7, 3 e 3
      { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
      
h.) 8, 3 e 3
      { 1, 2, 3, 4, 5, 6, 7, 8, 9 }
       
i.) 9, 3 e 3
      { 1, 2, 3, 0, 5, 6, 0, 0, 9 } 
      
j.) 10, 3 e 3
      { 1, 0, 0, 4, 5, 0, 7, 8, 9 }
      
k.) 11, 3 e 2

l.) 12, 5 e 3

---------------------------------------------- resultados
a.) 1.000 2.000 3.000
    4.000 5.000 6.000
    
b.) 1.000 2.000 3.000	
    4.000 5.000 6.000

c.)  Matriz: 
     1.000 2.000 3.000	
     4.000 5.000 6.000	
     7.000 8.000 9.000	
     
     Diagonal principal: 
     1.000			
     	     5.000		
     	           9.000	

d.) Matriz: 
    1.000 2.000	
    3.000 4.000	
    
    Diagonal secundaria: 
    	    2.000	
    3.000		

e.) Matriz: 
    1.000 2.000 3.000	
    4.000 5.000 6.000	
    7.000 8.000 9.000	
    
    Valores abaixo da diagonal principal: 
    	
    4.000		
    7.000 8.000		

f.) Matriz: 
    1.000 2.000 3.000	
    4.000 5.000 6.000	
    7.000 8.000 9.000	
    
    Valores acima da diagonal principal: 
    		2.000	3.000	
    				6.000

g.) Matriz: 
    1.000 2.000 3.000	
    4.000 5.000 6.000	
    7.000 8.000 9.000	
    
    Valores abaixo da diagonal secundaria:
               6.000
      	8.000	9.000

h.) Matriz: 
    1.000 2.000 3.000	
    4.000 5.000 6.000	
    7.000 8.000 9.000	
    
    Valores acima da diagonal secundaria:
    1.000 2.000			
    4.000

i.) Matriz: 
    1.000 2.000 3.000	
    0.000 5.000 6.000	
    0.000 0.000 9.000	

    Valores abaixo da diagonal principal:
    0.000
    0.000 0.000
    
    Todos os valores abaixo da diagonal principal sao nulos.

j.)  Matriz: 
     1.000 0.000 0.000
     4.000 5.000 0.000	
     7.000 8.000 9.000	
     
     Valores acima da diagonal principal: 
     0.000 0.000	
           0.000
           
     Todos os valores acima da diagonal principal sao nulos.

k.) Matriz: 
    1.000 2.000
    3.000 4.000
    5.000 6.000

l.) Matriz: 
    1.000 6.000 11.000	
    2.000 7.000 12.000	
    3.000 8.000 13.000	
    4.000 9.000 14.000	
    5.000 10.000 15.000	

---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          03/05                            esboco
              |
              |
              |
              04/05
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
              11. ( OK )
              12. ( OK )
*/