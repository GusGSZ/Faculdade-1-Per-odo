/**
   Exemplo01E1
   @author 656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 21/02/2019
  */
  
  //dependencias
  #include <stdio.h>
  #include <math.h>
  
  int main(int argc, char* argv[]){
     float diag1 = 0, diag2 = 0, area = 0, perimetro = 0, lado = 0, quad1 = 0, quad2 = 0;
     
     printf("%s\n", "Informe a medida da diagonal maior do losango.");
     scanf("%f", &diag1);
     
     printf("%s\n", "Informe a medida da diagonal menor do losango.");
     scanf("%f", &diag2);
     
     //operacoes
     area = (diag1 * diag2) / 2;
     quad1 = pow((diag1/2),2);
     quad2 = pow((diag2/2),2);
     lado = sqrt(quad1 + quad2);
     perimetro = lado * 4;
     
     //mostrar resultados
     printf("%s%f\n", "A area do losango e:", area);
     printf("%s%f\n", "O perimetro do losango e:", perimetro);
     
     //encerrar
     printf("/n/n Aperte ENTER para encerrar.");
     fflush(stdin);
     getchar();
     return(0);
  }
   