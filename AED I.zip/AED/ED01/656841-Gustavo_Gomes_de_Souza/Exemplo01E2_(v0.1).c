/**
   Exemplo01E2
   @author 656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 21/02/2019
  */
  
  //dependencias
  #include <stdio.h>
  #include <math.h>
  
  int main(int argc, char* argv[]){
     float bmaior = 0, bmenor = 0, altura = 0, area = 0, perimetro = 0, lado = 0, hipotenusa = 0, cb = 0; 
     
     //ler e guardar valores do teclado
     printf("%s\n", "Digite a base maior do trapezio:");
     scanf("%f", &bmaior);
     
     printf("%s\n", "Digite a base menor do trapezio:");
     scanf("%f", &bmenor);
     
     printf("%s\n", "Digite a altura do trapezio:");
     scanf("%f", &altura);
     
     //operacoes
     area = ((bmaior + bmenor) * altura)/2;
     cb = bmaior - bmenor;
     hipotenusa = pow(altura,2) + pow(cb,2); 
     lado = sqrt(hipotenusa);
     perimetro = bmaior + bmenor + altura + lado;
     
     //mostrar resultados
     printf("%s%f\n", "A area do trapezio e:", area);
     printf("%s%f\n", "O perimetro do trapezio e:", perimetro);
     
     //encerrar
     printf("\n\n Aperte ENTER para encerrar.");
     fflush(stdin);
     getchar();
     return(0);
  }