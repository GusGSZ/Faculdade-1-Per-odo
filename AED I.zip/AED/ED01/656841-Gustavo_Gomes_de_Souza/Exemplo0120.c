/**
   Exemplo0120
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   #include <math.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float raio = 0, volume = 0;
   
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor do raio da esfera:");
   scanf("%f", &raio);
   
   //opera��es
   volume = (4 * M_PI * (raio * raio * raio)) / 3;
   
   //mostrar resultados
   printf("%s %f\n", "O volume da esfera e:", volume);
   
   //encerrar
   printf("\n\n Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }