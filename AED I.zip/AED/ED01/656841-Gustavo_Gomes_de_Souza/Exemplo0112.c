/**
   Exemplo0112
   @author 656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
*/

//depend�ncias

#include <stdio.h>

int main (int argc, char* argv[]){
   //declaracao de variaveis
   int x = 0, areaquadrado = 0, perimetro = 0;
   
   
   //ler do teclado
   printf ("%s\n", "Digite o lado do quadrado:");
   scanf("%d", &x);
   
   //opera��es
   areaquadrado = x*x;
   perimetro = x*4;

   //mostrar resultado 
   printf ("%s %d\n", "A area do quadrado e:", areaquadrado);
   printf ("%s %d\n", "O perimetro do quadrado e:", perimetro);
   
   //encerrar
   printf("\n\n Apertar ENTER para terminar.");
   fflush (stdin);   //limpar a entrada de dados
   getchar();       //aguardar por ENTER
   return(0);       //voltar ao SO (sem erros)
} //fim main()
   