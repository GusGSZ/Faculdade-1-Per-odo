/**
   Exemplo0117
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   #include <math.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float lado = 0, volume = 0;
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor do lado do cubo:");
   scanf("%f", &lado);
   
   //opera��es
   volume = lado * lado * lado;
   
   
   //mostrar resultados
   printf("%s %f\n", "O volume do cubo e:", volume);
   
   //encerrar
   printf("\n\n Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }