/**
   Exemplo0118
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   #include <math.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float comp = 0, largura = 0, altura = 0, volume = 0;
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor do comprimento do paralelepipedo:");
   scanf("%f", &comp);
   
   printf("%s\n", "Digite o valor da largura do paralelepipedo:");
   scanf("%f", &largura);
   
   printf("%s\n", "Digite o valor da altura do paralelepipedo:");
   scanf("%f", &altura);
   
   //opera��es
   volume = comp * largura * altura;
   
   //mostrar resultados
   printf("%s %f\n", "O volume do paralelepipedo e:", volume);
   
   //encerrar
   printf("\n\n Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }