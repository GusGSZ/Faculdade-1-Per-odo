/**
   Ed0103
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float base = 0, altura = 0, area = 0;
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor da base do triangulo:");
   scanf("%f", &base);
   
   printf("%s\n", "Digite o valor da altura do tri�ngulo:");
   scanf("%f", &altura);
   
   //opera��es
   area = base * altura;
   
   //mostrar resultados
   printf("%s %f\n", "A area do triangulo e:", area);
   
   //encerrar
   printf("Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }
   