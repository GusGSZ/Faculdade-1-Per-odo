/**
   Exemplo0111
   @author 656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
*/

//depend�ncias

#include <stdio.h>

int main (int argc, char* argv[]){
   //declaracao de variaveis
   int x = 0, areaquadrado = 0;
   
   
   //ler do teclado
   printf ("%s\n", "Digite um numero qualquer:");
   scanf("%d", &x);
   
   //opera��o
   areaquadrado = x*x;

   //mostrar resultado 
   printf ("%s %d\n", "A area do quadrado e:", areaquadrado);
   
   //encerrar
   printf("\n\n Apertar ENTER para terminar.");
   fflush (stdin);   //limpar a entrada de dados
   getchar();       //aguardar por ENTER
   return(0);       //voltar ao SO (sem erros)
} //fim main()
   