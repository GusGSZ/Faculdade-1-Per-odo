/**
   Ed0103
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   #include <math.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float lado = 0, altura = 0, area = 0, perimetro = 0;
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor do lado do triangulo:");
   scanf("%f", &lado);
   
   //opera��es
   altura = (lado * sqrt(3)) / 2;
   area = ((lado * lado) * sqrt(3))/4;
   perimetro = lado * 3;
   //mostrar resultados
   printf("%s %f\n", "A altura do triangulo e:", altura);
   printf("%s %f\n", "A area do triangulo e:", area);
   printf("%s %f\n", "O perimetro do triangulo e:", perimetro);   
   
   //encerrar
   printf("\n\n Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }