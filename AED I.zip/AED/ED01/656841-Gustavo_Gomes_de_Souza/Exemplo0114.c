/**
   Exemplo0114
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   
   int main(int argc, char* argv[])
   {
      //declaracao de variaveis
      int x = 0, y = 0, area = 0, perimetro = 0;
      
      //ler dados do teclado
      printf("%s\n", "Digite o valor da base:");
      scanf("%d", &x);
      
      printf("%s\n", "Digite o valor da altura:");
      scanf("%d", &y);
      
      //opera��es
      area = x*y;
      perimetro = x+y * 2;
      
      //mostrar resultados
      printf("%s %d\n", "A area do retangulo e:", area);
      printf("%s %d\n", "O perimetro do retangulo e:", perimetro);
      
      //encerrar
      printf("%s\n\n", "Aperte ENTER para encerrar.");
      fflush(stdin);
      getchar();
      return(0);
   }
   