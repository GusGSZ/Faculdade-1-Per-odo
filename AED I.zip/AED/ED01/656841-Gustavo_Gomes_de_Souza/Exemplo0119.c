/**
   Exemplo0119
   @author656841 - Gustavo Gomes de Souza
   @version v0.1
   @date 20/02/2019
   */
   
   //dependencias
   #include <stdio.h>
   #include <math.h>
   
   int main(int argc, char* argv[])
   {
   //declaracao de variaveis
   float raio = 0, area = 0;
   
   
   //ler dados do teclado
   printf("%s\n", "Digite o valor do raio do circulo:");
   scanf("%f", &raio);
   
   //opera��es
   area = M_PI * (raio * raio);
   
   //mostrar resultados
   printf("%s %f\n", "A area do circulo e:", area);
   
   //encerrar
   printf("\n\n Aperte ENTER para encerrar.");
   fflush(stdin);
   getchar();
   return(0);
   }