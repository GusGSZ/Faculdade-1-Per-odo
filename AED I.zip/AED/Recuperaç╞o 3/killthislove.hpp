/*
 killthislove.hpp - v0.1 - 30/05/2019
 Matricula: 656841
 Author: Gustavo Gomes de Souza
*/

// ----------------------------------------------- definicoes globais
#ifndef _KTL_H_
#define _KTL_H_

// dependencias
#include <iostream>
using std::cin ; // para entrada
using std::cout; // para saida
using std::endl; // para mudar de linha

#include <iomanip>
using std::setw; // para definir espacamento

#include <string>
using std::string; // para cadeia de caracteres

#include <fstream>
using std::ofstream; // para gravar arquivo
using std::ifstream ; // para ler arquivo

#include <math.h>

template <typename KTL>

class Vetor
{
   private:
      int tamanho;
      KTL* dados;
   
   public:
   
   Vetor ( int tam )
   {
      tamanho = tam;
      dados = new KTL[tam];
   }
   
   void liberar ( )
   {
      if ( dados != NULL )
      {
         delete (dados);
         dados = NULL;
      }
   }
   
   void set ( int posicao, KTL valor )
   {
      if ( posicao >= 0 && posicao <= tamanho )
      {
         dados[posicao] = valor;
      }// fim if( )
   }// fim set( )
   
   KTL get ( int posicao )
   {
      KTL valor = 0; // retorna valor do tipo dependencia ( KTL )
      if ( posicao >= 0 && posicao <= tamanho )
      {
         valor = dados [posicao];
      }// fim if( )
      
      return ( valor );
   }// fim get ( )

   string gett ( int posicao )
   {
      string valor = ""; // retorna valor do tipo dependencia ( KTL )
      if ( posicao >= 0 && posicao <= tamanho )
      {
         valor = dados [posicao];
      }// fim if( )
      
      return ( valor );
   }// fim get ( )
   
   void mostrar ( )
   {
      cout << endl;
      for ( int x = 0; x < tamanho; x++ )
      {
         cout << setw ( 2 ) << x << ":" << setw ( 3 ) << dados[x] << endl;
      }// fim for( )
   }// fim mostrar ( )
   
   void ler ( )
   {
      cout << endl;
      for ( int i = 0; i < tamanho; i++ )
      {
         cout << setw ( 2 ) << i << ":" << setw( 2 ) << "";
         cin >> dados[i];
      }// fim for( )
      cout << endl;
   }// fim ler ( )

   void lerBin ( )
   {
      int numero = 0;

      cout << endl;
      for ( int i = 0; i < tamanho; i++ )
      {
         do
         {
            cout << setw ( 2 ) << i << ":" << setw( 2 ) << "";
            cin >> numero;
            dados[i] = numero;
         } while ( numero != 0 && numero != 1 );
         
      }// fim for( )
      cout << endl;
   }// fim ler ( )
   
   void preencherRand ( int inf, int sup )
   {
      int aleatorio = 0;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         aleatorio = rand()%(sup-inf+1) + inf;
         dados[i] = aleatorio;
      }// fim for ( )
      
   }// fim preencherRand ( )
   
   void gravar ( string fileName )
   {
      // declaracao tipo de entrada para arquivo
      ofstream arquivo;
      // abrir arquivo
      arquivo.open ( fileName );
      //salvar tamanho em arquivo
      arquivo << tamanho << endl;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         //salvar dados em arquivo
         arquivo << dados[i] << endl;
      }// fim for( )
      
      //fechar arquivo
      arquivo.close ( );
   }// fim gravar( )
   
   void lerArq ( string fileName )
   {
      //declaracao de tipo arquivo saida
      ifstream arquivo;
      //declarar dados
      int tam = 0;
      // abrir arquivo
      arquivo.open( fileName );
      // ler tamanho da primeira linha do arquivo
      arquivo >> tam;
      
      if ( tam == 0 )
      {
         cout << "\nERROR: Tamanho invalido.\n" << endl;
      }
      else
      {
         //guardar a quantidade de dados
         tamanho = tam;
         //reservar espaco
         dados = new KTL[tamanho];
         //ler dados
         for ( int i = 0; i < tamanho; i++ )
         {
            arquivo >> dados[i];
         }// fim for( )
      }// fim if-else( )
      //fechar arquivo
      arquivo.close ( );
   }

   void lerarqn ( string fileName, int n )
   {
      //declaracao de tipo arquivo saida
      ifstream arquivo;
      //declarar dados
      int tam = 0;
      // abrir arquivo
      arquivo.open( fileName );
      // ler tamanho da primeira linha do arquivo
      arquivo >> tam;
      
      /*
      if ( tam <= 0 || n <= 0 || n > tam )
      {
         cout << "\nERROR: Tamanho invalido.\n" << endl;
      }
      else
      {*/
         if( arquivo.good() )
         {
            //guardar a quantidade de dados
            tamanho = n;
            //reservar espaco
            dados = new KTL[tamanho];
            //ler dados
            for ( int i = 0; i < n; i++ )
            {
               arquivo >> dados[i];
            }// fim for( )
         }
         else
         {
            cout << "arquivo vazio." << endl;
         }
      //}// fim if-else( )
      //fechar arquivo
      arquivo.close( );
   }
   
   int tam ( string fileName )
   {
      //declaracao de tipo arquivo saida
      ifstream arquivo;
      //declarar dados
      int tam = 0;
      // abrir arquivo
      arquivo.open( fileName );
      // ler tamanho da primeira linha do arquivo
      arquivo >> tam;
      //fechar arquivo
      arquivo.close ( );
      // retornar valor
      return tam;
   }
   
   int acharMaior ( )
   {
      // definicao de dados
      int maior = 0;
      
      // procurar maior valor em vetor
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] > maior )
            maior = dados[i];
         // fim if ( )
      }// fim for ( )
      
      // retornar maior valor
      return ( maior );
   }
   
   int acharMenor ( )
   {
      // definicao de dados
      int menor = dados[0];
      
      // procurar menor valor em vetor
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] < menor )
            menor = dados[i];
         // fim if ( )
      }// fim for( )
      
      //retornar menor valor do vetor
      return ( menor );
   }
   
   int somar ( )
   {
      int soma = 0;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         soma = soma + dados[i];
      }
      
      return soma;
   }
   
   double media ( )
   {
      int soma = 0;
      double media = 0.0; 
      
      for ( int i = 0; i < tamanho; i++ )
      {
         soma = soma + dados[i];
      }
      
      media = (double)soma/(double)tamanho;
      
      return media;
   }
   
   bool zeros ( )
   {
      bool zero = true;
      
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] != 0 )
            zero = false;
      }
      
      return zero;
   } // fim zeros ( )
   
   bool ordenado ( )
   {
      // definicao de dados
      int maior = 0;
      int menor = 0;
      int tf = 0;
      
      maior = dados[0];
      for ( int i = 1; i < (tamanho-1); i++ )
      {
         menor = dados[i];
         if ( maior < menor )
         {
            tf++;
         }
         else
         {
            maior = menor;
         }
         
      }// fim for ( )
      
      // retorno booleano
      if ( tf > 0 )
         return false;
      else
         return true;
      
   } // fim ordenado ( )
   
   bool procurado ( int procurado, int posini, int posfin )
   {
      int a = 0;
      
      for ( int i = posini; i <= posfin; i++ )
      {
         if ( dados[i] == procurado )
         {
            a++;
         }
      }
      
      if ( a != 0 )
         return true;
      else
         return false;
   }
   
   Vetor escalar ( int constante, Vetor vetor )
   {
      for ( int i = 0; i < vetor.tamanho; i++ )
      {
         vetor.dados[i] = vetor.dados[i] * constante;
      }
      
      return ( vetor );
   }
   
   void decrescente ( )
   {
      int aux = 0;
      int aux2 = 0;
      int cont = 0;
      
      do
      {
         cont = 0;
         
         for ( int i = (tamanho-1); i > 0; i-- )
         {  
            if ( dados[i] > dados[i-1] )
            {
               aux  = dados[i];
               aux2 = dados[i-1];
               dados[i]   = aux2;
               dados[i-1] = aux;
            }
         }
         
         for ( int i = (tamanho-1); i > 0; i-- )
         {  
            if ( dados[i] > dados[i-1] )
            {
               cont++;
            }
         }
         
      }while(cont > 0);
         
      mostrar( );
   }
   
   int tam ( Vetor vetor )
   {
      int tam = tamanho;
      return tam;
   }
   
   /**
      operador (!=).
   */
   bool operator!= ( const Vetor <KTL> jennie )
   {
      int i = 0;
      int t = 0;
      
      if ( tamanho <= 0 || tamanho != jennie.tamanho )
      {
         cout << "Tamanhos diferentes." << endl;
         return true;
      }
      else
      {
         while ( i < this->tamanho )
         {
            if ( dados[i] != jennie.dados[i] )
               t++;
            i++;
         }
         
         if ( t != 0 )
         {
            return true;
         }
         else
         {
            return false;
         }
      }
   }
   
   /**
      operador (-).
   */
   Vetor& operator- ( const Vetor <KTL> rose )
   {
      static Vetor <KTL> soma ( rose.tamanho );
      
      if ( rose.tamanho <= 0 || tamanho != rose.tamanho )
      {
         cout << "Tamanho invalido ou diferente." << endl;
      }
      else
      {
         for ( int i = 0; i < this->tamanho; i++ )
         {
            soma.dados[i] = dados[i] - rose.dados[i];
         }
      }
      
      return (soma);
   }
   
   bool decrescente2 ( )
   {
   // declaracao de dados
      bool result = true;

   // executar
      for ( int i = 0; i < tamanho; i++ )
      {
         if ( dados[i] < dados[i+1] )
         {
            result = false;
            i = tamanho;
         }
      } // fim decrescente

   // retornar resultado
      return result;
   } // fim decrescente

   void crescente ( int n )
   {
   // declaracao de dados
      ofstream arquivo;
      arquivo.open("CRESCENTES.txt");
      int aux = 0;
   // gravar tamanho na primeira linha do arquivo
      arquivo << tamanho << endl;

   // executar
      for ( int i = 0; i <= n; i++ )
      {
         for ( int j = n - 1; j > i; j-- )
         {
            if ( dados[j] < dados[j-1] )
            {
               aux = dados[j-1];
               dados[j-1] = dados[j];
               dados[j] = aux;
            }
         }
      }

   // gravar resultado
      for ( int x = 0; x < n; x++ )
      {
         arquivo << dados[x] << "\n";
      }
   
      arquivo.close();
   } // fim crescente

   void comuns ( Vetor <int> arranjo2, int n )
   {
   // declaracao de dados
      Vetor <int> ncomum ( this->tamanho );
      FILE* arquivo = fopen ( "FILTRADOS.txt", "wt" );
      int cont = 0;

   // executar 
   if ( n < 0 || n > this->tamanho || n > arranjo2.tamanho )
   {
      cout << "Valor do n invalido." << endl;
   }
   else
   {
      for ( int i = 0; i < n; i++ )
      {
         for ( int j = 0; j < n; j++ )
         {
            if ( this->dados[j] == arranjo2.dados[i] )
            {
               cont++;
               ncomum.dados[i] = this->dados[j];
            }
         }
      }
      for ( int x = 0; x < cont; x++ )
      {
         fprintf ( arquivo, "%d\n", ncomum.dados[x] );
      }
   }

      fclose(arquivo);

      ncomum.mostrar();
   } // fim comuns

   Vetor inverter ( Vetor vetor2, int n )
   {
   // definir dados
      int j = 0;
   // abrir arquivo
      ofstream arquivo;
      arquivo.open("INVERTIDOS.txt");

      arquivo << n << endl;
      
   // executar
      for ( int i = (n-1); i >= 0; i-- )
      {
         vetor2.dados[j] = dados[i];
         arquivo << vetor2.dados[j] << endl;
         j++;
      }
      arquivo.close();

      return vetor2;
   } // fim inverter

   int converter ()
   {
      int x = 0;
      int pot = 0;
      int total = 0;
      int a = 0;
      
      for ( int i = 0; i < this->tamanho; i++ )
      {
         a = pow ( 2, i ) * dados[this->tamanho - (i+1)];
         total = total + a;
      }
      
      return total;
   }

};

template <typename KTL>
class Matriz
{
   private:
      int linhas;
      int colunas;
      KTL** dados;

   public:
      
      Matriz ( int lines, int columns )
      {
      // definir valores iniciais
         linhas = lines;
         colunas = columns;
      // reservar area
         dados = new KTL* [linhas];
         for ( int i = 0; i < linhas; i++ )
         {
            dados[i] = new KTL [ columns ];
         }// end for( )
      }// end Matriz ( )
      
      void liberar ( )
      {
         if ( dados != NULL )
         {
            for ( int i = 0; i < linhas; i++ )
            {
               delete(dados[i]);
            }// end for( )
            delete ( dados );
         }// end if ( )
      }// end liberar( )
      
      void set( int linha, int coluna, KTL valor )
      {
         if ( linha <= 0 || linha > linhas || coluna <= 0 || coluna > colunas )
            cout << "Posicao invalida." << endl;
         else
            dados[linha][coluna] = valor;
      }// end set( )
      
      KTL get ( int linha, int coluna )
      {
      // definicoes iniciais
         KTL valor = 0;
         
         if ( linha <= 0 || linha > linhas || coluna <= 0 || coluna > colunas )
         {
            cout << "Posicao invalida." << endl;
         }
         else
         {
            valor = dados[linha][coluna];
         }
      // retornar valor na posicao indicada
         return ( valor );
      }// end get( )
      
      void mostrar ( )
      {
         cout << endl;
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int x = 0; x < colunas; x++ )
            {
               cout << dados[i][x] << "\t";
            }// end for( )
            cout << endl;
         }// end for( )
         cout << endl;
      }// end mostrar( )
      
      void preencher( )
      {
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int x = 0; x < colunas; x++ )
            {
               cout << setw(3) << i << ", " <<  x << ":" << setw(1) << "";
               cin >> dados[i][x];
            }// end for( )
         }// end for( )
      }// end preencher( )
      
      void preencherAleatorio( int inferior, int superior )
      {
         KTL valor = 0;
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               valor = rand()%(superior-inferior+1) + inferior;
               dados[i][j] = valor;
            }// end for( )
         }// end for( )
      }// end preencherAleatorio( )
      
      void gravar( string fileName )
      {
         ofstream arquivo;
         arquivo.open ( fileName );

         arquivo << linhas << endl;
         arquivo << colunas << endl;
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               arquivo << dados[i][j] << endl;
            }// end for( )
         }// end for( )
         
         arquivo.close( );
      }// end gravar( )
      
      void lerArq ( string fileName )
      {
         ifstream arquivo;
         
         arquivo.open ( fileName );
         
         int linhas = 0;
         int colunas = 0;
         
         arquivo >> linhas;
         arquivo >> colunas;
         
         if ( linhas <= 0 || colunas <= 0 )
         {
            cout << "Dimensoes invalidas." << endl;
         }
         else
         {  
            this->linhas = linhas;
            this->colunas = colunas;
            dados = new KTL* [this->linhas];
            for ( int i = 0; i < this->linhas; i++)
            {
               dados[i] = new KTL [this->colunas];
            }// end for( )
            
            for ( int i = 0; i < this->linhas; i++)
            {
               for ( int j = 0; j < this->colunas; j++ )
               {
                  arquivo >> dados[i][j];
               }// end for( )
            }// end for( )
         }// end if( )
         
         arquivo.close( );
      }
      
      int linhass ( )
      {
         int linha = 0;
         linha = this->linhas;
         return ( linha );
      }
      
      int colunass ( )
      {
         int coluna = 0;
         coluna = this->colunas;
         return ( coluna );
      }
      
      Matriz escalar ( int constante )
      {
         static Matriz <KTL> matriz2( linhas, colunas );
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               matriz2.dados[i][j] = dados[i][j] * constante;
            }
         }
         
         return ( matriz2 );
      }
      
      bool isIdentity ( )
      {
      // definir dados
         int um = 0;
         int zero = 0;
         
         if ( linhas == colunas )
         {
            // testar cada posicao
            for ( int i = 0; i < linhas; i++ )
            {
               for ( int j = 0; j < colunas; j++ )
               {
                  if ( i == j )
                  {
                     if ( dados[i][j] == 1 )
                        um++;
                  }
                  else
                  {
                     if ( dados[i][j] == 0 )
                        zero++;
                  }// end if( )
               }// end for ( )
            }// end for( )
         
            if ( um == linhas && zero == (linhas*colunas-3))
               return true;
            else
               return false;
         }
         else
         {
            return false;
         }
      }
      
      bool operator== ( Matriz <KTL> matriz2 )
      {
         bool result = true;
         
         if ( linhas != matriz2.linhas || colunas != matriz2.colunas )
         {
            result = false;
         }
         else
         {
            for ( int i = 0; i < linhas; i++ )
            {
               for ( int j = 0; j < colunas; j++ )
               {
                  result = result && ( dados[i][j] == matriz2.dados[i][j] );
               }
            }
            
            
         }// end if( )
         
         return result;
      }// end operator==
      
      /**
         operador (+).
      */
      Matriz& operator+ ( const Matriz <KTL> rosa )
      {
         static Matriz <KTL> soma ( rosa.linhas, rosa.colunas );
         
         if ( linhas <= 0 || linhas != rosa.linhas || rosa.linhas <= 0 
         || colunas <= 0 || colunas  != rosa.colunas || rosa.colunas <= 0 )
         {
            cout << "Tamanho invalido ou diferente." << endl;
         }
         else
         {
            for ( int i = 0; i < this->linhas; i++ )
            {
               for ( int j = 0; j < this->colunas; j++ )
               {
                  soma.dados[i][j] = dados[i][j] + rosa.dados[i][j];
               }
            }
         }
         
         return (soma);
      }// end operator+
      
      Matriz addLines ( int l1, int l2, int constante )
      {  
         if ( l1 >= linhas || l2 >= linhas || l1 < 0 || l2 < 0 )
         {
            cout << "Linha invalida." << endl;
         }
         else
         {
            for ( int i = 0; i < linhas; i++ )
            {
               for ( int j = 0; j < colunas; j++ )
               {
                  if ( i == l1 )
                  {
                     dados[l1][j] = dados[i][j] + (dados[l2][j] * constante );
                  }
                  else
                  {
                     dados[i][j] = dados[i][j];
                  }// end if( )
               }// end for( )
            }// end for( )
         }// end if( )
         return *this;
      }// end addLines( )
      
      Matriz addColumns ( int c1, int c2, int constante )
      {
         if ( c1 >= colunas || c2 >= colunas || c1 < 0 || c2 < 0 )
         {
            cout << "Coluna invalida." << endl;
         }
         else
         {
            for ( int i = 0; i < linhas; i++ )
            {
               for ( int j = 0; j < colunas; j++ )
               {
                  if ( j == c1 )
                  {
                     dados[i][c1] = dados[i][j] - (dados[i][c2] * constante );
                  }
                  else
                  {
                     dados[i][j] = dados[i][j];
                  }// end if( )
               }// end for( )
            }// end for( )
         }
         return *this;
      }// end addColumns( )
      
      int procurarNaLinha ( int procurado )
      {  
      // definir dados
         int result = 0;
         int cont = 0;
         
      // procurar valor na matriz
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               if ( dados[i][j] == procurado )
               {
                  cont++;
               // se encontrado, atribuir valor da linha
                  result = i;
               }
            }// end for( )
         }// end for( )
         
         // retornar linha que o valor esta' se existir
         if ( cont != 0 )
         {
            return result;
         }
         else
         {
            return (-1);
         }
      }// end procurarNaLinha( )
      
      int procurarNaColuna ( int procurado )
      {  
      // definir dados
         int result = 0;
         int cont = 0;
         
      // procurar valor na matriz
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               if ( dados[i][j] == procurado )
               {
                  cont++;
               // se encontrado, atribuir valor da coluna
                  result = j;
               }
            }// end for( )
         }// end for( )
         
         // retornar coluna que o valor esta'
         if ( cont != 0 )
         {
            return result;
         }
         else
         {
         // retornar -1 se nao encontrado
            return (-1);
         }
      }// end procurarNaColuna( )
      
      Matriz& transpor ( )
      {               
      // definir matriz copia
         static Matriz <KTL> transposta ( this->linhas, this->colunas );
      // ler mesma matriz de arquivo
         transposta.lerArq( "DADOS1.TXT" );
      // trocar dimensoes da matriz original
         int linhas = this->linhas;
         int colunas = this->colunas;
         
         this->linhas = colunas;
         this->colunas = linhas;
      // trocar valores de posicao
         for ( int i = 0; i < colunas; i++ )
         {
            for ( int j = 0; j < linhas; j++ )
            {
               dados[i][j] = transposta.dados[j][i];
            }// end for( )
         }// end for( )
      // retornar matriz original transposta
         return *this;
      }// end transpor( )
      
      bool naSequencia ( )
      {
      // definir dados
         int cont = 0;
         int z = 0;
         
      // testar se esta' na sequencia proposta
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               if ( i == 0 && j == 0)
               {
                  if ( dados[i][j] == linhas*colunas )
                     cont++;
               }
               else
               {
                  if ( dados[i][j] == ((linhas*colunas)-z) )
                     cont++;
               }// end if( )
               z++;
            }// end for( )
         }// end for( )
         
      // verificar se contador de valores na sequencia/posicoes certas e' igual a quantidade de valores na matriz
         if ( cont == (linhas*colunas) )
         {
            return true;
         }
         else
         {
            return false;
         }// end if( )
         
      }// end naSequencia( )
      
      Matriz& criarNaSequencia( int lines, int columns )
      {
         this->linhas = lines;
         this->colunas = columns;
         int z = 0;
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
               if ( i == 0 && j == 0 )
                  dados[i][j] = linhas*colunas;
               else
                  dados[i][j] = (linhas*colunas-z);
                  
               z++;
            }
         }
         
         return *this;
      }// end criarNaSequencia( )

   // cria matrizes em ordem crescente por coluna. 
   /* Ex:
      1 2 3
      4 5 6
      7 8 9
   */    
      Matriz& criarNaSequencia2( int lines, int columns )
      {
         this->linhas = lines;
         this->colunas = columns;
         int z = 1;
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
                  dados[i][j] = z;
                  z++;
            }
         }
         
         return *this;
      }// end criarNaSequencia2( )
   
   // cria matrizes em ordem crescente por linha. 
   /* Ex:
      1 4 7
      2 5 8
      3 6 9
   */    
      Matriz& criarNaSequencia3( int lines, int columns )
      {
         this->linhas = lines;
         this->colunas = columns;
         int z = 1;
         
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
                  dados[j][i] = z;
                  z++;
            }
         }
         
         return *this;
      }// end criarNaSequencia3( )

   // cria matrizes em ordem crescente por linha. 
   /* Ex:
      1 4 7
      2 5 8
      3 6 9
   */    
      Matriz& criarNaSequencia4( int lines, int columns )
      {
         this->linhas = lines;
         this->colunas = columns;
         int z = 1;
         int pot = 0;
         
         for ( int i = 0; i < linhas; i++ )
         {
            pot = 0;
            for ( int j = 0; j < colunas; j++ )
            {
                  dados[i][j] = pow ( z, pot );
                  pot++;
            }
            z++;
         }
         
         return *this;
      }// end criarNaSequencia4( )

      bool listrada ( int linhas, int colunas, int qtd )
      {
         int valor = 0, cont = 0, cont1 = 0, cont2 = 0, sub = 0, x = 0, z = 1;

         for ( int a = 0; a < qtd; a++ )
         {
            valor = dados[a][a];
            cont = 0;
            cont1 = 0;

            for ( int i = 0; i < linhas; i++ )
            {
                  for ( int j = 0; j < colunas; j++ )
                  {
                     if ( i == x || i == (linhas-z))
                     {
                        if ( dados[i][j] == valor )
                              cont1++;
                        cont++;
                     } 
                     else if ( j == x || j == (colunas - z ))
                     {
                        if ( dados[i][j] == valor )
                              cont1++;
                        cont++;
                     }
                  }
            }
            cont = cont - (sub*2);
            if ( cont1 == cont )
                  cont2++;
            sub = z * 4;
            x++;
            z++;
         }

         if ( cont2 == qtd )
            return true;
         else
            return false;
      }

      bool igual ( Matriz <int> matriz2 )
      {
         bool result = true;
         
         if ( linhas != matriz2.linhas || colunas != matriz2.colunas )
         {
         result = false;
         }
         else
         {
         for ( int i = 0; i < linhas; i++ )
         {
            for ( int j = 0; j < colunas; j++ )
            {
                  result = result && ( dados[i][j] == matriz2.dados[i][j] );
            } // end for( )
         } // end for( )
         
         }// end if( )
         
         return result;
      }// end igual( )
      
      void lerArqQ ( string fileName )
      {
            ifstream arquivo;
            
            arquivo.open ( fileName );
            
            int linhas = 0;
            int colunas = 0;
            int qtd = 0;
            
            arquivo >> linhas;
            arquivo >> colunas;
            arquivo >> qtd;
            
            if ( linhas <= 0 || colunas <= 0 )
            {
               cout << "Dimensoes invalidas." << endl;
            }
            else
            {  
               this->linhas = linhas;
               this->colunas = colunas;
               dados = new KTL* [this->linhas];
               for ( int i = 0; i < this->linhas; i++)
               {
                  dados[i] = new KTL [this->colunas];
               }// end for( )
               
               for ( int i = 0; i < this->linhas; i++)
               {
                  for ( int j = 0; j < this->colunas; j++ )
                  {
                     arquivo >> dados[i][j];
                  }// end for( )
               }// end for( )
            }// end if( )
            
            arquivo.close( );
      }
};
#endif