/*
  Recuperação 3 - v0.1 - 14/06/2019
  Matricula: 656841
  Author: Gustavo Gomes de Souza
*/

// --------------------------------------------------- dependencias
#include <iostream> // cin - entrada, cout - saida, endl - mudanca de linha
#include <limits> // 
#include <string> // para cadeias de caracteres
#include <fstream> // para manipulacoes de/com arquivos

// --------------------------------------------------- definicoes globais
void pause ( std::string text )
{
    std::string dummy;
    std::cin.clear ( );
    std::cout << std::endl << text;
    std::cin.ignore( );
    std::getline( std::cin, dummy );
    std::cout << std::endl;
} // end pause( )

using namespace std;

// --------------------------------------------------- classes
#include "killthislove.hpp"

// --------------------------------------------------- struct
typedef
struct s_smercado
{
    string nome;
    int codigo;
    double preco;
}smercado;

// --------------------------------------------------- metodos

void method00( )
{
    // nao faz nada
} // fim method00( )

/**
    Method01
*/
void method01 ( )
{
// declaracao de dados
   int n = 0;
   Vetor <int> vetor ( 1 );

// ler do teclado
   cout << "Entre com o valor n a ser lido do arquivo: ";
   cin >> n;

// ler vetor de arquivo
   vetor.lerarqn( "DADOS.txt", n );

    vetor.mostrar();
// executar
   if ( vetor.decrescente2( ) )
   {
      vetor.gravar("CRESCENTES.txt");
   }
   else
   {
      vetor.crescente( n );
   }

// encerrar
   pause ("Aperte ENTER para continuar.");
} // fim method01

/**
 Method02
*/
void method02 ( )
{
// declaracao de dados
   int n = 0;
   Vetor <int> vetor ( 1 );

// ler do teclado
   cout << "Entre com o valor n a ser lido do arquivo: ";
   cin >> n;
   Vetor <int> vetor2 (n);

// ler do arquivo
   vetor.lerarqn( "CRESCENTES.txt", n );

    vetor.mostrar();
// executar
   vetor2 = vetor.inverter( vetor2, n );

   vetor2.mostrar();

// encerrar
   pause ("Aperte ENTER para continuar.");
} // fim method02

/**
 Method03
*/
void method03 ( )
{
// definicao de dados
   Vetor <int> vetor ( 1 );
   int maior = 0;

// ler vetor do arquivo  
   vetor.lerArq("DADOS.txt");

// executar e mostrar resultado
   cout << "O maior valor encontrado foi: " << vetor.acharMaior( ) << endl;

// encerrar
   pause ("Aperte ENTER para continuar.");
} // fim method03

/**
 Method04
*/
void method04 ( )
{
// declaracao de dados
   Vetor <int> vetor1 ( 1 );
   Vetor <int> vetor2 ( 1 );
   int n = 0;

// ler do teclado
   cout << "Entre com o valor n a ser lido do arquivo: ";
   cin >> n;

// ler do arquivo
   vetor1.lerarqn("DADOS1.txt", n );
   vetor2.lerarqn("DADOS2.txt", n );

// executar
   vetor1.comuns( vetor2, n );

// encerrar
   pause ("Aperte ENTER para continuar.");
} // fim method04

/**
 Method05
*/
void method05 ( )
{
//  definicao de dados
    int n = 0;
    int i = 0;
    int numero = 0;
    
    cout << "Quantos numeros serao digitados? " << endl;
    cin >> n;

    Vetor <int> vetor (n);

    vetor.lerBin( );

    cout << vetor.converter() << endl; // funcionando porem estranho

    pause( "Aperte ENTER para continuar." );
} // fim method05

void method06( )
{
//  definir dados
    int linhas = 0, colunas = 0;
//  entrada de dados
    cout << "Quantas linhas/colunas a matriz (quadrada) tera'? " << endl;
    cin >> linhas;
//  definir matriz
    Matriz <int> matriz ( linhas, linhas );
/* 
    criar matriz na sequencia 1 2 3  
                              4 5 6 
                              7 8 9
*/  
    matriz.criarNaSequencia2 ( linhas, linhas );
//  mostrar matriz
    matriz.mostrar();
//  encerrar
    pause ( "Aperte ENTER para continuar." );
} // fim method06( )

void method07( )
{
//  definir dados
    int linhas = 0, colunas = 0;
//  entrada de dados
    cout << "Quantas linhas/colunas a matriz (quadrada) tera'? " << endl;
    cin >> linhas;
//  definir matriz
    Matriz <int> matriz ( linhas, linhas );
/* 
    criar matriz na sequencia 1 4 7
                              2 5 8
                              3 6 9
*/  
    matriz.criarNaSequencia3 ( linhas, linhas );
//  mostrar matriz
    matriz.mostrar();
//  encerrar
    pause ( "Aperte ENTER para continuar." );
} // fim method07( )

void method08( )
{
//  definir dados
    int linhas = 0, colunas = 0;
//  entrada de dados
    cout << "Quantas linhas/colunas a matriz (quadrada) tera'? " << endl;
    cin >> linhas;
//  definir matriz
    Matriz <int> matriz ( linhas, linhas );
/* 
    criar matriz na sequencia 1 1 1
                              1 2 4
                              1 3 9
*/  
    matriz.criarNaSequencia4 ( linhas, linhas );
//  mostrar matriz
    matriz.mostrar();
//  encerrar
    pause ( "Aperte ENTER para continuar." );
} // fim method08( )

void method09( )
{
//  definir dados
    int linhas = 0, colunas = 0;
//  definir matriz
    Matriz <int> matriz1 ( 1, 1 );
    Matriz <int> matriz2 ( 1, 1 );
//  ler de arquivo
    matriz1.lerArqQ( "MATRIZ1.txt" );
    matriz2.lerArqQ( "MATRIZ2.txt" );
//  mostrar matriz
    matriz1.mostrar();
    matriz2.mostrar();
//  testar se sao iguais
    if ( matriz1.igual( matriz2 ) )
        cout << "Sao iguais." << endl;
    else    
        cout << "Sao diferentes." << endl;
    
//  encerrar
    pause ( "Aperte ENTER para continuar." );
} // fim method09( )

void method10( )
{
    int n = 0;
    smercado mercado;
    double precomedio = 0.0;
    double totprod = 0.0;
    
    cout << "De quantos supermercados os produtos serao avaliados?" << endl;
    cin >> n;

    Vetor <string> nomes(n);
    Vetor <double> precos(n);
    Vetor <int> cods(n);
    
    for ( int i = 0; i < n; i++ )
    {
        cout << "Qual o nome do supermercado?" << endl;
        cin >> mercado.nome;
        cout << "Qual o codigo do supermercado?" << endl;
        cin >> mercado.codigo;
        cout << "Qual o preco do produto nesse supermercado?" << endl;
        cin >> mercado.preco;
        totprod += mercado.preco;

        nomes.set(i, mercado.nome);
        precos.set(i, mercado.preco);
        cods.set(i, mercado.codigo);
    }

    precomedio = totprod/n;

    for ( int i = 0; i < n; i++ )
    {
        if ( precos.get(i) < precomedio )
            cout << "No supermercado " << nomes.gett(i) << " de codigo " << cods.get(i) << " o preco do produto esta' abaixo da media do preco desse produto." << endl;
    }

//  encerrar
    pause ( "Aperte ENTER para continuar." );
} // fim method10( )

// --------------------------------------------------- acao principal

/**
 * Funcao principal
 * @return codigo de encerramento
*/

int main ( int argc, char** argv )
{
// definir dado
    int x = 0;

// repetir ate desejar parar
    do
    {
    // mostrar menu de opcoes
        cout << "0 - Parar." << endl;
        cout << "1 - Ler um vetor de um arquivo e o colocar em ordem caso nao esteja." << endl;
        cout << "2 - Inverter o vetor do exercicio anterior." << endl;
        cout << "3 - Achar o maior valor no vetor lido em DADOS1.txt." << endl;
        cout << "4 - Filtrar e mostrar os elementos em comum achados nos vetors." << endl;
        cout << "5 - Converter binarios em decimais." << endl;
        cout << "6 - Criar matriz crescente comecando por colunas." << endl;
        cout << "7 - Criar matriz crescente comecando por linhas." << endl;
        cout << "8 - Criar matriz com os quadrados de cada numero inteiro em ordem crescente." << endl;
        cout << "9 - Verificar se matrizes sao iguais." << endl;
        cout << "10 - Calcular quantos produtos estao abaixo da media do preco de tal produto e mostrar de qual(is) supermercado(s) e'/sao." << endl;
    //  entrada de dado
        cin >> x;
    //  escolher acao
        switch ( x )
        {
            case 0:
                method00( );
                break;
            case 1:
                method01( );
                break;
            case 2:
                method02( );
                break;
            case 3:
                method03( );
                break;
            case 4:
                method04( );
                break;
            case 5:
                method05( );
                break;    
            case 6:
                method06( );
                break;
            case 7:
                method07( );
                break;
            case 8:
                method08( );
                break;
            case 9:
                method09( );
                break;
            case 10:
                method10( );
                break;
            default:
                cout << "Opcao invalida." << endl;
                break;
        } // fim switch( )
    } while ( x != 0);
//  encerrar
    pause ( "Aperte ENTER para terminar." );
    return ( 0 );
} // fim main( )