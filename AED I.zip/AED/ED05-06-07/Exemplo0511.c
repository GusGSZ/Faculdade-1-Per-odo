/*
Exemplo0511 - v0.1 - 27 / 03 / 2019 ___ 31 / 03 / 2019
Author: Gustavo Gomes de Souza
*/

// dependencias
#include "io.h" // para definicoes proprias

/**
Method00 - nao faz nada.
*/
void method00 ( )
{
// nao faz nada
} // fim method00 ( )

/**
   Funcao1 - Mostrar os multiplos de 3 em ordem crescente.
*/
int funcao1 ( int x )
{
   // definir dado local
   return ( x * 3 );
   
   
} // fim funcao1( )

/**
Method01 - Mostrar certa quantidade de valores.
OBS.: Preparacao e disparo de outro metodo.
*/
void method01 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method01 - v0.1" );
   int y = 0;
   
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   for ( int i = 1; i <= x; i++ )
   {
   y = funcao1 ( i );
   printf ( "%d\n", y );
   }
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
   
} // fim method01 ( )

/**
   Funcao2 - Mostrar os multiplos de 3 pares em ordem crescente.
*/
int funcao2 ( int x )
{
   return ( x * 6 );
} // fim funcao2( )

/**
Method02.
*/
void method02 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method02 - v0.1" );
   
   int y = 0;
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   for ( int i = 1; i <= x; i++ )
   {
   y = funcao2 ( i );
   printf ( "%d\n", y );
   }
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method02 ( )

/**
   Funcao3 - Mostrar os multiplos de 3 impares em ordem decrescente.
*/
int funcao3 ( int x )
{
   return ( x * 3 );
} // fim funcao3( )

/**
Method03.
*/
void method03 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method03 - v0.1" );
   
   int y = 0;
   int x = IO_readint ( "Digite uma quantidade: " );
   int b = 1;
   int d = 0;
   int dec[x];

// executar o metodo auxiliar
   for ( int i = 1; b <= x; i = i + 2 )
   {
      y = funcao3 ( i );
      dec [ d ] = y;
      b = b + 1;
      d = d + 1;
   }
   
   for ( int c = x; c > 0; c-- )
   {
      printf ( "%d\n", dec [ c - 1 ] );
   }
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method03 ( )

/**
   Funcao4 - Mostrar os multiplos de 3 na sequencia dos inversos.
*/
int funcao4 ( int x )
{
   return ( x * 3 );
}

/**
Method04.
*/
void method04 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method04 - v0.1" );
   
   int y = 0;
   int x = IO_readint ( "Digite uma quantidade: " );
   double fracao = 0.0;

// executar o metodo auxiliar
   for ( int i = 1; i <= x; i++ )
   {
   y = funcao4 ( i );
   fracao = 1 / (double) y;
   printf ( "1/%d = %lf\n", y, fracao );
   }
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method04 ( )

/**
   Funcao5 - Elevar a potencia x em ordem crescente.
*/
double funcao5 ( int x, int y )
{
   double potencia = pow ( x, y );
   return ( potencia );
}

/**
Method05.
*/
void method05 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method05 - v0.1" );
   
   double y = 0.0;
   int q = IO_readint ( "Digite uma quantidade: " );
   double x = IO_readdouble ( "Digite um valor: " );
   double result = 0.0;
   int a = 0;

// executar a funcao
   for ( int i = 1; i <= q; i ++ )
   {
      y = funcao5 ( x, a );
      result = 1 / y;
      a = a + 1;
      printf ( "Resultado de 1/%2.0lf = %lf\n", y, result );
   }
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method05 ( )

/**
   Funcao6 - Soma dos primeiros valores pares nao multiplos de 3.
*/
double funcao6 ( int x )
{
   int y = 1;
   int z = 0;
   double soma = 0;
   
   while ( y <= x )
   {  
      z = z + 2;
      
      if ( z % 3 != 0 )
      {
         soma = soma + z;
      }
      else
      {
         z = z + 2;
         soma = soma + z;
      }
      y = y + 1;
   }
   return ( soma );
}

/**
Method06.
*/
void method06 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method06 - v0.1" );
   
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   IO_printf ( "%s Soma dos primeiros valores pares nao multiplos de 3 = %2.2lf\n", "", funcao6 ( x ) );
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method06 ( )

/**
   Funcao7 - Soma dos inversos (1/x) dos primeiros valores pares positivos, come�ando em 2 e n�o m�ltiplos de 3.
*/
double funcao7 ( int x )
{
   int y = 1;
   int z = 0;
   double soma = 0;
   
   while ( y <= x )
   {  
      z = z + 2;
      
      if ( z % 3 != 0 )
      {
         soma = soma + (1/(double)z);
      }
      else
      {
         z = z + 2;
         soma = soma + (1/(double)z);
      }
      y = y + 1;
   }
   return ( soma );
}

/**
Method07.
*/
void method07 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method07 - v0.1" );
   
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   IO_printf ( "%s Soma dos inversos dos primeiros valores pares positivos, nao multiplos de 3 = %lf\n", "", funcao7 ( x ) );
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method07 ( )

/**
   Funcao8 - Soma dos primeiros valores naturais comecando em 1.
*/
double funcao8 ( int x )
{
   int y = 1;
   int z = 0;
   double soma = 0.0;
   
   while ( y <= x )
   {  
      z = z + 1;
      
      soma = soma + z;
      
      y = y + 1;
   }
   return ( soma );
}

/**
Method08.
*/ 
void method08 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method08 - v0.1" );
   
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   IO_printf ( "%s Soma dos primeiros valores naturais, comecando em 1 = %2.2lf\n", "", funcao8 ( x ) );
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method08 ( )

/**
   Funcao9 - Soma dos quadrados.
*/
double funcao9 ( int x )
{
   int y = 1;
   double z = 0;
   double soma = 0;
      
   while ( y <= x )
   {
      z = pow ( y, 2 );
      
      soma = soma + z;
      
      y = y + 1;
   }
   return ( soma );
   
} // fim funcao9 ( )

/**
Method09.
*/
void method09 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method09 - v0.1" );
   
   int x = IO_readint ( "Digite uma quantidade: " );

// executar o metodo auxiliar
   IO_printf ( "%s Soma dos quadrados dos primeiros numeros naturais, comecando em 1 = %2.2lf\n", "", funcao9 ( x ) );
  
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method09 ( )

/**
Funcao10 - Soma dos inversos dos primeiros numeros naturais comecando em 1.
*/
double funcao10 ( int x )
{
   int y         = 1;
   double z      = 0.0;
   double fracao = 0.0;
   double soma   = 0.0;
   
   while ( y <= x )
   {
      z = z + 1.0;
      
      fracao = (1.0/z);
      
      soma = soma + fracao;
      
      y = y + 1;
   }
   
   return ( soma );
   
}

/**
Method10.
*/
void method10 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method10 - v0.1" );

// definir dados
   int x = IO_readint ( "Digite a quantidade: " );   
   
// executar o metodo auxiliar ( funcao )
   IO_printf ( "%s Soma dos inversos dos primeiros numeros naturais comecando em 1 = %2.2lf\n", "", funcao10 ( x ) );
   
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method10 ( )

/**
Funcao11 - Fatorial.
*/
double funcao11 ( int x )
{
   int y         = 1;
   double z      = 0.0;
   double fatorial = 0.0;
   
   fatorial =  x * ( x - 1 )  ;
   for ( int i = 2; i < x; i ++ )
   {
      fatorial = fatorial * ( x - i );
   }

   if ( ( x == 0 ) || ( x == 1 ) )
   {
      return ( 1.0 );
   }
   else
   {
      return ( fatorial );
   }
}

/**
Method11.
*/
void method11 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method11 - v0.1" );

// definir dados
   int x = IO_readint ( "Digite o valor: " );   
   
// executar o metodo auxiliar ( funcao )
   IO_printf ( "%s Fatorial = %2.1lf ", "", funcao11 ( x ) );
   
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method11 ( )


/**
Funcao12 - f ( n ) = (1+3/2!) * (1+4/3!) * (1+5/4!) * ... 
*/
double funcao12 ( int x )
{
   int y            = 4;
   double z         = 3.0;
   double resultado = 1.0;
   double fatorial  = 0.0;
   int a = 1;
   int m = 2;
   int o = 3;
   
   fatorial = m * ( m - 1 );
   for ( int i = 1; i < x; i++ )
   {
      if ( x == 1 )
      {
         resultado = resultado * ( 1 + (z/fatorial) );
      }
      else
      {
      if ( i == 1 )
      {
         resultado = resultado * ( 1 + (z/fatorial) );   
         z = 4;
      }
      a = 1;
      for ( int n = o; n < y; n++ ) 
      {
         fatorial =  fatorial * ( n )  ;
      }
      
      resultado = resultado * ( 1 + (z/fatorial) );
      z = z + 1.0;
      y = y + 1;
      o = o + 1;
      }
   }
   
   return ( resultado );
}

/**
Method12.
*/
void method12 ( )
{
// identificar
   IO_id ( "EXEMPLO0511 - Method12 - v0.1" );

// definir dados
   int x = IO_readint ( "Digite a quantidade: " );
   
// executar o metodo auxiliar ( funcao )
   IO_printf ( "%s Resultado = %lf ", "", funcao12 ( x ) );
   
// encerrar
   IO_pause ( "Apertar ENTER para continuar" );
} // fim method11 ( )

/*
Funcao principal.
@return codigo de encerramento
*/
int main ( )
{
// definir dado
   int x = 0; // definir variavel com valor inicial
// repetir at� desejar parar
   do
   {
   
   // identificar
      IO_id ( "EXEMPLO0511 - Programa - v0.1" );
   
   // ler do teclado
      IO_println ( "Opcoes" );
      IO_println ( " 0 - parar." );
      IO_println ( " 1 - mostrar certa quantidade de valores." );
      IO_println ( " 2 - mostrar os multiplos de 3 impares em ordem crescente." );
      IO_println ( " 3 - mostrar os multiplos de 3 impares em ordem decrescente." );
      IO_println ( " 4 - mostrar os multiplos de 3 na sequencia dos inversos." );
      IO_println ( " 5 - elevar a potencia x em ordem crescente." );
      IO_println ( " 6 - soma dos primeiros valores pares nao multiplos de 3." );
      IO_println ( " 7 - soma dos primeiros valores naturais comecando em 1." );
      IO_println ( " 8 - soma dos primeiros valores naturais comecando em 1." );
      IO_println ( " 9 - soma dos quadrados." );
      IO_println ( "10 - soma dos inversos dos primeiros numeros naturais comecando em 1." );
      IO_println ( "11 - fatorial." );
      IO_println ( "12 - f ( n ) = (1+3/2!) * (1+4/3!) * (1+5/4!) * ... " );
      IO_println ( "" );
      x = IO_readint ( "Entrar com uma opcao: " );
   // testar valor
      switch ( x )
      {
         case 0:
            method00 ( );
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         default:
            IO_println ( "ERRO: Valor invalido." );
      } // fim escolher
   }
   while ( x != 0 );

// encerrar
   IO_pause ( "Apertar ENTER para terminar" );
   return ( 0 );
} // fim main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 * Fiz varios testes, mas nao deu tempo de colocar eles aqui.
 * Agora com os testes e com as funcoes retornando valor ( 21/04 ).
 
---------------------------------------------- previsao de testes
a.) 1 e 3
b.) 2 e 4
c.) 3 e 6
d.) 4 e 10
e.) 5, 3 e 2
f.) 6 e 3
g.) 7 e 4
h.) 8 e 5
i.) 9 e 2
j.) 10 e 4
k.) 11 e 3
l.) 12 e 5

---------------------------------------------- resultados
a.) 3
    6
    9
    
b.) 6
    12
    18
    24
    
c.) 33
    27
    21
    15
    9
    3

d.) 1/3 = 0.333333
    1/6 = 0.166667
    1/9 = 0.111111
    1/12 = 0.083333
    1/15 = 0.066667
    1/18 = 0.055556
    1/21 = 0.047619
    1/24 = 0.041667
    1/27 = 0.037037
    1/30 = 0.033333
    
e.) Resultado de 1/ 1 = 1.000000
    Resultado de 1/ 2 = 0.500000
    Resultado de 1/ 4 = 0.250000
    
f.) Soma dos primeiros valores pares nao multiplos de 3 = 14.00  

g.) Soma dos inversos dos primeiros valores pares positivos, nao multiplos de 3 = 0.975000

h.) Soma dos primeiros valores naturais, comecando em 1 = 15.00
    
i.) Soma dos quadrados dos primeiros numeros naturais, comecando em 1 = 5.00

j.) Soma dos inversos dos primeiros numeros naturais comecando em 1 = 2.08

k.) Fatorial = 6.0

l.) Resultado = 5.337854

---------------------------------------------- historico
Versao          Data                           Modificacao
0.1 ( Begin )   27/03                          esboco
    ( Final )   31/03


---------------------------------------------- testes
Versao       Teste
0.1          01. ( OK )                        identificacao de programa

*/