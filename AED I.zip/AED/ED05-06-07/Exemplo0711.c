/**
   Exemplo0711 - v0.1 - 13/04/2019 - 17/04/2019
   Author: Gustavo Gomes de Souza - 656841
*/

// * OBS: NECESSARIO USAR OS METODOS AUXILIARES 14, 15 E 16, PARA QUE OS METODOS 9, 10 E 12, FUNCIONEM CORRETAMENTE!

// dependencias

#include "io.h"

// METODOS

/**
   gravarMultiplosDe3 - gravar multiplos de 3.  
*/

void gravarMultiplosDe3 ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int multiplo = 0;
   
   for ( int i = 1; i <= x; i ++ )
   {
      multiplo = i * 3;
      fprintf ( arquivo, "%d\n", multiplo );
   }
   
   fclose ( arquivo );
}

void method01 ( )
{
   // identificar
   IO_id ( "Exemplo0711 - Method01 - v0.1" );
   
   // receber valor
   int x = IO_readint ( "Digite a quantidade: " );
   
   // executar metodo para gravar em arquivo
   gravarMultiplosDe3 ( "RESULTADO01.txt", x );
   
   // encerrar
   IO_pause ( "Aperte ENTER para terminar. " );
}

void gravarMult3Pares ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int multiplo = 0;
   
   for ( int i = x; i > 0; i -- )
   {
      multiplo = i * 6;
      
      fprintf ( arquivo, "%d\n", multiplo );
   } 
   
   // fechar arquivo
   fclose ( arquivo );
}

void method02 ( )
{
   int x = IO_readint ( "Digite a quantidade: " );
   
   gravarMult3Pares ( "RESULTADO02.txt", x );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

void gravarValoresSequencia ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int sequencia = 3;
   
   for ( int i = 1; i <= x; i ++ )
   {
      if ( i == 1 )
      {
         fprintf ( arquivo, "%d\n", 1 );
      }
      else
      {
         if ( i == 2 )
         {
            fprintf ( arquivo, "%d\n", sequencia );
         }
         else
         {
            sequencia = sequencia + 6;
            fprintf ( arquivo, "%d\n", sequencia );
         }
      }
   }
   
   fclose ( arquivo );
}

void method03 ( )
{
   // receber quantidade
   int x = IO_readint ( "Digite a quantidade: " );
   
   // executar metodo para salvar valores em arquivo
   gravarValoresSequencia ( "RESULTADO03.txt", x );
   
   // encerrar
   IO_pause ( "Aperte ENTER para terminar. ");
}

void gravarValores ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int sequencia = 0;
   double result = 0.0;
   
   for ( int i = 0; i < x; i ++ )
   {
      if ( i == 0 )
      {
         fprintf ( arquivo, "%d = %2.1lf\n", 1, 1.0 );
      }
      else
      {
         sequencia = pow ( 3, i );
         result = 1.0 / sequencia;
         fprintf ( arquivo, "1/%d = %lf\n", sequencia, result );
      }
   }
   
   // fechar arquivo
   fclose ( arquivo );
}

void gravarValoresa ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int sequencia = 0;
   double result = 0.0;
   
   for ( int i = -1; i <= x; i ++ )
   {
      if ( i == x )
      {
         fprintf ( arquivo, "%2.1lf\n", 0.0 );
      }
      else
      {
         if ( i == -1 )
         {
            fprintf ( arquivo, "%d\n", 0 );
         }
         else
         {
            if ( i == 0 )
            {
               fprintf ( arquivo, "%2.1lf\n", 1.0 );
            }
            else
            {
               sequencia = pow ( 3, i );
               result = 1.0 / sequencia;
               fprintf ( arquivo, "%lf\n", result );
            }
         }
      }
   }
   
   // fechar arquivo
   fclose ( arquivo );
}

void method04 ( )
{
   // receber quantidade
   int x = IO_readint ( "Digite a quantidade: " );
   
   // executar metodo para salvar valores em arquivo
   gravarValores ( "RESULTADO04.txt", x );
   
   // encerrar
   IO_pause ( "Aperte ENTER para terminar. ");
}

void method04a ( )
{
   // receber quantidade
   int x = IO_readint ( "Digite a quantidade: " );
   
   // executar metodo para salvar valores em arquivo
   gravarValoresa ( "RESULTADO04a.txt", x );
   
   // encerrar
   IO_pause ( "Aperte ENTER para terminar. ");
}

void gravarValores5 ( chars fileName, int x, int y )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   double pot = 0.0;
   int k = 1;
   
   for ( int i = -1; i <= x; i ++ )
   {
      if ( x == 1 )
      {
         pot = pow ( y, 0 );
         fprintf ( arquivo, "%lf\n", 1.0 );
      }
      else
      {
         if( i == 0 )
         {
            pot = pow ( y, 0 );
            fprintf ( arquivo, "%lf\n", 1.0 );
         }
         else
         {
            if ( i == x )
            {
               fprintf ( arquivo, "%2.1lf\n", 0.0 );
            }
            else
            {
               if ( i == -1 )
               {
                  fprintf ( arquivo, "%2.1lf\n", 0.0 );
               }
               else
               {
                  pot = pow ( y, k );
                  k = k + 2;
                  fprintf ( arquivo, "%2.12lf\n", ( 1.0/pot ) );
               }
            }
         }
      }
   }
   
   fclose ( arquivo );
}

void method05 ( )
{
   int x = IO_readint ( "Digite a quantidade: " );
   int y = IO_readint ( "Digite o valor a ser elevado: " );
   
   gravarValores5 ( "RESULTADO05.txt", x, y );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

double gravarSoma ( chars fileName, int x )
{
   FILE* entrada = fopen ( fileName, "rt" );
   int w = 0;
   int y = 1;
   double z = 0.0;
   double soma = 0.0;
   
   // tentar ler a quantidade de dados
   fscanf ( entrada, "%d", &w );
   while ( !feof( entrada ) && y <= x )
   {
      fscanf ( entrada, "%lf", &z );
      soma = soma + z;
      y = y + 1;
   }
   
   return ( soma );
   
   fclose ( entrada );
}

void gravarMethod06 ( chars fileName, int x )
{  
   FILE* arquivo = fopen ( fileName, "wt" );

   fprintf ( arquivo, "Quantidade: %d\n", x );
   fprintf ( arquivo, "Soma = %2.12lf", gravarSoma ( "RESULTADO05.txt", x ) );
   
   fclose ( arquivo );
}

void method06 ( )
{
   int x = IO_readint ( "Digite a quantidade: " );
   
   gravarMethod06 ( "RESULTADO06.txt", x );
   
   IO_pause ( "Aperte ENTER para continuar. " );
}

double somaInversosPot3 ( chars fileIn, int x )
{
   FILE* entrada = fopen ( fileIn, "rt" );
   int w = 0;
   int y = 1;
   double z = 0.0;
   double soma = 0.0;
   
   fscanf ( entrada, "%d", &w );
   
   while ( !feof( entrada ) && y <= x )
   {
      fscanf ( entrada, "%lf", &z );
      soma = soma + z;
      y = y + 1;
   }
   
   return ( soma );
   
   fclose ( entrada );
}

void gravarMethod07 ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "Quantidade: %d\n", x );
   fprintf ( arquivo, "Soma = %lf", somaInversosPot3 ( "RESULTADO04a.txt", x ) );
   
   fclose ( arquivo );
}

void method07 ( )
{
   int x = IO_readint ( "Digite a quantidade: " );
   gravarMethod07 ( "RESULTADO07.txt", x );

   IO_pause ( "Aperte ENTER para continuar. " );
}

/**
 fibonacci - Gerador de numero de Fibonacci.
 @return numero de Fibonacci
 @param x - numero de ordem cujo valor sera' calculado
*/
int fibonacci ( int x )
{
// definir dado
   int resposta = 0;
// testar se contador valido
   if ( x == 1 || x == 2 )
   {
   // primeiros dois valores iguais a 1
      resposta = 1; // bases
   }
   else
   {
      if ( x > 1 )
      {
      // fazer de novo com valor absoluto
         resposta = fibonacci ( x-1 ) + fibonacci ( x-2 );
      } // fim se
   } // fim se
// retornar resposta
   return ( resposta );
} // fim fibonacci ( )

void gravarFibonacci ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "Quantidade: %d\n", x );
   
   int k = 1;
   
   for ( int i = 1; i <= x; i ++ )
   {
      if ( fibonacci ( k ) % 2 != 0 )
      {
         fprintf ( arquivo, "%d: %d\n", i, fibonacci ( k ) );
      }
      else
      {
         k++;
         fprintf ( arquivo, "%d: %d\n", i, fibonacci ( k ) );
      }
      k++;
   }

   fclose ( arquivo );
}

void method08 ( )
{
   int x = IO_readint ( "Digite uma quantidade: " );
   
   gravarFibonacci ( "RESULTADO08.txt", x );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

// metodo para gravar palavras
void gravarPalavras ( chars fileName, chars cc )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "%s", cc );
   
   fclose ( arquivo );
}

void metodoPalavras ( ) // metodo para gravar palavras em arquivo que sera' lido no method09
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   palavra = IO_readstring ( "Digite uma cadeia de caracteres: " );
   
   gravarPalavras ( "PALAVRAS.txt", palavra );
}

// metodo para gravar palavras
void gravarPalavras2 ( chars fileName, chars cc )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   
   fprintf ( arquivo, "%s", cc );
   
   fclose ( arquivo );
}

void metodoPalavras2 ( ) // metodo para gravar palavras em arquivo que sera' lido no method10
{
   chars palavra = IO_new_chars ( 80 );
   strcpy ( palavra, "" );
   palavra = IO_readstring ( "Digite uma cadeia de caracteres: " );
   
   gravarPalavras2 ( "PALAVRAS2.txt", palavra );
}


int contMinusculas ( chars fileName )
{
   FILE* arquivo = fopen ( fileName, "rt" );
   int w = 0;
   chars z = IO_new_chars ( 80 );
   strcpy ( z, "" );
   int cont = 0;
   
   strcpy ( z, IO_fread ( arquivo ) );
   
   fscanf ( arquivo, "%s", &z );
   
   for ( int i = 0; i < strlen ( z ); i ++ )
   {
      if ( z [ i ] >= 'a' && z [ i ] <= 'z' )
      {
         cont++;
      }
   }
   
   return ( cont );
   
   fclose ( arquivo );
  
}

void method09a ( chars fileOut, chars fileIn )
{
   FILE* entrada = fopen ( fileIn, "rt" );
   FILE* saida = fopen ( fileOut, "wt" );
   chars z = IO_new_chars ( 80 );
   strcpy ( z, "" );
   
   strcpy ( z, IO_fread ( entrada ) );
   
   fscanf ( entrada, "%s", &z );
      
   fprintf ( saida, "A cadeia de caracteres '%s' tem %d letras min�sculas.", z, contMinusculas ( "PALAVRAS.txt" ) );
   
   fclose ( entrada );
   fclose ( saida );
}

void method09 ( )
{
   method09a ( "RESULTADO09.txt", "PALAVRAS.txt" );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

int contDigitos ( chars fileName )
{
   FILE* arquivo = fopen ( fileName, "rt" );
   int w = 0;
   chars z = IO_new_chars ( 80 );
   strcpy ( z, "" );
   int cont = 0;
   
   strcpy ( z, IO_fread ( arquivo ) );
   
   fscanf ( arquivo, "%s", &z );
   
   for ( int i = 0; i < strlen ( z ); i ++ )
   {
      if ( z [ i ] >= '0' && z [ i ] <= '9' )
      {
         cont++;
      }
   }
   
   return ( cont );
   
   fclose ( arquivo );
  
}

void method10a ( chars fileOut, chars fileIn )
{
   FILE* entrada = fopen ( fileIn, "rt" );
   FILE* saida = fopen ( fileOut, "wt" );
   chars z = IO_new_chars ( 80 );
   strcpy ( z, "" );
   
   strcpy ( z, IO_fread ( entrada ) );
   
   fscanf ( entrada, "%s", &z );
      
   fprintf ( saida, "A cadeia de caracteres '%s' tem %d digitos.", z, contDigitos ( "PALAVRAS2.txt" ) );
   
   fclose ( entrada );
   fclose ( saida );
}

void method10 ( )
{
   method10a ( "RESULTADO10.txt", "PALAVRAS2.txt" );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void gravarDivisores ( chars fileName, int x )
{
   FILE* arquivo = fopen ( fileName, "wt" );

   for ( int i = x; i > 0; i -- )
   {
      if ( x % i == 0 )
      {
         fprintf ( arquivo, "%d\n", i );
      } 
   }
   
   fclose ( arquivo );
}

void method11 ( )
{
   int x = IO_readint ( "Digite um valor: " );
   
   gravarDivisores ( "RESULTADO11.txt", x );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

void metodoPalavras3 ( chars fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   chars linha = IO_new_chars ( 80 );
   
   fprintf ( arquivo, "%c\n", ' ' );
   IO_println ( "Gravar palavras em arquivo. Digite PARAR para terminar. " );
   do
   {
      strcpy ( linha, IO_readln ( "" ) );
      fprintf ( arquivo, "%s\n", linha );
   } while ( strcmp ( "PARAR", linha ) != 0 );
   
   fclose ( arquivo );
}

void palavraS ( )
{
   metodoPalavras3 ( "PALAVRAS3.txt" );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}


int contAs ( chars fileIn )
{
   FILE* arquivo = fopen ( fileIn, "rt" );
   int contA = 0;
   chars z = IO_new_chars ( 80 );
   chars linha = IO_new_chars ( 80 );
   
   strcpy ( linha, IO_fread ( arquivo ) );
   while ( !feof( arquivo ) && strcmp ( "PARAR", linha )!=0 )
   {  
      if ( linha [ 0 ] == 'A' || linha [ 0 ] == 'a' )
      contA = contA + 1;
      // tentar ler o proximo
            strcpy ( linha, IO_fread ( arquivo ) );
   }
   
   return ( contA );
   
   fclose ( arquivo );
}

void method12 ( )
{
   printf ( "Ha' %d palavras que comecam com 'A' ou 'a' dentre as palavras no arquivo. ", contAs ( "PALAVRAS3.txt" ) );
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

int main ( )
{
   int x = 0;
   
   do
   {
      // identificar
      IO_id ( "EXEMPLO0711 - Programa - v0.1" );
      IO_println ( "Author: Gustavo Gomes de Souza - 656841 " );
      
      // opcoes
      IO_println ( "1  - Gravar em arquivo multiplos de 3 impares, crescente, comecando em 3.              " );
      IO_println ( "2  - Gravar em arquivo os valores pares multiplos de 3, decrescendo e terminando em 6. " );
      IO_println ( "3  - Gravar em arquivo os multiplos de 3.                                              " );
      IO_println ( "4  - Gravar em arquivo o inverso das potencias de 3.                                   " );
      IO_println ( "5  - Gravar em arquivo o inverso das potencias impares de x.                           " );
      IO_println ( "6  - Gravar em arquivo a soma dentre os primeiros valores gravados no exercicio 5.     " );
      IO_println ( "7  - Soma dos inversos das potencias de 3.                                             " );
      IO_println ( "8  - Gravar primeiros valores impares da sequencia Fibonacci em arquivo.               " );
      IO_println ( "9  - Contar minusculas de uma cadeia de caracteres.                                    " );
      IO_println ( "10 - Contar digitos de uma cadeia de caracteres.                                       " );
      IO_println ( "11 - Gravar divisores de um numero em arquivo.                                         " );
      IO_println ( "12 - Contar quantas palavras comecam com 'A' ou 'a'.                                   " );
      IO_println ( "13 - Gravar palavras. ( Alternativo do metodo 4. )                                     " );
      IO_println ( "14 - Gravar palavras. ( Auxiliar do metodo 9.  )                                       " );
      IO_println ( "15 - Gravar palavras. ( Auxiliar do metodo 10. )                                       " );
      IO_println ( "16 - Gravar palavras. ( Auxiliar do metodo 12. )                                       " );
      x = IO_readint ("\nEscolha uma opcao: ");
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04a ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         case 13:
            method04 ( );
            break;   
         case 14:
            metodoPalavras ( );
            break;
         case 15:
            metodoPalavras2 ( );
            break;
         case 16:
            palavraS ( );
            break;
         default:
            printf ( "INVALID VALUE!");
            break;
      }
   }
   while ( x != 0 );
   
   IO_pause ( "Aperte ENTER para terminar. ");
   return ( 0 );
}

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios

 * OBS: NECESSARIO USAR OS METODOS AUXILIARES 14, 15 E 16, PARA QUE OS METODO 9, 10 E 12, FUNCIONEM CORRETAMENTE!
 
 * Alguns arquivos comecam e terminam com '0' ou '0.0' pois nao pegava o primeiro valor e repetia o ultimo nas somas, resultando em um valor errado.
 
---------------------------------------------- previsao de testes
a.) 1 e 5
b.) 2 e 6
c.) 3 e 7
d.) 4 e 8
e.) 5, 9 e 3
f.) 6 e 10
g.) 7 e 11
h.) 8 e 3
i.) 9
j.) 10
k.) 11 e 18
l.) 12
m.) \\-\\
n.) abc
o.) gustaVogOmes
p.) ABELHA
    Ana
    amanda
    artes
    benjamin
    Bruna

---------------------------------------------- resultados
a.) 3
    6
    9
    12
    15
    
b.) 36
    30
    24
    18
    12
    6

c.) 1
    3
    9
    15
    21
    27
    33

d.) 1.0
    0.333333
    0.111111
    0.037037
    0.012346
    0.004115
    0.001372
    0.000457

e.) 1.000000
    0.333333333333
    0.037037037037
    0.004115226337
    0.000457247371
    0.000050805263
    0.000005645029
    0.000000627225
    0.000000069692

f.) Quantidade: 10
    Soma = 1.374999991287

g.) Quantidade: 11
    Soma = 1.499771

h.) Quantidade: 3
    1: 1
    2: 1
    3: 3

i.) A cadeia de caracteres 'abc' tem 3 letras min�sculas.

j.) A cadeia de caracteres 'gustaVogOmes' tem 0 digitos.

k.) 18
    9
    6
    3
    2
    1

l.) Ha' 4 palavras que comecam com 'A' ou 'a' dentre as palavras.

---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          13/04                            esboco
              |
              |
              |
              17/04
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
              11. ( OK )
              12. ( OK )
 
*/