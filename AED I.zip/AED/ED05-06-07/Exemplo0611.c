/**
   Exemplo0611 - v0.1 - 03/04/2019 - 07/04/2019
   Author: Gustavo Gomes de Souza - 656841
*/

// dependencias

#include "io.h"

// METODOS

void method01a ( int x, int y )
{

   if ( x > 0 )
   {
      printf ( "Valor = %d\n", 2*y + 1 );
      method01a ( x - 1, y + 1 );
   }
   
}

void method01 ( )
{
   int x = IO_readint ( "\nDigite uma quantidade: " );
   
   method01a ( x, 1 );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

void method02a ( int x, int y )
{
   if ( x > 0 )
   {
      method02a ( x - 1, y + 1 );
      printf ( "Valor = %d\n", y * 3 );
   }
}

void method02 ( )
{
   int x = IO_readint ( "\nDigite uma quantidade: " );
   
   method02a ( x, 1 );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

void method03a ( int x, int y )
{
   if ( y == 1 )
   {
      printf ( "Valor = %d\n", y/y );
   }
   
   if ( x > 1 )
   {
      printf ( "Valor = %d\n", y * 3 );
      method03a ( x - 1, y + 1);
   }
}

void method03 ( )
{
   int x = IO_readint( "\nDigite uma quantidade: " );
   
   method03a ( x, 1 );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

void method04a ( int x, double y )
{
   double pot = 0;
   if ( x > 0 )
   {
      method04a ( x - 1, y + 1.0 );
      pot = pow ( 3, y );
      printf ( "1/%2.0lf = %lf\n", pot, (1.0/pot) );
   }
}

void method04 ( )
{
   int x = IO_readint ( "\nDigite uma quantidade: " );
   
   method04a ( x, 1 );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

void method05a ( chars palavra, int x )
{  
   int tam = strlen ( palavra );
   
   if ( x < tam )
   {
      printf ( "Simbolo: %c\n", palavra [ x ] );
      method05a ( palavra, x + 1 );
   }
}

void method05 ( )
{
   chars palavra = IO_new_chars( 80 );
   strcpy( palavra, "" );
   palavra = IO_readstring ( "\nDigite uma palavra: " );
   
   method05a ( palavra, 0 );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

double method06a ( int x )
{
   double soma = 0.0;
   
   if ( x > 0 )
   {
      soma = (5 + (2 * (x - 1))) + method06a ( x - 1 ) ;
   }
   else
   {
      soma = 0;
   }
   
   return ( soma );
}

void method06 ( )
{
   int x = IO_readint ( "\nDigite uma quantidade: " );
   double soma = 0.0;
   
   soma = method06a ( x );
   printf ( "\nSoma dos primeiros impares comecando em 5 = %2.2lf", soma );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

double method07a ( double x )
{
   double soma = 0.0;
   
   if ( x > 0.0 )
   {
      soma = 1.0/( 5.0 + ( 2.0 * (x - 1.0) ) ) + method07a( x - 1.0 );
   }
   else
   {
      soma = 0.0;
   }
   
   return ( soma );
}

void method07 ( )
{
   double x = IO_readdouble ( "\nDigite uma quantidade: " );
   double soma = 0.0;
   
   soma = method07a ( x );
   printf ( "\nSoma dos inversos = %lf", soma );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

int fibonacci ( int x )
{
   int fibo = 0;
   
   if ( ( x == 1 ) || ( x == 2 ) )
   {
      fibo = 1;
   }
   
   if ( x > 1 )
   {
      fibo = fibonacci ( x - 1 ) + fibonacci ( x - 2 );
   }
   
   return ( fibo );
}

void method08 ( )
{
   int x = IO_readint ( "\nDigite a quantidade: " );
   
   for ( int i = 1; i <= x; i ++ )
   {
      if ( fibonacci ( i ) % 2 == 0 )
      {
      printf ( "%d\n", fibonacci ( i ) );
      }
   }
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

void method08b ( )
{
   int x = IO_readint ( "\nDigite a quantidade: " );
   int z = 1;
   
   for ( int i = 1; i <= x; i ++ )
   {
         if ( fibonacci ( z ) % 2 == 0 )
         {
            printf ( "%d\n", fibonacci ( z ) );
         }
         else
         {
            i--;
         }
         z++;
   }
   
   IO_pause ( "Aperte ENTER para terminar. " );
}

int method09a ( chars palavra, int x )
{
   int tam = strlen ( palavra );
   int cont = 0;
   
   if ( x < tam )
   {
      if ( palavra [ x ] % 2 != 0 )
      {
         cont = 1 + method09a ( palavra, x + 1 );
      }
      else
      {
         cont = cont + method09a ( palavra, x + 1 );
      }
   }
   return ( cont );
}

void method09 ( )
{
   chars palavra = IO_readstring ( "\nDigite uma palavra: " );
   int impares = 0;
   
   impares = method09a ( palavra, 0 );
   printf ( "\nExistem %d digitos impares.", impares );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

int method10a ( chars palavra, int x )
{
   int tam = strlen ( palavra );
   int cont = 0;
   
   if ( x < tam )
   {
      if ( palavra [ x ] >= 'A' && palavra [ x ] <= 'Z' )
      {
         cont = 1 + method10a ( palavra, x + 1 );
      }
      else
      {
         cont = 0 + method10a ( palavra, x + 1 );
      }
   }
   return ( cont );
}

void method10 ( )
{
   chars palavra = IO_readstring ( "\nDigite uma palavra: " );
   int maiusculas = 0;
   
   maiusculas = method10a ( palavra, 0 );
   printf ( "\nExistem %d letras maiusculas.", maiusculas );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

int method11a ( int y, int x, int n )
{
   int funcao = 0;
   int pot = 0;
   
   if ( y > 0 )
   {
      if ( y < 0 )
      {
         printf ( "Apenas valores positivos sao aceitos. " );
      }
      else
      {
         pot = pow ( x, n );
         funcao = funcao + pot;
         funcao = funcao + method11a ( y - 1, x, n + 1 );
      }
   }
   return ( funcao );
}

void method11 ( )
{
   int y = IO_readint ( "\nDigite a quantidade: " );
   int x = IO_readint ( "\nDigite um valor: " );
   
   int funcao = 0;
   
   funcao = method11a ( y, x, 0 );
   printf ( "\nf( x, n ) = %d.", funcao );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

double fatorial ( int x )
{
   int y = 1;
   double z = 0.0;
   double fatorial = 0.0;
   
   fatorial = x * ( x - 1 );
   for ( int i = 2; i < x; i++ )
   {
      fatorial = fatorial * ( x - i );
   }
   
   if ( ( x == 0 ) || ( x == 1 ) )
   {
      fatorial = 1.0;
      return ( fatorial );
   }
   else
   {
      return ( fatorial );
   }
}


double method12a ( int x )
{
   double e = 0.0;
   
   if ( x > 0 )
   {
      e = e + ( x/fatorial ( x -1 ) );
      e = e + method12a ( x - 1 );
   }
   
   return ( e );
}

void method12 ( )
{
   int x = IO_readint ( "\nDigite a quantidade: " );
   
   double e = 0.0;
   
   e = method12a ( x );
   printf ( "\ne = %lf.", e );
   
   IO_pause ( "\nAperte ENTER para terminar. " );
}

int main ( )
{
   int x = 0;
   
   do
   {
      // identificar
      IO_id ( "EXEMPLO0611 - Programa - v0.1" );
      IO_println ( "Author: Gustavo Gomes de Souza - 656841 " );
      
      // opcoes
      IO_println ( "1 - Impares crescentes comecando em 3. " );
      IO_println ( "2 - multiplos de 3 decrescentes encerrando em 3. " );
      IO_println ( "3 - multiplos de 3. ( exceto o 1 ) " );
      IO_println ( "4 - multiplos de 3 inversos decrescentes. ( exceto o 1 ) " );
      IO_println ( "5 - mostrar simbolos de uma cadeia de caracteres. " );
      IO_println ( "6 - soma dos primeiros impares (+) comecando em 5. " );
      IO_println ( "7 - soma dos inversos dos primeiros impares (+) comecando em 5. " );
      IO_println ( "8 - mostrar termos pares do Fibonacci de x (numero inserido). " );
      IO_println ( "9 - contar digitos impares em uma cadeia de caracteres. " );
      IO_println ( "10 - contar maiusculas em uma cadeia de caracteres. " );
      IO_println ( "11 - f ( x, n ) = 1 + x^1 + x^2 + x^3 + x^4 + ... + x^n ");
      IO_println ( "12 - e = 1 + 2/1! + 3/2! + 4/3! + 5/4! + ... + n/(n-1)! ");
      IO_println ( "13 - mostrar tantos termos pares da sequencia Fibonacci quanto a quantidade indicar." ); 
      x = IO_readint ("\nEscolha uma opcao: ");
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            method11 ( );
            break;
         case 12:
            method12 ( );
            break;
         case 13:
            method08b ( );
            break;
         default:
            printf ( "INVALID VALUE!");
            break;
      }
   }
   while ( x != 0 );
   
   IO_pause ( "Aperte ENTER para terminar. ");
   return ( 0 );
}

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 * Nao sabia o que realmente era pra fazer na 8, entao fiz de duas formas
 * Testes adicionados. ( 21/04 ) 
---------------------------------------------- previsao de testes
a.) 1 e 3
b.) 2 e 4
c.) 3 e 5
d.) 4 e 3
e.) 5 e palavra
f.) 6 e 5
g.) 7 e 3
h.) 8 e 10
i.) 9 e gustavo
j.) 10 e viCtor
k.) 11, 4 e 3
l.) 12 e 5
m.) 13 e 3

---------------------------------------------- resultados
a.) Valor = 3
    Valor = 5
    Valor = 7
    
b.) Valor = 12
    Valor = 9
    Valor = 6
    Valor = 3

c.) Valor = 1
    Valor = 3
    Valor = 6
    Valor = 9
    Valor = 12

d.) 1/27 = 0.037037
    1/ 9 = 0.111111
    1/ 3 = 0.333333

e.) Simbolo: p
    Simbolo: a
    Simbolo: l
    Simbolo: a
    Simbolo: v
    Simbolo: r
    Simbolo: a

f.) Soma dos primeiros impares comecando em 5 = 45.00

g.) Soma dos inversos = 0.453968

h.) 2
    8
    34
    
i.) Existem 5 digitos impares.

j.) Existem 1 letras maiusculas.

k.) f ( x, n ) = 40.

l.) e = 5.375000.

m.) 2
    8
    34

---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          03/04                            esboco
              |
              |
              |
              07/04
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
              11. ( OK )
              12. ( OK )
              13. ( OK )
 
*/