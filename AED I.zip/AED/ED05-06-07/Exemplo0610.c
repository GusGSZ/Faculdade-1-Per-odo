/**
   Exemplo0610 - v0.1 - 06/04/2019
   Author: Gustavo Gomes de Souza - 656841
*/

// dependencias

#include "io.h"

/**
 Method01a - Mostrar certa quantidade de valores recursivamente.
 @param x - quantidade de valores a serem mostrados
*/
void method01a ( int x )
{
// repetir enquanto valor maior que zero
 if ( x > 0 )
 {
 // mostrar valor
 IO_printf ( "%s%d\n", "Valor = ", x );
 // passar ao proximo
 method01a ( x - 1 ); // motor da recursividade
 } // fim se
} // fim method01a( )

/**
 Method01 - Mostrar certa quantidade de valores.
*/
void method01 ( )
{
// definir dado
 int quantidade = 0;
 int valor = 0;
 int controle = 0;
// identificar
 IO_id ( "EXEMPLO0610 - Method01 - v0.1" );
// executar o metodo auxiliar
 method01a ( 5 ); // motor da recursividade
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method01 ( )


/**
 Method02a - Mostrar certa quantidade de valores recursivamente.
 @param x - quantidade de valores a serem mostrados
*/
void method02a ( int x )
{
// repetir enquanto valor maior que zero
 if ( x > 0 )
 {
 // passar ao proximo
 method02a ( x - 1 ); // motor da recursividade
 // mostrar valor
 IO_printf ( "%s%d\n", "Valor = ", x );
 } // fim se
} // fim method02a( )

/**
 Method02.
*/
void method02 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method02 - v0.1" );
// executar o metodo auxiliar
 method02a ( 5 ); // motor da recursividade
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method02 ( )

/**
 Method03a - Mostrar certa quantidade de valores recursivamente.
 @param x - quantidade de valores a serem mostrados
*/
void method03a ( int x )
{
// repetir enquanto valor maior que zero
 if ( x > 1 )
 {
 // passar ao proximo
 method03a ( x - 1 ); // motor da recursividade
 // mostrar valor
 IO_printf ( "%s%d\n", "Valor = ", x );
 }
 else
 { // base da recursividade
 // mostrar o ultimo
 IO_printf ( "%s\n", "Valor = 1" );
 } // fim se
} // fim method03a( )

/**
 Method03.
*/
void method03 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method03 - v0.1" );
// executar o metodo auxiliar
 method03a ( 5 ); // motor da recursividade
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method03 ( )

/**
 Method04a - Mostrar certa quantidade de valores recursivamente.
 @param x - quantidade de valores a serem mostrados
*/
void method04a ( int x )
{
// repetir enquanto valor maior que zero
 if ( x > 1 )
 {
 // passar ao proximo
 method04a ( x - 1 ); // motor da recursividade
 // mostrar valor
 IO_printf ( "%s%d\n", "Valor = ", 2*(x-1) );
 }
 else
 { // base da recursividade
 // mostrar o ultimo
 IO_printf ( "%s\n", "Valor = 1" );
 } // fim se
} // fim method04a( )

/**
 Method04.
*/
void method04 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method04 - v0.1" );
// executar o metodo auxiliar
 method04a ( 5 ); // motor da recursividade
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method04 ( )

/**
 Method05a - Mostrar certa quantidade de valores recursivamente.
 @param x - quantidade de valores a serem mostrados
*/
void method05a ( int x )
{
// repetir enquanto valor maior que zero
 if ( x > 1 )
 {
 // passar ao proximo
 method05a ( x - 1 ); // motor da recursividade
 // mostrar valor
 IO_printf ( "%d: %d/%d\n", x, (2*(x-1)), (2*(x-1)+1) );
 }
 else
 { // base da recursividade
 // mostrar o ultimo
 IO_printf ( "%d: %d\n", x, 1 );
 } // fim se
} // fim method05a( )

/**
 Method05.
*/
void method05 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method05 - v0.1" );
// executar o metodo auxiliar
 method05a ( 5 ); // motor da recursividade
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method05 ( )

/**
 somarFracoes - Somar certa quantidade de fracoes recursivamente.
 @return soma de valores
 @param x - quantidade de valores a serem mostrados
*/
double somarFracoes ( int x )
{
// definir dado local
 double soma = 0.0;
// repetir enquanto valor maior que zero
 if ( x > 1 )
 {
 // separar um valor e passar ao proximo (motor da recursividade)
 soma = (2.0*(x-1))/(2.0*(x-1)+1) + somarFracoes ( x - 1 );
 // mostrar valor
 IO_printf ( "%d: %lf/%lf\n", x, (2.0*(x-1)), (2.0*(x-1)+1) );
 }
 else
 {
 // base da recursividade
 soma = 1.0;
 // mostrar o ultimo
 IO_printf ( "%d; %lf\n", x, 1.0 );
 } // fim se
// retornar resultado
 return ( soma );
} // fim somarFracoes ( )

/**
 Method06.
*/
void method06 ( )
{
// definir dado
 double soma = 0.0;
// identificar
 IO_id ( "EXEMPLO0610 - Method06 - v0.1" );
// chamar a funcao e receber o resultado
 soma = somarFracoes ( 5 );
// mostrar resultado
 IO_printf ( "soma = %lf\n", soma );
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method06 ( )

/**
 somarFracoes2 - Somar certa quantidade de fracoes recursivamente.
 @return soma de valores
 @param x - quantidade de valores a serem mostrados
*/
double somarFracoes2 ( int x )
{
// definir dado local
 double soma = 0.0;
// repetir enquanto valor maior que zero
 if ( x > 1 )
 {
 // separar um valor e passar ao proximo (motor da recursividade)
 soma = (2.0*(x-1)+1)/(2.0*(x-1)) + somarFracoes2 ( x - 1 );
 // mostrar valor
 IO_printf ( "%d: %lf/%lf\n", x, (2.0*(x-1)+1), (2.0*(x-1)) );
 }
 else
 {
 // base da recursividade
 soma = 1.0;
 // mostrar o ultimo
 IO_printf ( "%d: %lf\n", x, 1.0 );
 } // fim se
// retornar resultado
 return ( soma );
} // fim somarFracoes2 ( )

/**
 Method07.
*/
void method07 ( )
{
// definir dado
 double soma = 0.0;
// identificar
 IO_id ( "EXEMPLO0610 - Method07 - v0.1" );
// chamar a funcao e receber o resultado
 soma = somarFracoes2 ( 5 );
// mostrar resultado
 IO_printf ( "soma = %lf\n", soma );
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method07 ( )

/**
 contarDigitos - Contar digitos recursivamente.
 @return quantidade de digitos
 @param x - numero cuja quantidade de digitos sera' calculada
*/
int contarDigitos ( int x )
{
// definir dado
 int resposta = 1; // base
// testar se contador valido
 if ( x >= 10 )
 {
 // tentar fazer de novo com valor menor
 resposta = 1 + contarDigitos ( x/10 ); // motor 1
 }
 else
 {
 if ( x < 0 )
 {
 // fazer de novo com valor absoluto
 resposta = contarDigitos ( -x ); // motor 2
 } // fim se
 } // fim se
// retornar resposta
 return ( resposta );
} // fim contarDigitos ( )

/**
 Method08.
*/
void method08 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method08 - v0.1" );
// mostrar resultado
 IO_printf ( "digitos (%3d) = %d\n", 123, contarDigitos (123) );
 IO_printf ( "digitos (%3d) = %d\n", 1 , contarDigitos ( 1 ) );
 IO_printf ( "digitos (%3d) = %d\n", -10, contarDigitos ( -10 ) );
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method08 ( )

/**
 fibonacci - Gerador de numero de Fibonacci.
 @return numero de Fibonacci
 @param x - numero de ordem cujo valor sera' calculado
*/
int fibonacci ( int x )
{
// definir dado
 int resposta = 0;
// testar se contador valido
 if ( x == 1 || x == 2 )
 {
 // primeiros dois valores iguais a 1
 resposta = 1; // bases
 }
 else
 {
 if ( x > 1 )
 {
 // fazer de novo com valor absoluto
 resposta = fibonacci ( x-1 ) + fibonacci ( x-2 );
 } // fim se
 } // fim se
// retornar resposta
 return ( resposta );
} // fim fibonacci ( )

/**
 Method09.
*/
void method09 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method09 - v0.1" );
// calcular numero de Fibonacci
 IO_printf ( "fibonacci (%d) = %d\n", 1, fibonacci ( 1 ) );
 IO_printf ( "fibonacci (%d) = %d\n", 2, fibonacci ( 2 ) );
 IO_printf ( "fibonacci (%d) = %d\n", 3, fibonacci ( 3 ) );
 IO_printf ( "fibonacci (%d) = %d\n", 4, fibonacci ( 4 ) );
 IO_printf ( "fibonacci (%d) = %d\n", 5, fibonacci ( 5 ) );
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method09 ( )

/**
 contarMinusculas - Contador de letras minusculas.
 @return quantidade de letras minusculas
 @param x - cadeia de caracteres a ser avaliada
*/
int contarMinusculas ( chars cadeia, int x )
{
// definir dado
 int resposta = 0;
// testar se contador valido
 if ( 0 <= x && x < strlen ( cadeia ) )
 {
 // testar se letra minuscula
 if ( cadeia [x] >= 'a' &&
 cadeia [x] <= 'z' )
 {
 // fazer de novo com valor absoluto
 resposta = 1;
 } // fim se
 resposta = resposta + contarMinusculas ( cadeia, x+1 );
 } // fim se
// retornar resposta
 return ( resposta );
} // fim contarMinusculas ( )

/**
 Method10.
*/
void method10 ( )
{
// identificar
 IO_id ( "EXEMPLO0610 - Method10 - v0.1" );
// contar minusculas em cadeias de caracteres
 IO_printf ( "Minusculas (\"abc\",0) = %d\n", contarMinusculas ( "abc", 0 ) );
 IO_printf ( "Minusculas (\"aBc\",0) = %d\n", contarMinusculas ( "aBc", 0 ) );
 IO_printf ( "Minusculas (\"AbC\",0) = %d\n", contarMinusculas ( "AbC", 0 ) );
// encerrar
 IO_pause ( "Apertar ENTER para continuar" );
} // fim method10 ( )

int main ()
{
   int x = 0;
   
   do
   {
      // identificar
      IO_id ( "EXEMPLO0610 - Programa - v0.1" );
      IO_println ( "Author: Gustavo Gomes de Souza - 656841 " );
      
      // opcoes
      printf ( "Opcoes: \n" );
      printf ( "1 - Mostrar certa quantidade de valores. \n" );
      printf ( "2 - Mostrar certa quantidade de valores recursivamente. ( 1 ) \n" );
      printf ( "3 - Mostrar certa quantidade de valores recursivamente. ( 2 ) \n" );
      printf ( "4 - Mostrar certa quantidade de valores recursivamente. ( 3 ) \n" );
      printf ( "5 - Mostrar certa quantidade de valores recursivamente. ( 4 ) \n" );
      printf ( "6 - Somar certa quantidade de fracoes recursivamente. \n" );
      printf ( "7 - Somar certa quantidade de fracoes recursivamente ( 2 ). \n" );
      printf ( "8 - Contar digitos recursivamente. \n" );
      printf ( "9 - Gerador de numero de Fibonacci. \n" );
      printf ( "10 - Contador de letras minusculas. \n" );
      printf ( "Escolha uma opcao: \n" );
      scanf  ( "%d", &x );
      switch ( x )
      {
         case 0:
            break;
         case 1:
            method01 ( );
            break;
         case 2:
            method02 ( );
            break;
         case 3:
            method03 ( );
            break;
         case 4:
            method04 ( );
            break;
         case 5:
            method05 ( );
            break;
         case 6:
            method06 ( );
            break;   
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         default:
            printf( "%s ERRO: Valor invalido. ");
            break;
      }
      
   }
   while ( x != 0 );
   
   //encerrar
   printf ( "Digite ENTER para terminar. " );
   fflush( stdin );
   getchar( );
   return ( 0 );
}

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 * Testes adicionados e legenda (opcoes) corrigidas. ( 21/04 )
---------------------------------------------- previsao de testes
a.) 1
b.) 2
c.) 3
d.) 4
e.) 5
f.) 6
g.) 7
h.) 8
i.) 9
j.) 10

---------------------------------------------- resultados
a.) Valor = 5
    Valor = 4
    Valor = 3
    Valor = 2
    Valor = 1

b.) Valor = 1
    Valor = 2
    Valor = 3
    Valor = 4
    Valor = 5

c.) Valor = 1
    Valor = 2
    Valor = 3
    Valor = 4
    Valor = 5

d.) Valor = 1
    Valor = 2
    Valor = 4
    Valor = 6
    Valor = 8

e.) 1: 1
    2: 2/3
    3: 4/5
    4: 6/7
    5: 8/9

f.) 1; 1.000000
    2: 2.000000/3.000000
    3: 4.000000/5.000000
    4: 6.000000/7.000000
    5: 8.000000/9.000000
    soma = 4.212698

g.) 1: 1.000000
    2: 3.000000/2.000000
    3: 5.000000/4.000000
    4: 7.000000/6.000000
    5: 9.000000/8.000000
    soma = 6.041667

h.) digitos (123) = 3
    digitos (  1) = 1
    digitos (-10) = 2
   
i.) fibonacci (1) = 1
    fibonacci (2) = 1
    fibonacci (3) = 2
    fibonacci (4) = 3
    fibonacci (5) = 5

j.) Minusculas ("abc",0) = 3
    Minusculas ("aBc",0) = 2
    Minusculas ("AbC",0) = 1
   
---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          06/04                            esboco
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
*/