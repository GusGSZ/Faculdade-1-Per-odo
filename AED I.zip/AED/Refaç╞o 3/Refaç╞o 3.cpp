/**
  Refacao 3 - v0.1 - 07/06/2019
  Matricula: 656841
  Author: Gustavo Gomes de Souza
*/

// --------------------------------------------- Dependencias
#include <iostream> // para entrada(cin), saida(cout) e mudanca de linha(endl)
#include <limits> // 
#include <string> // para cadeias de caracteres
#include <stdio.h>

// --------------------------------------------- Definicoes globais

void pause ( std::string text )
{
    std::string dummy;
    std::cin.clear ( );
    std::cout << std::endl << text;
    std::cin.ignore( );
    std::getline( std::cin, dummy );
    std::cout << std::endl;
} // end pause( )

using namespace std;

// --------------------------------------------- classes
#include "killthislove.hpp"


// -------------------------------------------- struct

typedef
struct s_data
{
    int dia;
    int mes;
    int ano;
}data;

// -------------------------------------------- funcoes

int contarpalavras ( string cadeia )
{
    int cont = 0;
    int tamanho = 0;
    int a = 0;
    int extraespaco = 0;
    int i = 0;

    if ( !cadeia.empty() )
    {
        tamanho = cadeia.size();
        cout << tamanho << endl;

        while ( cadeia[i] == ' ' )
        {
            i++;
        }

        for ( int x = i; x < tamanho; x++ )
        {
            if ( cadeia[x] == ' ' && cadeia[x+1] != ' ' )
                cont++;

            if ( cadeia [x+1] == ' ' && (x+1) == (tamanho-1 ) )
                cont -= 1;
        }
    }
    else
    {
        cout << "Cadeia vazia." << endl;
        cont = -1;
    }
    return ( cont+1 );
} // end contarpalavras( )

int faltamdias ( data datas )
{
    int dia = datas.dia;
    int mes = datas.mes;
    int ano = datas.mes;
    int passou = 0;
    int faltam = 0;

    for ( int i = 1; i <= mes; i++ )
    {
        if ( i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12 )
            passou += 31;
        else if ( i == 4 || i == 6 || i == 9 || i == 11 )
            passou += 30;
        else
            passou += 28;
    }

    if ( mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12 )
        passou -= (31-dia);
    else if ( mes == 2 )
        passou -= (28-dia);
    else
        passou -= (30-dia);
    
    faltam = 365 - passou;

    return faltam;
} // end faltamdias( )

// -------------------------------------------- metodos

void method00 ( )
{
    // nao faz nada
} // end method00( )

void questao1 ( )
{
    string cadeia = "";

    cout << "Digite a(s) palavra(s)." << endl;
    cin.ignore();
    getline ( cin, cadeia );
    cout << cadeia << endl;

    cout << "Existem " << contarpalavras(cadeia) << " palavras." << endl;
    
    pause ( "Aperte ENTER para continuar.");
} // end questao1( )

void questao2 ( )
{
    int linhas = 0, colunas = 0, qtd = 0, valor = 0;

    cout << "Quantas linhas a matriz tera'? ";
    cin >> linhas;

    cout << "Quantas colunas a metriz tera'? ";
    cin >> colunas;

    Kisses <int> matriz ( linhas, colunas );

    matriz.preencher( );

    qtd = linhas * colunas - (linhas*colunas-1);
    cout << qtd << endl;

    if ( matriz.listrada ( linhas, colunas, qtd ) )
        cout << "E' listrada." << endl;
    else
        cout << "Nao e' listrada." << endl;

    pause ( "Aperte ENTER para continuar." );
} // end questao2( )

void questao3 ( )
{   
    bool v = true;
    data datas;
    int dia = 0;
    int mes = 0;
    int ano = 0;

    //ifstream arquivo;
    FILE* arquivo = fopen ( "DATAS.txt", "rt" );

    //arquivo.open( "DATAS.txt" );

    if ( arquivo == NULL )
    {
        cout << "Arquivo vazio." << endl;
    }
    else
    {
        while( !feof(arquivo) && v )
        {
            fscanf ( arquivo, "%d", &dia );
            //arquivo >> datas.dia;
            fscanf ( arquivo, "%d", &mes );
            //arquivo >> datas.mes;
            fscanf ( arquivo, "%d", &ano );
            //arquivo >> datas.ano;
            datas.dia = dia;
            datas.mes = mes;
            datas.ano = ano;
            cout << dia << "/" << mes << "/" << ano << endl;

            if ( ( ( datas.mes == 4 || datas.mes == 6 || datas.mes == 9 || datas.mes == 11 ) && datas.dia > 30 || datas.dia < 1 ) 
            || ( datas.mes == 2 && datas.dia > 28 || datas.dia < 1 ) 
            || ( (datas.mes == 1 || datas.mes == 3 || datas.mes == 5 || datas.mes == 7 || datas.mes == 8 || datas.mes == 10 || datas.mes == 12) && datas.dia > 31 || datas.dia < 1 )
            || ( datas.mes > 12 || datas.mes <= 0 ) )
            {
                cout << "Data invalida." << endl;
                v = false;
            }
            else
            {
                cout << "Deste dia ate' o fim do ano faltam " << faltamdias(datas) << " dias." << endl << endl;
            }
        }
    }
    
} // end questao3( )

// -------------------------------------------- acao principal

/**
 * Funcao principal
 * @return codigo de encerramento
*/

int main( int argc, char** argv )
{
//  definir dado
    int x = 0;
//  repetir ate desejar parar
    do
    {
    //  identificar
        cout << "Refacao - Programa - v0.1\n" << endl;
    //  opcoes
        cout << "Opcoes: "<< endl;
        cout << "1 - Calcular quantas palavras existem na cadeia." << endl;
        cout << "2 - Dizer se uma matriz e' listrada ou nao." << endl;
        cout << "3 - Calcular quantos dias faltam para o fim do ano." << endl;
        cin >> x;
        cout << endl;
    //  escolher acao
        switch ( x )
        {
            case 0:
                method00( );
                break;
            case 1:
                questao1( );
                break;
            case 2:
                questao2( );
                break;
            case 3:
                questao3( );
                break;
            default:
                cout << "Opcao invalida." << endl;
                break;
        }
    } while ( x != 0 );
//  encerrar
    pause ( "Aperte ENTER para terminar.");
    return ( 0 );
} // fim main( )