/*
 Exemplo1011->E2 - v0.1 - |19/05/2019 - 26/05/2019|
 Matricula: 656841
 Author: Gustavo Gomes de Souza
*/

// dependencias
#include "io.h" // para definicoes proprias


/**
 Definicao de tipo arranjo com inteiros baseado em estrutura
*/

typedef 
struct s_vetorInt
{
   int tamanho;
   int* dados;
   int ix;
   
}vetorInt;

/**
 Definicao de tipo arranjo bidimensional com inteiros baseado em estrutura
*/

typedef
struct s_matrizInt
{
   int linhas;
   int colunas;
   int **dados;
   int i, j;
   
}matrizInt;

/**
 Definicao de referencia para arranjo bidimensional com inteiros baseado em estrutura
*/

typedef matrizInt *refmi;

//-------------------------------------- funcoes auxiliares

void gravarVetorInteiro ( vetorInt vetor, char* fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   fprintf ( arquivo, "%d\n", vetor.tamanho );
   
   // mostrar valores no arranjo
   for ( vetor.ix = 0; vetor.ix < vetor.tamanho; vetor.ix++ ){
      
      //gravar valor
      fprintf ( arquivo, "%d: %d\n", vetor.ix, vetor.dados[vetor.ix]);
   }
   
   fclose ( arquivo );
}

void mostrarVetor ( vetorInt vetor )
{
   printf ( "\n" );
   
   //mostrar valores do vetor
   for ( vetor.ix=0; vetor.ix < vetor.tamanho; vetor.ix++ )
   {
      //mostrar valor
      printf ( "%d: %d\n", vetor.ix, vetor.dados[vetor.ix]);
   }
   
}

vetorInt lerArquivo ( chars fileName )
{
   FILE *arquivo = fopen ( fileName, "rt" );
   int x = 0;
   int y = 0;
   vetorInt vetor;
   vetor.ix = 0;
   int w = 0;
   
   fscanf ( arquivo, "%d", &x );
   vetor.tamanho = x;
   
   vetor.dados = (int*) malloc ((vetor.tamanho)*sizeof(int));
   while ( !feof (arquivo) && vetor.ix < x )
   {
      fscanf ( arquivo, "%d: %d", &w, &y );
      vetor.dados[vetor.ix] = y;
      vetor.ix++;
   }
   
   return ( vetor );
}

bool achar ( vetorInt vetor, int n ){
   
   int x = vetor.tamanho;
   vetor.ix = 0;
   int valor = 0;
   
   for ( vetor.ix = 0; vetor.ix < x; vetor.ix++ )
   {
      if ( vetor.dados[vetor.ix] == n )
      {
         valor = vetor.ix;
         printf ( "Foi encontrado o valor procurado na posicao: %d\n", vetor.ix );
      }
   }
   
   if ( valor == 0 )
   {
      printf ( "Nao foi encontrado o valor buscado." );
      return false;
   }
   else
      return true;
}

bool comparar ( vetorInt vetor1, vetorInt vetor2 )
{
   int tam = vetor1.tamanho;
   int tam2 = vetor2.tamanho;
   int iguais = 0;
   
   vetor2.ix = 0;
   
   if ( tam == tam2 ){
      for ( vetor1.ix = 0; vetor1.ix < tam; vetor1.ix++ )
      {
         if ( vetor1.dados[vetor1.ix] == vetor2.dados[vetor2.ix] )
         {
            iguais++;
         }
         vetor2.ix++;
      }
   }
   else{
      return false;
   }
   
   if ( iguais == tam )
   {
      return true;
   }
   else
   {
      return false;
   }
   
}

void criarVetor ( chars fileName, int n )
{
   static vetorInt vetor;
   
   int valor = 0;
   
   vetor.tamanho = n;
   
   printf ( "Digite os valores do vetor.\n" );
   
   if ( n <= 0 )
   {
      printf ( "\nERRO: Quantidade invalida.\n" );
   }
   else
   {
      
      vetor.dados = (int*) malloc ((vetor.tamanho)*sizeof(int));
      
      vetor.ix = 0;
      
      while ( vetor.ix < vetor.tamanho ){
         valor = IO_readint ( "" );
         vetor.dados[vetor.ix] = valor;
         vetor.ix++;
      }
      
      gravarVetorInteiro ( vetor, fileName );
   }
}

vetorInt somar ( vetorInt vetor1, vetorInt vetor2 )
{
   int tam = vetor1.tamanho;
   int tam2 = vetor2.tamanho;
   vetorInt vetorSomado;
   vetorInt alternativo;
   
   vetorSomado.tamanho = tam;
   
   vetorSomado.dados = (int*) malloc ((vetorSomado.tamanho)*sizeof(int));
   alternativo.dados = (int*) malloc ((vetorSomado.tamanho)*sizeof(int));
   if ( tam == tam2 ){
      for ( vetor1.ix = 0; vetor1.ix < tam; vetor1.ix++ )
      {
         vetorSomado.dados[vetor1.ix] = vetor1.dados[vetor1.ix] + vetor2.dados[vetor1.ix];
      }
      return vetorSomado;
   }
   else
   {
      for ( int i = 0; i < tam; i++ )
      {
         alternativo.dados[i] = 0;
      }
      
      printf ( "Os vetores nao sao do mesmo tamanho, o que impossibilita a soma.\n" );
      printf ( "\nVetor default: \n" );
      return alternativo;
   }
}

bool ordenado ( vetorInt vetor )
{
   
   int x = 0; // contador pra saber se o vetor esta' ordenado
   
   for ( vetor.ix = 0; vetor.ix < vetor.tamanho; vetor.ix++ )
   {
      if ( vetor.ix == 0 )
      {
         x++;
      }
      else if ( vetor.dados [vetor.ix] > vetor.dados[vetor.ix-1] )
      {
         x++;
      }
   }
   
   if ( x == vetor.tamanho )
      return true;
   else
      return false;
}

vetorInt ordenar ( vetorInt vetorordenado )
{
   int aux = 0;
   int aux2 = 0;
   
   HERE:
   
   for ( int i = 0; i < (vetorordenado.tamanho-1); i++ )
   {
      if ( vetorordenado.dados[i] > vetorordenado.dados [i+1] )
      {  
         aux = vetorordenado.dados [ i ];
         aux2 = vetorordenado.dados [ i + 1 ];
         vetorordenado.dados [ i ] = aux2;
         vetorordenado.dados [ i + 1 ] = aux;
      }
   }
   
   for ( int i = 0; i < (vetorordenado.tamanho-1); i++ )
   {
      if ( vetorordenado.dados[i] > vetorordenado.dados [i+1] )
      {
         goto HERE;
      }
   }
   
   return vetorordenado;
}

//------------------------------------------------------matrizes

typedef matrizInt* refmatriz;

refmatriz reservarEspaco ( int lines, int columns )
{
   // reserva de espaco
   refmatriz tmpMatrix = (refmatriz) malloc (sizeof(matrizInt));
// estabelecer valores padroes
   if ( tmpMatrix != NULL )
   {
      tmpMatrix->linhas = 0;
      tmpMatrix->colunas = 0;
      tmpMatrix->dados = NULL;
   // reservar espaco
      if ( lines>0 && columns>0 )
      {
         tmpMatrix->linhas = lines;
         tmpMatrix->colunas = columns;
         tmpMatrix->dados = malloc (columns * sizeof(ints));
         for ( int i = 0; i <tmpMatrix->linhas; i++ )
         {
            tmpMatrix->dados [ i ] = (ints) malloc (columns * sizeof(int));
         } // fim repetir
      } // fim se
      int i = 0;
      int j = 0;
   } // fim se
   return ( tmpMatrix );
}

void freeMatriz ( refmatriz tmpMatrix )
{
// testar se ha' dados
   if ( tmpMatrix != NULL )
   {
      for ( int i = 0; i < tmpMatrix->linhas; i++ )
      {
         free ( tmpMatrix->dados [ i ] );
      } // fim repetir
      free ( tmpMatrix );
   } // fim se
} // fim free_int_Matrix ( )  

void mostrarMatriz ( refmatriz matriz )
{
   printf ( "\n" );
   
   int i = 0;
   int j = 0;
   
   //mostrar valores da matriz
   for ( i = 0; i < matriz->linhas; i++ )
   {
      for ( j = 0; j < matriz->colunas; j++ )
      {
         printf ( "%d\t", matriz->dados[i][j]);
      }
      printf ( "\n" );
   }
   
}

void gravarMatriz ( refmatriz matrix, char* fileName )
{
   FILE* arquivo = fopen ( fileName, "wt" );
   int valor = 0;
   fprintf ( arquivo, "%d\n", matrix->linhas );
   fprintf ( arquivo, "%d\n", matrix->colunas );
   
   // mostrar valores no arranjo
   for ( matrix->i = 0; matrix->i < matrix->linhas; matrix->i++ )
   {
      for ( matrix->j = 0; matrix->j < matrix->colunas; matrix->j++ ){
            
         fprintf ( arquivo, "%d\n", matrix->dados[matrix->i][matrix->j] );
      }
   }
   
   fclose ( arquivo );
}

void criarMatriz ( chars fileName, int linhas, int colunas )
{
   refmatriz matriz = reservarEspaco ( linhas, colunas );
   
   int valor = 0;
   
   matriz->linhas = linhas;
   matriz->colunas = colunas;
   
   printf ( "Digite os valores da matriz: " );
   
   if ( linhas < 0 || colunas < 0 || ( linhas <= 0 && colunas <= 0 ) )
   {
      printf ( "ERRO: Valor invalido." );
   }
   else
   {  
      int i = 0;
      int j = 0;
      
      for ( i = 0; i < matriz->linhas; i++ )
      {
         for ( int j = 0; j < matriz->colunas; j++ )
         {
            valor = IO_readint ( "" );
            matriz->dados[i][j] = valor;
         }
      }
   }
   
   mostrarMatriz ( matriz );
   gravarMatriz ( matriz, fileName );
}

refmatriz lerMatrizDeArquivo ( char* fileName )
{
   FILE *arquivo = fopen ( fileName, "rt" );
   int x = 0;
   int y = 0;
   int w = 0;
   
   fscanf ( arquivo, "%d", &x );
   fscanf ( arquivo, "%d", &y );
   refmatriz matriz = reservarEspaco ( x, y );
   matriz->linhas = x;
   matriz->colunas = y;
   
   matriz->i = 0;
   matriz->j = 0;
   
   
   matriz->dados = malloc ((matriz->linhas)*sizeof(int));
   for ( matriz->i = 0; matriz->i < matriz->linhas; matriz->i++ )
   {
      matriz->dados[matriz->i] = (int*) malloc ((matriz->colunas)*sizeof(int));
      for ( matriz->j = 0; matriz->j < matriz->colunas; matriz->j++ )
      {
         fscanf ( arquivo, "%d", &w );
         
         matriz->dados[matriz->i][matriz->j] = w;
      }
   }
   
   
   
   return ( matriz );
}

refmatriz transposta ( refmatriz matriz )
{
   refmatriz transposta = reservarEspaco ( matriz->colunas, matriz->linhas );
   
   transposta->linhas = matriz->colunas;
   transposta->colunas = matriz->linhas;
   
   int i = 0;
   int j = 0;
      
   for ( i = 0; i < transposta->colunas; i++ )
   {
      for ( j = 0; j < transposta->linhas; j++ )
      {
         transposta->dados[j][i] = matriz->dados[i][j];
      }
   }
   
   return ( transposta );
}

bool igualazero ( refmatriz matriz )
{
   int zero = 0;
   
   for ( int i = 0; i < matriz->linhas; i++ )
   {
      for ( int j = 0; j < matriz->colunas; j++ )
      {
         if ( matriz->dados[i][j] == 0 )
         zero++;
      }
   }
   
   if ( zero == matriz->linhas*matriz->colunas )
   return true;
   else
   return false;
}

bool compararMatriz ( refmatriz matriz1, refmatriz matriz2 )
{
   int igual = 0;
   
   if ( (matriz1->linhas == matriz2->linhas) && (matriz1->colunas == matriz2->colunas) )
   {
      for ( int i = 0; i < matriz1->linhas; i++ )
      {
         for ( int j = 0; j < matriz1->colunas; j++ )
         {
            if ( matriz1->dados[i][j] == matriz2->dados[i][j] )
               igual++;
         }
      }
   }
   
   if ( igual == matriz1->linhas*matriz1->colunas )
   return true;
   else
   return false;
}

refmatriz somarMatriz ( refmatriz matriz1, refmatriz matriz2 )
{
   if ( ( matriz1->linhas == matriz2->linhas) && ( matriz1->colunas == matriz2->colunas ) )
   {
      refmatriz matrizsomada = reservarEspaco ( matriz1->linhas, matriz1->colunas );
      
      for ( int i = 0; i < matriz1->linhas; i++ )
      {
         for ( int j = 0; j < matriz1->colunas; j++ )
         {
            matrizsomada->dados[i][j] = matriz1->dados[i][j] + matriz2->dados[i][j];
         }
      }
      
      return matrizsomada;
   }
   else
   {
      refmatriz matrizdefault = reservarEspaco ( matriz1->linhas, matriz1->colunas );
      for ( int i = 0; i < matriz1->linhas; i++ )
      {
         for ( int j = 0; j < matriz1->colunas; j++ )
         {
            matrizdefault->dados[i][j] = 0;
         }
      }
      
      printf ( "\nAs matrizes nao sao de mesma ordem, nao e' possivel fazer a soma.\n" );
      printf ( "Matriz default: \n" );
      return ( matrizdefault );
   }
   
}

refmatriz multiplicarMatriz ( refmatriz matriz1, refmatriz matriz2 )
{
   if ( matriz1->colunas == matriz2->linhas )
   {
      refmatriz matrizmultiplicada = reservarEspaco ( matriz1->linhas, matriz2->colunas );
      
      int termo1 = 0;
      int result = 0;
      
      for ( int i = 0; i < matriz1->linhas; i++ )
      {
         for ( int j = 0; j < matriz2->colunas; j++ )
         {
            for ( int k = 0; k < matriz2->colunas; k++ )
            {
               termo1 = (matriz1->dados[i][k] * matriz2->dados[k][j] );
               result = result + termo1;
            }
            matrizmultiplicada->dados[i][j] = result;
            result = 0;
         }
         
      }
      
      return matrizmultiplicada;
   }
   else
   {
      refmatriz matrizdefault = reservarEspaco ( matriz1->linhas, matriz1->colunas );
      for ( int i = 0; i < matriz1->linhas; i++ )
      {
         for ( int j = 0; j < matriz1->colunas; j++ )
         {
            matrizdefault->dados[i][j] = 0;
         }
      }
      
      printf ( "\nO numero de linhas da matriz1 nao e' o mesmo de colunas da matriz2.\n" );
      printf ( "Matriz default: \n" );
      return matrizdefault;
   }
}

bool igualaidentidade ( refmatriz matriz )
{
   int zero = 0;
   int um = 0;
   
   if ( matriz->linhas == matriz->colunas )
   {
      for ( int i = 0; i < matriz->linhas; i++ )
      {
         for ( int j = 0; j < matriz->colunas; j++ )
         {
            if ( i==j ){
               if ( matriz->dados[i][j] == 1 )
                  um++;
            }
            else
            {
              if ( matriz->dados[i][j] == 0 )
              zero++;
            }
         }
      }
      
      if ( (um == matriz->linhas) && (zero == ((matriz->linhas*matriz->colunas)-matriz->linhas)) )
         return true;
      else
         return false;
   }
   else
   {
      printf ( "\nNao e' matriz quadrada, portanto, nao pode ser uma matriz identidade por nao possuir diagonal principal.\n" );
      return false;
   }
}

//------------------------------------------------------metodos

void method01a ( chars fileName, int inf, int sup, int n )
{
   static vetorInt vetor;
   
   vetor.tamanho = n;
   
   if ( n <= 0 )
   {
      printf ( "\nERRO: Quantidade invalida.\n" );
   }
   else if ( inf > sup )
   {
      printf ( "\nERRO: Limites invalidos." );
   }
   else
   {
      int random = 0;
      
      vetor.dados = (int*) malloc ((vetor.tamanho)*sizeof(int));
      
      vetor.ix = 0;
      
      while ( vetor.ix < vetor.tamanho ){
         random = inf + (rand( ) %(sup-inf) );
         vetor.dados[vetor.ix] = random;
         vetor.ix++;
      }
      
      mostrarVetor ( vetor );
      gravarVetorInteiro ( vetor, fileName );
   }
}

void method01 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method01 - v0.1" );

   //definicao de dados
   int n = 0;
   int inf = 0;
   int sup = 0;
   
   n = IO_readint ( "Quantos valores aleatorios serao gravados? " );
   inf = IO_readint ( "Qual o valor inferior do intervalo? " );
   sup = IO_readint ( "Qual o valor superior do intervalo? " );
   
   method01a ( "DADOS.txt", inf, sup, n );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method02 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method02 - v0.1" );

   //definicao de dados
   vetorInt novoVetor;
   novoVetor = lerArquivo( "DADOS.txt" );
   int valorProcurado = 0;
   printf ( "Qual o valor procurado?\n" );
   scanf ( "%d", &valorProcurado );
   
   achar ( novoVetor, valorProcurado );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method03a ( )
{  
   int n = 0;
   int n1 = 0;
   
   n = IO_readint ( "Quantos valores serao gravados no primeiro arranjo? " );
   n1 = IO_readint ( "Quantos valores serao gravados no segundo arranjo? " );
   
   printf ( "Primeiro arranjo; " );
   criarVetor ( "DADOS1.txt", n );
   printf ( "Segundo arranjo; " );
   criarVetor ( "DADOS2.txt", n1 );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method03 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method03 - v0.1" );

   //definicao de dados
   vetorInt vetor1;
   vetorInt vetor2;
   
   vetor1 = lerArquivo ( "DADOS1.txt" );
   vetor2 = lerArquivo ( "DADOS2.txt" );
   
   mostrarVetor ( vetor1 );
   mostrarVetor ( vetor2 );
   
   printf ( "\n" );
   
   if ( comparar ( vetor1, vetor2 ) == true )
      printf ( "Os arranjos possuem os mesmos valores." );
   else
      printf ( "Os arranjos possuem valores diferentes." );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method04 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method04 - v0.1" );

   //definicao de dados
   vetorInt vetor1;
   vetorInt vetor2;
   vetorInt vetorSomado;
   
   vetor1 = lerArquivo ( "DADOS1.txt" );
   vetor2 = lerArquivo ( "DADOS2.txt" );
   
   printf ( "\nVetor 1: \n" );
   mostrarVetor ( vetor1 );
   
   printf ( "\nVetor 2: \n" );
   mostrarVetor ( vetor2 );
   
   printf ( "\n" );
   
   vetorSomado = somar( vetor1, vetor2 );
   mostrarVetor ( vetorSomado );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void method05 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method05 - v0.1" );

   //definicao de dados
   vetorInt vetor;
   vetor = lerArquivo ( "DADOS1.txt" );
   
   mostrarVetor ( vetor );
   
   printf ( "\n" );
   
   if ( ordenado ( vetor ) )
      printf ( "O vetor esta' em ordem crescente." );
   else
      printf ( "O vetor nao esta' em ordem crescente." );
      
   IO_pause ( "Aperte ENTER para terminar." );
}

void method06a ( )
{  
   int n = 0;
   int n1 = 0;
   
   n = IO_readint ( "Quantos linhas a matriz tera'? " );
   n1 = IO_readint ( "Quantos colunas a matriz tera'? " );
   
   criarMatriz ( "DADOS01.txt", n, n1 );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method06 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method06 - v0.1" );

   //definicao de dados
   refmatriz matriz;
   
   matriz = lerMatrizDeArquivo ( "DADOS01.txt" );
   
   printf ( "\nMatriz original: " );
   mostrarMatriz ( matriz );
   
   printf ( "\nMatriz transposta: " );
   mostrarMatriz ( transposta ( matriz ) );
   
   IO_pause( "Aperte ENTER para continuar." );
}

void method07 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method07 - v0.1" );

   //definicao de dados
   refmatriz matriz;
   
   matriz = lerMatrizDeArquivo ( "DADOS01.txt" );
   
   if ( igualazero ( matriz ) )
   printf ( "Todos os valores da matriz sao iguais a zero." );
   else
   printf ( "Todos ou alguns valores da matriz sao diferentes de zero." );
   
   IO_pause( "Aperte ENTER para continuar." );
}

void method08a ( )
{  
   int n = 0;
   int n1 = 0;
   
   n = IO_readint ( "Quantos linhas a matriz tera'? " );
   n1 = IO_readint ( "Quantos colunas a matriz tera'? " );
   
   criarMatriz ( "DADOS02.txt", n, n1 );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method08 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method08 - v0.1" );

   //definicao de dados
   refmatriz matriz1, matriz2;
   
   matriz1 = lerMatrizDeArquivo ( "DADOS01.txt" );
   matriz2 = lerMatrizDeArquivo ( "DADOS02.txt" );
   
   if ( compararMatriz ( matriz1, matriz2 ) )
   printf ( "As matrizes sao iguais." );
   else
   printf ( "As matrizes sao diferentes." );
   
   IO_pause( "Aperte ENTER para continuar." );
}

void method09 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method09 - v0.1" );

   //definicao de dados
   refmatriz matriz1, matriz2;
   
   matriz1 = lerMatrizDeArquivo ( "DADOS01.txt" );
   matriz2 = lerMatrizDeArquivo ( "DADOS02.txt" );
   
   printf ( "Matriz original 1:\n" );
   mostrarMatriz ( matriz1 );
   
   printf ( "\nMatriz original 2:\n" );
   mostrarMatriz ( matriz2 );
   
   printf ( "\nMatriz somada:\n" );
   mostrarMatriz ( somarMatriz ( matriz1, matriz2 ) );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void method10 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - Method10 - v0.1" );

   //definicao de dados
   refmatriz matriz1, matriz2;
   
   matriz1 = lerMatrizDeArquivo ( "DADOS01.txt" );
   matriz2 = lerMatrizDeArquivo ( "DADOS02.txt" );
   
   printf ( "Matriz original 1:\n" );
   mostrarMatriz ( matriz1 );
   
   printf ( "\nMatriz original 2:\n" );
   mostrarMatriz ( matriz2 );
   
   printf ( "\nMatriz multiplicada:\n" );
   mostrarMatriz ( multiplicarMatriz ( matriz1, matriz2 ) );
   
   IO_pause ( "Aperte ENTER para continuar." );
}

void methodE1 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - MethodE1 - v0.1" );

   //definicao de dados
   vetorInt vetor;
   vetor = lerArquivo ( "DADOS1.txt" );
   
   printf ( "\nVetor original:\n " );
   mostrarVetor ( vetor );
   
   printf ( "\nVetor ordenado:\n " );
   mostrarVetor ( ordenar ( vetor ) );
   
   IO_pause ( "Aperte ENTER para terminar." );
}

void methodE2 ( )
{
   // identificar
   IO_id ( "EXEMPLO1011->E2 - MethodE2 - v0.1" );

   //definicao de dados
   refmatriz matriz1, matriz2;
   
   matriz1 = lerMatrizDeArquivo ( "DADOS01.txt" );
   matriz2 = lerMatrizDeArquivo ( "DADOS02.txt" );
   
   printf ( "Matriz original 1:\n" );
   mostrarMatriz ( matriz1 );
   
   printf ( "\nMatriz original 2:\n" );
   mostrarMatriz ( matriz2 );
   
   printf ( "\nMatriz multiplicada:\n" );
   mostrarMatriz (multiplicarMatriz ( matriz1, matriz2 ));
   printf ( "\n" );
   
   if ( igualaidentidade (multiplicarMatriz ( matriz1, matriz2 )) )
      printf ( "O produto das matrizes e' uma matriz identidade." );
   else
      printf ( "O produto das matrizes nao e' uma matriz identidade.\n" );
      
   IO_pause ( "Aperte ENTER para continuar." );
}

int main ( )
{
   // Declarar variaveis
   int x = 0;
   
   // Repeticao do menu de metodos
   do{ 
      // identificar
      IO_id ( "EXEMPLO1011-E2 - Programa - v0.1" );
   
   // ler do teclado
      IO_println ( "Opcoes" );
      IO_println ( " 0 - Parar." );
      IO_println ( " 1 - Gerar valores aleatorios e gravar em arranjo." );
      IO_println ( " 2 - Procurar valor em arranjo." );
      IO_println ( " 3 - Comparar se dois vetores sao iguais ou nao." );
      IO_println ( " 4 - Somar dois vetores." );
      IO_println ( " 5 - Dizer se um vetor esta' em ordem crescente ou nao." );
      IO_println ( " 6 - Obter a transposta de uma matriz." );
      IO_println ( " 7 - Testar se uma matriz so' contem valores iguais a zero." );
      IO_println ( " 8 - Testar se duas matrizes sao iguais." );
      IO_println ( " 9 - Somar duas matrizes." );
      IO_println ( "10 - Multiplicar duas matrizes." );
      IO_println ( "11 - Ordenar vetor." );
      IO_println ( "12 - Testar se o produto de duas matrizes e' igual a matriz identidade." );
      IO_println ( "13 - Criar e gravar novos vetores(arranjos) em arquivos (DADOS1.txt e DADOS2.txt)." ); // Esse metodo eu uso pra criar vetores pra poder usa-los em questoes depois da 3
      IO_println ( "14 - Criar e gravar nova matriz em arquivo (DADOS01.txt)." ); // Esse pra criar uma matriz para os exercicios a partir da 6
      IO_println ( "15 - Criar e gravar nova matriz em arquivo (DADOS02.txt)." ); // Esse para os exercicios a partir da 8, que precisa de duas matrizes
      IO_println ( "" );
      scanf ( "%d", &x );
      switch ( x ){
         case 0:
            break;
         case 1:
            method01( );
            break;
         case 2:
            method02( );
            break;
         case 3:
            method03( );
            break;
         case 4:
            method04( );
            break;
         case 5:
            method05( );
            break;
         case 6:
            method06( );
            break;
         case 7:
            method07 ( );
            break;
         case 8:
            method08 ( );
            break;
         case 9:
            method09 ( );
            break;
         case 10:
            method10 ( );
            break;
         case 11:
            methodE1 ( );
            break;
         case 12:
            methodE2 ( );
            break;
         case 13:
            method03a( );
            break;
         case 14:
            method06a( );
            break;
         case 15:
            method08a ( );
            break;
         default:
            printf ( "ERRO: Valor invalido\n" );
            break;
      } 
   } while ( x != 0 );
   
   // encerrar
   printf ( "Aperte ENTER para terminar." );
   
   fflush(stdin);
   getchar ( );
   return ( 0 );
} //fim int main( )

/*
---------------------------------------------- documentacao complementar

---------------------------------------------- notas / observacoes / comentarios
 
---------------------------------------------- previsao de testes
a.) 1, 3 e [1:10]

   Resultado:
      0: 6
      1: 9
      2: 8
      
b.) 2 e 8
   Resultado:
      Foi encontrado o valor procurado na posicao: 2


c.) 3

   Resultado:
      0: 8
      1: 29
      2: 290
      3: 19
      4: 487
      5: 58
      6: 93
      7: 8
      8: 28
      9: 74
      10: 8
      11: 3
      12: 2
      13: 5
      14: 8
      15: 2
      16: 37
      17: 4730
      18: 849
      19: 38
      
      0: 1
      1: 2
      2: 3
      3: 4
      4: 5
      5: 6
      6: 7
      7: 8
      8: 9
      9: 10
      
      Os arranjos possuem valores diferentes.
      
d.) 4

   Resultado:
   
      Vetor 1:
   
      0: 8
      1: 29
      2: 290
      3: 19
      4: 487
      5: 58
      6: 93
      7: 8
      8: 28
      9: 74
      10: 8
      11: 3
      12: 2
      13: 5
      14: 8
      15: 2
      16: 37
      17: 4730
      18: 849
      19: 38
      
      Vetor 2:
      
      0: 1
      1: 2
      2: 3
      3: 4
      4: 5
      5: 6
      6: 7
      7: 8
      8: 9
      9: 10      
      
      Os vetores nao sao do mesmo tamanho, o que impossibilita a soma.
      
      Vetor default:
      
      0: 0
      1: 0
      2: 0
      3: 0
      4: 0
      5: 0
      6: 0
      7: 0
      8: 0
      9: 0
            
e.) 5

   Resultado:

      0: 8
      1: 29
      2: 290
      3: 19
      4: 487
      5: 58
      6: 93
      7: 8
      8: 28
      9: 74
      10: 8
      11: 3
      12: 2
      13: 5
      14: 8
      15: 2
      16: 37
      17: 4730
      18: 849
      19: 38

      O vetor nao esta' em ordem crescente.
      
f.) 6

   Resultado:
   
      Matriz original: 
         1	0	0	
         0	1	0	
         0	0	1	
      
      Matriz transposta: 
         1	0	0	
         0	1	0	
         0	0	1
      
g.) 7

   Resultado:
      Todos ou alguns valores da matriz sao diferentes de zero.
      
h.) 8

   Resultado:
      As matrizes sao diferentes.
       
i.) 9
      
   Resultado:
   
      Matriz original 1:
      
         1	0	0	
         0	1	0	
         0	0	1	
      
      Matriz original 2:
      
         1	0	0	
         1	0	0	
         0	1	0	
      
      Matriz somada:
      
         2	0	0	
         1	1	0	
         0	1	1	
   
j.) 10

   Resultado:
   
   Matriz original 1:
   
      1	2	3	
      4	5	6	
      7	8	9	
   
   Matriz original 2:
   
      1	2	3	
      4	5	6	
      7	8	9	
      
   Matriz multiplicada:
   
      30	   36	   42	
      66	   81	   96	
      102	126	150
      
k.) 11

   Resultado:
   
   Vetor original:
   
      0: 8
      1: 29
      2: 290
      3: 19
      4: 487
      5: 58
      6: 93
      7: 8
      8: 28
      9: 74
      10: 8
      11: 3
      12: 2
      13: 5
      14: 8
      15: 2
      16: 37
      17: 4730
      18: 849
      19: 38
   
   Vetor ordenado:
   
      0: 2
      1: 2
      2: 3
      3: 5
      4: 8
      5: 8
      6: 8
      7: 8
      8: 19
      9: 28
      10: 29
      11: 37
      12: 38
      13: 58
      14: 74
      15: 93
      16: 290
      17: 487
      18: 849
      19: 4730

l.) 12

   Resultado:
   
      Matriz original 1:
      
         1	2	3	
         4	5	6	
         7	8	9	
      
      Matriz original 2:
      
         1	2	3	
         4	5	6	
         7	8	9	
      
      Matriz multiplicada:
      
         30	   36	   42
         66	   81	   96
         102	126	150
      
      O produto das matrizes nao e' uma matriz identidade.

---------------------------------------------- historico
Versao        Data                             Modificacao
 0.1          19/05                            esboco
              |
              |
              |
              26/05
 
---------------------------------------------- testes
Versao        Teste
 0.1          01. ( OK )                       identificacao de programa
              02. ( OK )
              03. ( OK )
              04. ( OK )
              05. ( OK )
              06. ( OK )
              07. ( OK )
              08. ( OK )
              09. ( OK )
              10. ( OK )
              11. ( OK )
              12. ( OK )
*/